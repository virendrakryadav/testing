<div class="prvlist_box"> <a href="#"><img src="<?php  echo CommonUtility::getPublicImageUri( "prv_img.jpg" ) ?>" width="71" height="52"></a>
                <p class="title">Candy</p>
                <p class="date">Done by : John     21-01-2014</p>                
            </div>

<div class="prvlist_box"> <a href="#"><img src="<?php  echo CommonUtility::getPublicImageUri( "prv_img.jpg" ) ?>" width="71" height="52"></a>
                <p class="title">Candy</p>
                <p class="date">Done by : John     21-01-2014</p>
            </div>

<div class="prvlist_box"> <a href="#"><img src="<?php  echo CommonUtility::getPublicImageUri( "prv_img.jpg" ) ?>" width="71" height="52"></a>
                <p class="title">Candy</p>
                <p class="date">Done by : John     21-01-2014</p>
            </div>

<div class="prvlist_box"> <a href="#"><img src="<?php echo CommonUtility::getPublicImageUri( "prv_img.jpg" ) ?>" width="71" height="52"></a>
                <p class="title">Candy</p>
                <p class="date">Done by : John     21-01-2014</p>
            </div>  

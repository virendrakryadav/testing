 <div class="page-container pagetopmargn">
 
<!--Left side bar start here-->
<div class="leftbar">
<!--Previoue tast start here-->
<div class="box">
<div class="box_topheading"><h3 class="h3">Previous Task</h3></div>
<div class="box2">
<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>
</div>
</div>
<!--Previoue tast Ends here-->

<!--Template Category start here-->
<div class="box">
<div class="box_topheading"><h3 class="h3">Template Category</h3></div>
<div class="box2">
<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>
</div>
</div>
<!--Template Category tast Ends here-->

</div>
<!--Left side bar ends here-->

<!--Right side content start here-->
<div class="rightbar">
<div class="box">
<div class="box_topheading"><h3 class="h3">Post your task in just couple of seconds</h3></div>

<!--Instant task start here-->
<div class="controls-row pdn2">
<div class="controls-row pdn4">
<!--Task step start here-->
<div class="step_row">
<div class="step1 active">
<span class="nubr">1</span>Create your task
</div>
<div class="step1 active"><span class="nubr">2</span>Preview</div>
</div>
<!--Task step ends here-->
<div class="controls-row">
<!--Task title start here-->
<div class="controls-row">

<div class="controls-row">
<div class="taskpreview_img"><img src="../images/no_category_img.png" width="150px" height="150"></div>
<div class="taskpreview_title">
<h3 class="h3-1">Ecommerce website design</h3>
<span class="postedby">Posted by <a href="#">Amit S.</a></span>
<span class="postedby"><i class="icon-map-marker"></i>Indi, NSW</span>
<span class="postedby">3 Seconds ago</span></div>
</div>
<div class="taskcount">
<div class="taskcount_col1"><span class="point">0</span><br/>Proposals</div>
<div class="taskcount_col1"><span class="point">0</span><br/>Invited</div>
<div class="taskcount_col1"><span class="point">$200</span><br/>Fixed Price</div>
<div class="datecount_col1"><span class="point2">20</span><br/>Days left</div>
</div>
</div>
<!--Task title ends here-->

<!--Skills needed start here-->

<div class="controls-row">
<h2 class="taskheading">Request specific skills</h2>
<div class="skill">
<ul>
<li>c , c++</li>
<li>Design</li>
<li>Ecommerce</li>
<li>Graphic design</li>
</ul>
<ul>
<li>Mobile</li>
<li>Music</li>
<li>Video</li>
<li>Website design</li>
</ul>
</div>
</div>
<!--Skills needed ends here-->

<!--Description Start here-->
<div class="controls-row">
<h2 class="taskheading">Description</h2>
Looking for an ecommerce website that will feature pages such as a. About us b. Group of companies with each company having its own page on the same web site. Not sure if you call pull this. I like to put a page about my essential oil page, Tshirt sale page, African arts page, missionary page, gallery page, music pageand a blog. Animal shelter, summer camp, c. Products an shopping cart and payment d. I want the pictures coded so it cant be copied. video and multi media ability and mobile ready and compatible website
</div>
<!--Description Ends here-->

<!--Requirements & details Start here-->
<div class="controls-row">
<h2 class="taskheading">Requirements & details</h2>
<div class="controls-row"><div class="name_ic"><img src="../images/vis-ic.png"></div>Public - Open to All</div>
</div>
<div class="controls-row">
<div class="postedby"><img src="../images/doc1.png"></div>
<div class="postedby"><img src="../images/noimage.jpg"></div>
</div>
<!--Requirements & details Ends here-->

<!--Invited tasker start here-->
<div class="controls-row">
<h2 class="taskheading">Invited tasker</h2>
<div class="postedby"><img src="../images/tasker-img.jpg"></div>
<div class="postedby"><img src="../images/tasker-img.jpg"></div>
</div>
<!--Invited tasker ends here-->

</div>
</div>
<div class="controls-row cnl_space">
<div class="span5 nopad">
<input type="submit" value="Edit" name=""  class="sign_bnt">
<input type="button" value="Publish" name="" class="cnl_btn">
</div>
</div></div>
<!--Instant task ends here-->

</div>
</div>
<!--Right side content ends here-->


  </div>
 <div class="page-container pagetopmargn">
 
<!--Left side bar start here-->
<div class="leftbar">
<!--Previoue tast start here-->
<div class="box">
<div class="box_topheading"><h3 class="h3">Previous Task</h3></div>
<div class="box2">
<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
<p class="date">Done by : John     21-01-2014</p>
<p><a href="#">View</a></p>
</div>
</div>
</div>
<!--Previoue tast Ends here-->

<!--Template Category start here-->
<div class="box">
<div class="box_topheading"><h3 class="h3">Template Category</h3></div>
<div class="box2">
<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>

<div class="prvlist_box"> <a href="#"><img src="../images/prv_img.jpg"></a>
<p class="title">Handcrafted dining table</p>
</div>
</div>
</div>
<!--Template Category tast Ends here-->

</div>
<!--Left side bar ends here-->

<!--Right side content start here-->
<div class="rightbar">
<div class="box">
<div class="box_topheading"><h3 class="h3">Post your task in just couple of seconds</h3></div>
<!--Which kind of task  start here-->
<!--<div class="controls-row pdn">
<h3 class="h3 bottom_border">Which kind of task </h3>
<div class="tast_box">
    <a href="#" id="loadVirtualTask"><i class="task_icon virtual"></i><p>Virtual Task <span>Anywhere</span></p></a>
</div>
<div class="tast_box">
    <a href="#" id="loadInpersonTask"><i class="task_icon inperson"></i><p>In-person Task <span>At my location</span> </p></a>
</div>
<div class="tast_box active">
            <a href="#" id="loadInstantTask"><i class="task_icon instant"></i><p>Instant Task <span>Need it now</span></p></a>
    </div>
</div>-->


<div class="controls-row pdn">
<div class="span3 nopadding"><h3 class="h3-1">Which kind of task </h3></div>
<div class="tast_box_new">
    <a id="loadVirtualTask" href="#"><i class="task_icon2 virtual2"></i>Virtual Task</a>
</div>

<div class="tast_box_new">
    <a id="loadInpersonTask" href="#"><i class="task_icon2 inperson2"></i>In-person Task</a>
</div>

<div class="tast_box_new">
            <a id="loadInstantTask" href="#"><i class="task_icon2 instant2"></i>Instant Task</a>
    </div>

</div>

<!--Which kind of task  ends here-->

<!--Instant task category start here-->
<div class="controls-row pdn2">
<h3 class="h3 bottom_border">Choose instant task category  </h3>
<div class="controls-row cnl_space">
<div class="task_cat cat_bg1">
<div class="cat_img"><img src="../images/delivery.png"></div>
<p>Delivery</p></div>
<div class="task_cat cat_bg2">
<div class="cat_img"><img src="../images/house.png"></div>
<p>House Cleaning</p></div>
<div class="task_cat cat_bg1">
<div class="cat_img"><img src="../images/computer.png"></div>
<p>Computer Help</p></div>
<div class="task_cat cat_bg2">
<div class="cat_img"><img src="../images/shopping.png"></div>
<p>Shopping</p></div>
<div class="task_cat cat_bg1">
<div class="cat_img"><img src="../images/handyman.png"></div>
<p>Handyman</p></div>
<div class="task_cat cat_bg2">
<div class="cat_img"><img src="../images/research.png"></div>
<p>Research</p></div>
<div class="task_cat cat_bg1">
<div class="cat_img"><img src="../images/office-help.png"></div>
<p>Office Help</p></div>
<div class="task_cat cat_bg2">
<div class="cat_img"><img src="../images/event.png"></div>
<p>Event Help</p></div>
<div class="task_cat cat_bg1">
<div class="cat_img"><img src="../images/packing.png"></div>
<p>Moving & Packing</p></div>
<div class="task_cat cat_bg2">
<div class="cat_img"><img src="../images/others.png"></div>
<p>Other</p></div>
</div>
</div>

<!--Instant task category Ends here-->

<!--Instant task start here-->
<div class="controls-row pdn2">
<div class="cat_border">
<div class="cat_type">
<i class="task_icon2 instant2"></i>Instant Task
    </div>
<div class="cat_heading"><img src="../images/delivery.png">Delivery</div>
<div class="change_cat"><a href="#" class="cat_btn">Change category</a></div>
</div>
<div class="controls-row pdn3">
<div class="step_row">
<div class="step1 active">
<span class="nubr">1</span>Create your task
</div>
<div class="step1"><span class="nubr">2</span>Preview</div>
</div>
<!--Instant task left form part start here-->
<div class="task_boxleft">
<div class="controls-row cnl_space">
<div class="name_ic"><img src="../images/title-ic.png"></div>
<div class="span4 nopadding">
<label class="required">Your task name</label>
<input type="text" value="Enter your task title" id="" name="" class="span4"></div>
<div class="help"><i class="icon-question-sign"></i>
<span class="helpdesk">Help message</span>
</div>
</div>

<div class="controls-row cnl_space">
<div class="name_ic"><img src="../images/dic-ic.png"></div>
<div class="span4 nopadding">
<div class="span2 nopadding"><label class="required">Your task name</label></div>
<div class="browes_temp"><a href="#">Browes your template</a></div>
<div class="span4 nopadding"><textarea name="" class="span4"></textarea></div></div>
<div class="help"><i class="icon-question-sign"></i>
<span class="helpdesk">Help message</span>
</div>
<div class="span4">
<div class="span3 adattach"> <a href="#"><i class="icon-plus-sign"></i>Add Attachment</a></div>
<div class="span2 wordcount2">Remaining characters:965</div>
</div>
</div>

<div class="controls-row cnl_space">
<div class="name_ic"><img src="../images/map-ic.png"></div>
<div class="span4 nopadding">
<label class="required">Need tasker at</label>
<div class="span3 nopadding"><input type="text" class="span3" name="" id="" value="123 Main St., San Francisco, CA"></div>
<div class="startby"><input type="text" class="startby nomargin" name="" id="" value="2mile away">
</div> 
</div>
<div class="help"><i class="icon-question-sign"></i>
<span class="helpdesk">Help message</span>
</div>
</div>

<div class="controls-row cnl_space">
<div class="name_ic"><img src="../images/time_ic.png"></div>
<div class="span4 nopadding">
<label class="required">Finish my task till</label>
<select name="" class="span2">
<option>Select time</option>
</select></div>
<div class="help"><i class="icon-question-sign"></i>
<span class="helpdesk">Help message</span>
</div>
</div>

<div class="controls-row cnl_space">
<div class="name_ic"><img src="../images/card-ic.png"></div>
<div class="span4 nopadding">
<label class="required">I am willing to pay</label>
<div class="span2 nopadding"><input type="text" value="$0" id="" name="" class="span2"></div>
<div class="spanweek"><label class="radio">
<input type="radio" value="" name="">
Fixed price</label></div> 
<div class="span4 nopadding">This task requires <span class="blue_text">$25 </span>– do 
you have <span class="blue_text">$25</span> to use on this 
task?</div>
</div>
<div class="help"><i class="icon-question-sign"></i>
<span class="helpdesk">Help message</span>
</div>
</div>

<div class="controls-row cnl_space">
<div class="name_ic"><img src="../images/vis-ic.png"></div>
<div class="span4 nopadding">
<label class="required">Task Posting Visibility</label>
<div class="span4 nopadding"><label class="radio text">
<input type="radio" value="" name="">
Public-Visible to everyone</label></div> 
<div class="span4 nopadding"><label class="radio text">
<input type="radio" value="" name="">
Private-Only candidates I invite can respond</label></div> </div>
<div class="help"><i class="icon-question-sign"></i>
<span class="helpdesk">Help message</span>
</div>
</div>
</div>
<!--Instant task left form part Ends here-->

<!--Instant task right part start here-->
<div class="task_boxright">
<div class="box_topheading"><h3 class="h3">Need tasker</h3>
</div>
<div class="boxright_in">
<div class="span3 nopadding"><label class="radio text">
<input type="radio" name="" value="">
Do you want to select tasker</label>
<label class="radio text">
<input type="radio" name="" value="">
Auto select by system</label></div>

<!--Instant task right map start here-->
<div class="tasker_map"><img src="../images/map1.jpg"></div>
<!--Instant task right map ends here-->

<!--Instant task right tasker list start here-->
<div class="span3 nopadding">
<div class="tasker_list">
<div class="item_label">
<span class="item_label_text">You hired</span>
</div>
<div class="tasker_row1">
<div class="tasker_col1"><img src="../images/tasker-img.jpg">
<div class="tasker_col3"> <a href="#"><img src="../images/email-ic.png"></a>
  <a href="#"><img src="../images/phone-ic.png"></a>
  <a href="#"><img src="../images/chat-ic.png"></a>
</div>
</div>
<div class="tasker_col2">
<p class="tasker_name"><a href="#">John Smith <span class="tasker_city">NYK</span></a></p>
<p class="tasker_mile">1.5 miles away </p>
<p class="tasker_skill">Skills:  Plumber installation, 
Plumber Maintenance...</p>                  
</div>
</div>
<div class="tasker_row2">
<div class="tasker_col4"><a href="#">10 Reviews</a></div><div class="tasker_col4"><img src="../images/star.png"><img src="../images/star.png"><img src="../images/star.png"></div>
<div class="tasker_col5"><input name="" type="button" value="Invite" class="invite_btn" /></div>
</div>
</div>

<div class="tasker_list">
<div class="item_label">
<span class="item_label_text">You hired</span>
</div>
<div class="tasker_row1">
<div class="tasker_col1"><img src="../images/tasker-img.jpg">
<div class="tasker_col3"> <a href="#"><img src="../images/email-ic.png"></a>
  <a href="#"><img src="../images/phone-ic.png"></a>
  <a href="#"><img src="../images/chat-ic.png"></a>
</div>
</div>
<div class="tasker_col2">
<p class="tasker_name"><a href="#">John Smith <span class="tasker_city">NYK</span></a></p>
<p class="tasker_mile">1.5 miles away </p>
<p class="tasker_skill">Skills:  Plumber installation, 
Plumber Maintenance...</p>                  
</div>
</div>
<div class="tasker_row2">
<div class="tasker_col4"><a href="#">10 Reviews</a></div><div class="tasker_col4"><img src="../images/star.png"><img src="../images/star.png"><img src="../images/star.png"></div>
<div class="tasker_col5"><input name="" type="button" value="Invite" class="invite_btn" /></div>
</div>
</div>

<div class=""><a href="#">View all</a></div>

</div>
<!--Instant task right tasker list ends here-->

</div>
</div>
<!--Instant task right part ends here-->

</div>
<div class="controls-row cnl_space">
<div class="span5 nopad">
<input type="submit" value="Save" name=""  class="sign_bnt">
<input type="button" value="Publish" name="" class="cnl_btn">
</div>
</div></div>
<!--Instant task ends here-->

</div>
</div>
<!--Right side content ends here-->


  </div>
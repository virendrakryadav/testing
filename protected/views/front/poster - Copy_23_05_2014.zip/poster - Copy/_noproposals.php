<div id="loadProposalDiv" class=" positionRelativeClass">
    <?php echo UtilityHtml::getAjaxLoading("loadPreviewTaskLoadingImg") ?>
    <div class="box">
            <div class="box_topheading ">
                <div class="controls-row">
                    <h3 class="h3 pull-left"><?php  echo CHtml::encode(Yii::t('poster_createtask', 'lbl_proposals')); ?></h3>
                </div>
            </div>
    </div>
</div>
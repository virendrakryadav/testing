/**
 * 
 */

$(document).ready(function(){
	$("#addkeywords").click(function(){
		$("#addnewkeywordform").slideToggle("slow");									 
})						   
	$("#cancelkeywords").click(function(){
		$("#addnewkeywordform").slideToggle("slow");									 
})	
	
	
	$("#adddesignerlink").click(function(){
		$("#addnewdesignerform").slideToggle("slow");									 
})						   
	$("#canceldesigner").click(function(){
		$("#addnewdesignerform").slideToggle("slow");									 
})				


	$("#addvideo").click(function(){
		$("#addvideoform").slideToggle("slow");									 
})						   
		$("#canceladdvideo").click(function(){
		$("#addvideoform").slideToggle("slow");									 
})
	
		$("#addimages").click(function(){
		$("#addimagesform").slideToggle("slow");									 
})						   
		$("#canceladdimages").click(function(){
		$("#addimagesform").slideToggle("slow");									 
})

});

var scrollTimer;
function scrollContent(amt)
{
$("#content").scrollTop($("#content").scrollTop()+amt);
scrollTimer = window.setTimeout("scrollContent(" + amt + ")", 25);
}
function onWindowResize()
{
$("#content").height($(window).height() - $("#header").height() - $("#footer").height() - 20);
}
$(document).ready(function ()
{
$("#content").css("overflow", "hidden");
$("#scrollUp").click(function() {
window.clearTimeout(scrollTimer); //Not necessary, but just to be sure...
$("#scrollUp").animate({"opacity": 100}, 'slow');
scrollContent(-80);
});
$("#scrollUp").click(function() {
window.clearTimeout(scrollTimer);
$("#scrollUp").animate({"opacity": 100}, 'slow');
});
$("#scrollDown").click(function() {
window.clearTimeout(scrollTimer); //Not necessary, but just to be sure...
$("#scrollDown").animate({"opacity": 100}, 'slow');
scrollContent(80);
});
$("#scrollDown").click(function() {
window.clearTimeout(scrollTimer);
$("#scrollDown").animate({"opacity": 100}, 'slow');
});
//$("#scrollUp").css("opacity", 0); //Alternative
$("#scrollUp").animate({"opacity": 100}, 'slow');
$("#scrollDown").animate({"opacity": 100}, 'slow');
$(window).resize(onWindowResize);
onWindowResize();
});

$(document).ready(function(){

});

//Add Dynamic image script

function addMore(){ 
var counter=0;
        var counter =  parseInt(document.getElementById("counter").value);
        document.getElementById("counter").value =  counter + 1 ;
        var box = "box"+counter;
        if(counter=='0'){
            document.getElementById("addBox").innerHTML = '';
	
        }
		else if(counter=='9'){
			return null;
			}
		else{
            document.getElementById("addBox"+counter).innerHTML = '';
            document.getElementById("removeBox"+counter).innerHTML = '';	
        }
        var thumbImage = "thumbImage"+counter;
        var bigImage = "bigImage"+counter;
        var counter = counter + 1;	
        var nextBox = "box"+counter;
        var addBox_name = "addBox"+counter;
        var removeBox_name = "removeBox"+counter;
        document.getElementById(box).innerHTML = '<div style="width:100%;"><div style="padding-right:3px; padding-bottom:10px; float:left;">Browse Image -</div><div style="float:left;padding-right:3px; padding-bottom:10px; "><input class="add_brow required" type="file" name="'+bigImage+'" id="'+bigImage+'"></div></div><div style="width:160px; float:left; "><span id="'+removeBox_name+'" style="padding-right:8px; float:left;"><input name="input" type="button" value="Remove" class="removeimgbtn" onClick="return removeBox('+counter+');"/></span><span id="'+addBox_name+'"><input name="input" type="button" value="Add More" class="addmorebtn" onClick="return addMore();"/></span></div>';

        document.getElementById(box).innerHTML += '<div style="clear:both;"></div>';
        document.getElementById(box).innerHTML +=  '<div id="'+nextBox+'"></div>';
        return true;
    }

    function removeBox(c)
    {
        var v = c -1;	
        if(c != '1'){
            var counter =  parseInt(document.getElementById("counter").value);
            document.getElementById("counter").value =  counter - 1 ;
            document.getElementById("addBox"+v).innerHTML = '<input name="input" type="button" value="Add More" class="addmorebtn" onClick="return addMore();"/>';
            document.getElementById("removeBox"+v).innerHTML = '<input name="input" type="button" value="Remove" class="removeimgbtn" onClick="return removeBox('+v+');"/>';
            document.getElementById("addBox"+c).innerHTML = '';
            document.getElementById("removeBox"+c).innerHTML = '';
            var box = "box"+v;	
            document.getElementById(box).innerHTML = ''; 
        } else {
            var counter =  parseInt(document.getElementById("counter").value);
            document.getElementById("counter").value =  counter - 1 ;
            document.getElementById("addBox").innerHTML = '<input name="input" type="button" value="Add More" class="addmorebtn" onClick="return addMore();"/>';
            document.getElementById("addBox"+c).innerHTML = '';
            document.getElementById("removeBox"+c).innerHTML = '';
            var box = "box"+v;	
            document.getElementById(box).innerHTML = ''; 

		
        }
        return false;	
    }
	


function addMorevideo(){ 

		//var countervideo=0;
        countervideo =  parseInt(document.getElementById("countervideo").value);
        document.getElementById("countervideo").value =  countervideo + 1 ;
        var boxvideo = "boxvideo"+countervideo;
		
        if(countervideo=='0'){
            document.getElementById("addBoxVideo").innerHTML = '';
	
        }
		else if(countervideo=='9'){
			return null;
			}
		else{
            document.getElementById("addBoxVideo"+countervideo).innerHTML = '';
            document.getElementById("removeBoxVideo"+countervideo).innerHTML = '';	
        }
		
        var thumbImagevideo = "thumbImagevideo"+countervideo;
		        var countervideo = countervideo + 1;	
        var nextVideoBox = "boxvideo"+countervideo;
        var addBoxVideo_name = "addBoxVideo"+countervideo;
        var removeBoxVideo_name = "removeBoxVideo"+countervideo;
	

        document.getElementById(boxvideo).innerHTML = '<div style="width:100%;"><div style="padding-right:3px; padding-bottom:10px; float:left;">Browse Video -</div><div style="float:left;padding-right:3px; padding-bottom:10px; "><input class="add_brow required" type="file" name="'+thumbImagevideo+'" id="'+thumbImagevideo+'"></div></div><div style="width:160px; float:left; "><span id="'+removeBoxVideo_name+'" style="padding-right:8px; float:left;"><input name="input" type="button" value="Remove" class="removeimgbtn" onClick="return removeBoxVideo('+countervideo+');"/></span><span id="'+addBoxVideo_name+'"><input name="input" type="button" value="Add More" class="addmorebtn" onClick="return addMorevideo();"/></span></div>';

        document.getElementById(boxvideo).innerHTML += '<div style="clear:both;"></div>';
        document.getElementById(boxvideo).innerHTML +=  '<div id="'+nextVideoBox+'"></div>';
        return true;
    }

	  function removeBoxVideo(c)
    {
		
        var v = c -1;	
        if(c != '1'){
			var countervideo =  parseInt(document.getElementById("countervideo").value);
            document.getElementById("countervideo").value =  countervideo - 1 ;
            document.getElementById("addBoxVideo"+v).innerHTML = '<input name="input" type="button" value="Add More" class="addmorebtn" onClick="return addMorevideo();"/>';
            document.getElementById("removeBoxVideo"+v).innerHTML = '<input name="input" type="button" value="Remove" class="removeimgbtn" onClick="return removeBoxVideo('+v+');"/>';
            document.getElementById("addBoxVideo"+c).innerHTML = '';
            document.getElementById("removeBoxVideo"+c).innerHTML = '';
            var boxvideo = "boxvideo"+v;	
            document.getElementById(boxvideo).innerHTML = ''; 
        } else {
            var countervideo =  parseInt(document.getElementById("countervideo").value);
            document.getElementById("countervideo").value =  countervideo - 1 ;
            document.getElementById("addBoxVideo").innerHTML = '<input name="input" type="button" value="Add More" class="addmorebtn" onClick="return addMorevideo();"/>';
            document.getElementById("addBoxVideo"+c).innerHTML = '';
            document.getElementById("removeBoxVideo"+c).innerHTML = '';
            var boxvideo = "boxvideo"+v;	
            document.getElementById(boxvideo).innerHTML = ''; 

		
        }
        return false;	
    }


var rate = new Array(0.28,0.36,0.20,0.41,0.18,1.96,2960.21,27.33,1,9.92);
// Convert a currency input to another currency
function currency_convert(from) {
var from_value = eval('document.currency.cur'+from+'.value');
var base = rate[from];
var curr_value;
//get the total number of currency rate from array by just setting the rate.length
for (i=0; i<rate.length; i++) {
if (i!=from) {
//to round up the currency value to 2 decimal value
curr_value = Math.round(rate[i]*from_value/ base *100)/100;
//pass the rounded up currency value to the correspond textbox and display it
eval('document.currency.cur'+i+'.value = '+ curr_value);
}
}


return true;

}


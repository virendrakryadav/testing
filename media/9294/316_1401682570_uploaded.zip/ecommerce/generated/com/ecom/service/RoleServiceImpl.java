package com.ecom.service;

import com.ecom.dao.FeatureRoleDAO;
import com.ecom.dao.RoleDAO;
import com.ecom.dao.RoleDescDAO;

import com.ecom.domain.FeatureRole;
import com.ecom.domain.Role;
import com.ecom.domain.RoleDesc;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Role entities
 * 
 */

@Service("RoleService")
@Transactional
public class RoleServiceImpl implements RoleService {

	/**
	 * DAO injected by Spring that manages FeatureRole entities
	 * 
	 */
	@Autowired
	private FeatureRoleDAO featureRoleDAO;

	/**
	 * DAO injected by Spring that manages Role entities
	 * 
	 */
	@Autowired
	private RoleDAO roleDAO;

	/**
	 * DAO injected by Spring that manages RoleDesc entities
	 * 
	 */
	@Autowired
	private RoleDescDAO roleDescDAO;

	/**
	 * Instantiates a new RoleServiceImpl.
	 *
	 */
	public RoleServiceImpl() {
	}

	/**
	 * Return all Role entity
	 * 
	 */
	@Transactional
	public List<Role> findAllRoles(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Role>(roleDAO.findAllRoles(startResult, maxRows));
	}

	/**
	 * Save an existing Role entity
	 * 
	 */
	@Transactional
	public void saveRole(Role role) {
		Role existingRole = roleDAO.findRoleByPrimaryKey(role.getRoleId());

		if (existingRole != null) {
			if (existingRole != role) {
				existingRole.setRoleId(role.getRoleId());
				existingRole.setDateAdded(role.getDateAdded());
				existingRole.setDateModified(role.getDateModified());
				existingRole.setStatusId(role.getStatusId());
				existingRole.setStoreId(role.getStoreId());
			}
			role = roleDAO.store(existingRole);
		} else {
			role = roleDAO.store(role);
		}
		roleDAO.flush();
	}

	/**
	 * Return a count of all Role entity
	 * 
	 */
	@Transactional
	public Integer countRoles() {
		return ((Long) roleDAO.createQuerySingleResult("select count(o) from Role o").getSingleResult()).intValue();
	}

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	@Transactional
	public Role deleteRoleFeatureRoles(Integer role_roleId, Integer related_featureroles_featureId, Integer related_featureroles_roleId) {
		FeatureRole related_featureroles = featureRoleDAO.findFeatureRoleByPrimaryKey(related_featureroles_featureId, related_featureroles_roleId, -1, -1);

		Role role = roleDAO.findRoleByPrimaryKey(role_roleId, -1, -1);

		related_featureroles.setRole(null);
		role.getFeatureRoles().remove(related_featureroles);

		featureRoleDAO.remove(related_featureroles);
		featureRoleDAO.flush();

		return role;
	}

	/**
	 * Delete an existing RoleDesc entity
	 * 
	 */
	@Transactional
	public Role deleteRoleRoleDescs(Integer role_roleId, Integer related_roledescs_roleId, Integer related_roledescs_langId) {
		RoleDesc related_roledescs = roleDescDAO.findRoleDescByPrimaryKey(related_roledescs_roleId, related_roledescs_langId, -1, -1);

		Role role = roleDAO.findRoleByPrimaryKey(role_roleId, -1, -1);

		related_roledescs.setRole(null);
		role.getRoleDescs().remove(related_roledescs);

		roleDescDAO.remove(related_roledescs);
		roleDescDAO.flush();

		return role;
	}

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	@Transactional
	public Role saveRoleFeatureRoles(Integer roleId, FeatureRole related_featureroles) {
		Role role = roleDAO.findRoleByPrimaryKey(roleId, -1, -1);
		FeatureRole existingfeatureRoles = featureRoleDAO.findFeatureRoleByPrimaryKey(related_featureroles.getFeatureId(), related_featureroles.getRoleId());

		// copy into the existing record to preserve existing relationships
		if (existingfeatureRoles != null) {
			existingfeatureRoles.setFeatureId(related_featureroles.getFeatureId());
			existingfeatureRoles.setRoleId(related_featureroles.getRoleId());
			existingfeatureRoles.setDateAdded(related_featureroles.getDateAdded());
			existingfeatureRoles.setDateModified(related_featureroles.getDateModified());
			existingfeatureRoles.setStatusId(related_featureroles.getStatusId());
			related_featureroles = existingfeatureRoles;
		}

		related_featureroles.setRole(role);
		role.getFeatureRoles().add(related_featureroles);
		related_featureroles = featureRoleDAO.store(related_featureroles);
		featureRoleDAO.flush();

		role = roleDAO.store(role);
		roleDAO.flush();

		return role;
	}

	/**
	 */
	@Transactional
	public Role findRoleByPrimaryKey(Integer roleId) {
		return roleDAO.findRoleByPrimaryKey(roleId);
	}

	/**
	 * Load an existing Role entity
	 * 
	 */
	@Transactional
	public Set<Role> loadRoles() {
		return roleDAO.findAllRoles();
	}

	/**
	 * Delete an existing Role entity
	 * 
	 */
	@Transactional
	public void deleteRole(Role role) {
		roleDAO.remove(role);
		roleDAO.flush();
	}

	/**
	 * Save an existing RoleDesc entity
	 * 
	 */
	@Transactional
	public Role saveRoleRoleDescs(Integer roleId, RoleDesc related_roledescs) {
		Role role = roleDAO.findRoleByPrimaryKey(roleId, -1, -1);
		RoleDesc existingroleDescs = roleDescDAO.findRoleDescByPrimaryKey(related_roledescs.getRoleId(), related_roledescs.getLangId());

		// copy into the existing record to preserve existing relationships
		if (existingroleDescs != null) {
			existingroleDescs.setRoleId(related_roledescs.getRoleId());
			existingroleDescs.setLangId(related_roledescs.getLangId());
			existingroleDescs.setName(related_roledescs.getName());
			existingroleDescs.setDescription(related_roledescs.getDescription());
			existingroleDescs.setStoreId(related_roledescs.getStoreId());
			related_roledescs = existingroleDescs;
		}

		related_roledescs.setRole(role);
		role.getRoleDescs().add(related_roledescs);
		related_roledescs = roleDescDAO.store(related_roledescs);
		roleDescDAO.flush();

		role = roleDAO.store(role);
		roleDAO.flush();

		return role;
	}
}

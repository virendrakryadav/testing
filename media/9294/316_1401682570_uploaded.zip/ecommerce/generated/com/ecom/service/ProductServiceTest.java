package com.ecom.service;

import com.ecom.domain.Designer;
import com.ecom.domain.Product;
import com.ecom.domain.ProductCustomField;
import com.ecom.domain.ProductCustomFieldVal;
import com.ecom.domain.ProductDesc;
import com.ecom.domain.ProductKeyword;
import com.ecom.domain.ProductMedia;
import com.ecom.domain.Store;

import java.util.List;
import java.util.Set;

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;

import org.springframework.context.ApplicationContext;

import org.springframework.mock.web.MockHttpServletRequest;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.RequestScope;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.SessionScope;

/**
 * Class to run the service as a JUnit test. Each operation in the service is a separate test.
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration(locations = {
		"file:./resources/ecommerce-security-context.xml",
		"file:./resources/ecommerce-service-context.xml",
		"file:./resources/ecommerce-dao-context.xml",
		"file:./resources/ecommerce-web-context.xml" })
@Transactional
public class ProductServiceTest {

	/**
	 * The Spring application context.
	 *
	 */
	@SuppressWarnings("unused")
	private ApplicationContext context;

	/**
	 * The service being tested, injected by Spring.
	 *
	 */
	@Autowired
	protected ProductService service;

	/**
	 * Instantiates a new ProductServiceTest.
	 *
	 */
	public ProductServiceTest() {
		setupRequestContext();
	}

	/**
	 * Operation Unit Test
	 * Save an existing ProductMedia entity
	 * 
	 */
	@Test
	public void saveProductProductMedias() {
		// TODO: JUnit - Populate test inputs for operation: saveProductProductMedias 
		Integer prodId = 0;
		ProductMedia related_productmedias = new com.ecom.domain.ProductMedia();
		Product response = null;
		response = service.saveProductProductMedias(prodId, related_productmedias);
		// TODO: JUnit - Add assertions to test outputs of operation: saveProductProductMedias
	}

	/**
	 * Operation Unit Test
	 * Save an existing Store entity
	 * 
	 */
	@Test
	public void saveProductStore() {
		// TODO: JUnit - Populate test inputs for operation: saveProductStore 
		Integer prodId_1 = 0;
		Store related_store = new com.ecom.domain.Store();
		Product response = null;
		response = service.saveProductStore(prodId_1, related_store);
		// TODO: JUnit - Add assertions to test outputs of operation: saveProductStore
	}

	/**
	 * Operation Unit Test
	 * Delete an existing Product entity
	 * 
	 */
	@Test
	public void deleteProduct() {
		// TODO: JUnit - Populate test inputs for operation: deleteProduct 
		Product product = new com.ecom.domain.Product();
		service.deleteProduct(product);
	}

	/**
	 * Operation Unit Test
	 * Return a count of all Product entity
	 * 
	 */
	@Test
	public void countProducts() {
		Integer response = null;
		response = service.countProducts();
		// TODO: JUnit - Add assertions to test outputs of operation: countProducts
	}

	/**
	 * Operation Unit Test
	 * Delete an existing ProductDesc entity
	 * 
	 */
	@Test
	public void deleteProductProductDescs() {
		// TODO: JUnit - Populate test inputs for operation: deleteProductProductDescs 
		Integer product_prodId = 0;
		Integer related_productdescs_prodId = 0;
		Integer related_productdescs_langId = 0;
		Product response = null;
		response = service.deleteProductProductDescs(product_prodId, related_productdescs_prodId, related_productdescs_langId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteProductProductDescs
	}

	/**
	 * Operation Unit Test
	 * Delete an existing ProductMedia entity
	 * 
	 */
	@Test
	public void deleteProductProductMedias() {
		// TODO: JUnit - Populate test inputs for operation: deleteProductProductMedias 
		Integer product_prodId_1 = 0;
		Integer related_productmedias_prodId = 0;
		Integer related_productmedias_langId = 0;
		Integer related_productmedias_mediaId = 0;
		Product response = null;
		response = service.deleteProductProductMedias(product_prodId_1, related_productmedias_prodId, related_productmedias_langId, related_productmedias_mediaId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteProductProductMedias
	}

	/**
	 * Operation Unit Test
	 * Save an existing ProductCustomField entity
	 * 
	 */
	@Test
	public void saveProductProductCustomFields() {
		// TODO: JUnit - Populate test inputs for operation: saveProductProductCustomFields 
		Integer prodId_2 = 0;
		ProductCustomField related_productcustomfields = new com.ecom.domain.ProductCustomField();
		Product response = null;
		response = service.saveProductProductCustomFields(prodId_2, related_productcustomfields);
		// TODO: JUnit - Add assertions to test outputs of operation: saveProductProductCustomFields
	}

	/**
	 * Operation Unit Test
	 * Delete an existing ProductKeyword entity
	 * 
	 */
	@Test
	public void deleteProductProductKeywords() {
		// TODO: JUnit - Populate test inputs for operation: deleteProductProductKeywords 
		Integer product_prodId_2 = 0;
		Integer related_productkeywords_prodId = 0;
		Integer related_productkeywords_keywordId = 0;
		Product response = null;
		response = service.deleteProductProductKeywords(product_prodId_2, related_productkeywords_prodId, related_productkeywords_keywordId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteProductProductKeywords
	}

	/**
	 * Operation Unit Test
	 * Return all Product entity
	 * 
	 */
	@Test
	public void findAllProducts() {
		// TODO: JUnit - Populate test inputs for operation: findAllProducts 
		Integer startResult = 0;
		Integer maxRows = 0;
		List<Product> response = null;
		response = service.findAllProducts(startResult, maxRows);
		// TODO: JUnit - Add assertions to test outputs of operation: findAllProducts
	}

	/**
	 * Operation Unit Test
	 * Save an existing Designer entity
	 * 
	 */
	@Test
	public void saveProductDesigner() {
		// TODO: JUnit - Populate test inputs for operation: saveProductDesigner 
		Integer prodId_3 = 0;
		Designer related_designer = new com.ecom.domain.Designer();
		Product response = null;
		response = service.saveProductDesigner(prodId_3, related_designer);
		// TODO: JUnit - Add assertions to test outputs of operation: saveProductDesigner
	}

	/**
	 * Operation Unit Test
	 * Delete an existing ProductCustomField entity
	 * 
	 */
	@Test
	public void deleteProductProductCustomFields() {
		// TODO: JUnit - Populate test inputs for operation: deleteProductProductCustomFields 
		Integer product_prodId_3 = 0;
		Integer related_productcustomfields_prodId = 0;
		Integer related_productcustomfields_customFieldId = 0;
		Product response = null;
		response = service.deleteProductProductCustomFields(product_prodId_3, related_productcustomfields_prodId, related_productcustomfields_customFieldId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteProductProductCustomFields
	}

	/**
	 * Operation Unit Test
	 * Save an existing Product entity
	 * 
	 */
	@Test
	public void saveProduct() {
		// TODO: JUnit - Populate test inputs for operation: saveProduct 
		Product product_1 = new com.ecom.domain.Product();
		service.saveProduct(product_1);
	}

	/**
	 * Operation Unit Test
	 * Delete an existing ProductCustomFieldVal entity
	 * 
	 */
	@Test
	public void deleteProductProductCustomFieldVals() {
		// TODO: JUnit - Populate test inputs for operation: deleteProductProductCustomFieldVals 
		Integer product_prodId_4 = 0;
		Integer related_productcustomfieldvals_prodId = 0;
		Integer related_productcustomfieldvals_langId = 0;
		Integer related_productcustomfieldvals_customFieldId = 0;
		Product response = null;
		response = service.deleteProductProductCustomFieldVals(product_prodId_4, related_productcustomfieldvals_prodId, related_productcustomfieldvals_langId, related_productcustomfieldvals_customFieldId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteProductProductCustomFieldVals
	}

	/**
	 * Operation Unit Test
	 * Delete an existing Designer entity
	 * 
	 */
	@Test
	public void deleteProductDesigner() {
		// TODO: JUnit - Populate test inputs for operation: deleteProductDesigner 
		Integer product_prodId_5 = 0;
		Integer related_designer_designerId = 0;
		Product response = null;
		response = service.deleteProductDesigner(product_prodId_5, related_designer_designerId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteProductDesigner
	}

	/**
	 * Operation Unit Test
	 * Save an existing ProductDesc entity
	 * 
	 */
	@Test
	public void saveProductProductDescs() {
		// TODO: JUnit - Populate test inputs for operation: saveProductProductDescs 
		Integer prodId_4 = 0;
		ProductDesc related_productdescs = new com.ecom.domain.ProductDesc();
		Product response = null;
		response = service.saveProductProductDescs(prodId_4, related_productdescs);
		// TODO: JUnit - Add assertions to test outputs of operation: saveProductProductDescs
	}

	/**
	 * Operation Unit Test
	 * Save an existing ProductCustomFieldVal entity
	 * 
	 */
	@Test
	public void saveProductProductCustomFieldVals() {
		// TODO: JUnit - Populate test inputs for operation: saveProductProductCustomFieldVals 
		Integer prodId_5 = 0;
		ProductCustomFieldVal related_productcustomfieldvals = new com.ecom.domain.ProductCustomFieldVal();
		Product response = null;
		response = service.saveProductProductCustomFieldVals(prodId_5, related_productcustomfieldvals);
		// TODO: JUnit - Add assertions to test outputs of operation: saveProductProductCustomFieldVals
	}

	/**
	 * Operation Unit Test
	 * Load an existing Product entity
	 * 
	 */
	@Test
	public void loadProducts() {
		Set<Product> response = null;
		response = service.loadProducts();
		// TODO: JUnit - Add assertions to test outputs of operation: loadProducts
	}

	/**
	 * Operation Unit Test
	 * Delete an existing Store entity
	 * 
	 */
	@Test
	public void deleteProductStore() {
		// TODO: JUnit - Populate test inputs for operation: deleteProductStore 
		Integer product_prodId_6 = 0;
		Integer related_store_storeId = 0;
		Product response = null;
		response = service.deleteProductStore(product_prodId_6, related_store_storeId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteProductStore
	}

	/**
	 * Operation Unit Test
	 * Save an existing ProductKeyword entity
	 * 
	 */
	@Test
	public void saveProductProductKeywords() {
		// TODO: JUnit - Populate test inputs for operation: saveProductProductKeywords 
		Integer prodId_6 = 0;
		ProductKeyword related_productkeywords = new com.ecom.domain.ProductKeyword();
		Product response = null;
		response = service.saveProductProductKeywords(prodId_6, related_productkeywords);
		// TODO: JUnit - Add assertions to test outputs of operation: saveProductProductKeywords
	}

	/**
	 * Operation Unit Test
	 */
	@Test
	public void findProductByPrimaryKey() {
		// TODO: JUnit - Populate test inputs for operation: findProductByPrimaryKey 
		Integer prodId_7 = 0;
		Product response = null;
		response = service.findProductByPrimaryKey(prodId_7);
		// TODO: JUnit - Add assertions to test outputs of operation: findProductByPrimaryKey
	}

	/**
	 * Autowired to set the Spring application context.
	 *
	 */
	@Autowired
	public void setContext(ApplicationContext context) {
		this.context = context;
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("session", new SessionScope());
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("request", new RequestScope());
	}

	/**
	 * Sets Up the Request context
	 *
	 */
	private void setupRequestContext() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		ServletRequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
	}
}

package com.ecom.service;

import com.ecom.domain.KeywordDesc;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for KeywordDesc entities
 * 
 */
public interface KeywordDescService {

	/**
	 */
	public KeywordDesc findKeywordDescByPrimaryKey(Integer keywordId, Integer langId);

	/**
	 * Return all KeywordDesc entity
	 * 
	 */
	public List<KeywordDesc> findAllKeywordDescs(Integer startResult, Integer maxRows);

	/**
	 * Delete an existing KeywordDesc entity
	 * 
	 */
	public void deleteKeywordDesc(KeywordDesc keyworddesc);

	/**
	 * Load an existing KeywordDesc entity
	 * 
	 */
	public Set<KeywordDesc> loadKeywordDescs();

	/**
	 * Save an existing KeywordDesc entity
	 * 
	 */
	public void saveKeywordDesc(KeywordDesc keyworddesc_1);

	/**
	 * Return a count of all KeywordDesc entity
	 * 
	 */
	public Integer countKeywordDescs();
}
package com.ecom.service;

import com.ecom.domain.FeatureRole;
import com.ecom.domain.Role;
import com.ecom.domain.RoleDesc;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for Role entities
 * 
 */
public interface RoleService {

	/**
	 * Return all Role entity
	 * 
	 */
	public List<Role> findAllRoles(Integer startResult, Integer maxRows);

	/**
	 * Save an existing Role entity
	 * 
	 */
	public void saveRole(Role role);

	/**
	 * Return a count of all Role entity
	 * 
	 */
	public Integer countRoles();

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	public Role deleteRoleFeatureRoles(Integer role_roleId, Integer related_featureroles_featureId, Integer related_featureroles_roleId);

	/**
	 * Delete an existing RoleDesc entity
	 * 
	 */
	public Role deleteRoleRoleDescs(Integer role_roleId_1, Integer related_roledescs_roleId, Integer related_roledescs_langId);

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	public Role saveRoleFeatureRoles(Integer roleId, FeatureRole related_featureroles);

	/**
	 */
	public Role findRoleByPrimaryKey(Integer roleId_1);

	/**
	 * Load an existing Role entity
	 * 
	 */
	public Set<Role> loadRoles();

	/**
	 * Delete an existing Role entity
	 * 
	 */
	public void deleteRole(Role role_1);

	/**
	 * Save an existing RoleDesc entity
	 * 
	 */
	public Role saveRoleRoleDescs(Integer roleId_2, RoleDesc related_roledescs);
}
package com.ecom.service;

import com.ecom.dao.ProductDescDAO;

import com.ecom.domain.ProductDesc;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for ProductDesc entities
 * 
 */

@Service("ProductDescService")
@Transactional
public class ProductDescServiceImpl implements ProductDescService {

	/**
	 * DAO injected by Spring that manages ProductDesc entities
	 * 
	 */
	@Autowired
	private ProductDescDAO productDescDAO;

	/**
	 * Instantiates a new ProductDescServiceImpl.
	 *
	 */
	public ProductDescServiceImpl() {
	}

	/**
	 * Save an existing ProductDesc entity
	 * 
	 */
	@Transactional
	public void saveProductDesc(ProductDesc productdesc) {
		ProductDesc existingProductDesc = productDescDAO.findProductDescByPrimaryKey(productdesc.getProdId(), productdesc.getLangId());

		if (existingProductDesc != null) {
			if (existingProductDesc != productdesc) {
				/*
				existingProductDesc.setProdId(productdesc.getProdId());
				existingProductDesc.setLangId(productdesc.getLangId());
				existingProductDesc.setPublicName(productdesc.getPublicName());
				existingProductDesc.setSummary(productdesc.getSummary());
				existingProductDesc.setDescription(productdesc.getDescription());
				existingProductDesc.setUrl(productdesc.getUrl());
				existingProductDesc.setStoreId(productdesc.getStoreId());
				*/
				existingProductDesc.setPublicName(productdesc.getPublicName());
				existingProductDesc.setSummary(productdesc.getSummary());

			}
			productdesc = productDescDAO.store(existingProductDesc);
		} else {
			productdesc = productDescDAO.store(productdesc);
		}
		productDescDAO.flush();
	}

	/**
	 * Return all ProductDesc entity
	 * 
	 */
	@Transactional
	public List<ProductDesc> findAllProductDescs(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<ProductDesc>(productDescDAO.findAllProductDescs(startResult, maxRows));
	}

	/**
	 * Delete an existing ProductDesc entity
	 * 
	 */
	@Transactional
	public void deleteProductDesc(ProductDesc productdesc) {
		productDescDAO.remove(productdesc);
		productDescDAO.flush();
	}

	/**
	 */
	@Transactional
	public ProductDesc findProductDescByPrimaryKey(Integer prodId, Integer langId) {
		return productDescDAO.findProductDescByPrimaryKey(prodId, langId);
	}

	/**
	 * Return a count of all ProductDesc entity
	 * 
	 */
	@Transactional
	public Integer countProductDescs() {
		return ((Long) productDescDAO.createQuerySingleResult("select count(*) from ProductDesc o").getSingleResult()).intValue();
	}

	/**
	 * Load an existing ProductDesc entity
	 * 
	 */
	@Transactional
	public Set<ProductDesc> loadProductDescs() {
		return productDescDAO.findAllProductDescs();
	}
}

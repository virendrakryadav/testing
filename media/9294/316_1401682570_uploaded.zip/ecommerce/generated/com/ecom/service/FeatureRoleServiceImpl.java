package com.ecom.service;

import com.ecom.dao.FeatureRoleDAO;

import com.ecom.domain.FeatureRole;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for FeatureRole entities
 * 
 */

@Service("FeatureRoleService")
@Transactional
public class FeatureRoleServiceImpl implements FeatureRoleService {

	/**
	 * DAO injected by Spring that manages FeatureRole entities
	 * 
	 */
	@Autowired
	private FeatureRoleDAO featureRoleDAO;

	/**
	 * Instantiates a new FeatureRoleServiceImpl.
	 *
	 */
	public FeatureRoleServiceImpl() {
	}

	/**
	 * Return a count of all FeatureRole entity
	 * 
	 */
	@Transactional
	public Integer countFeatureRoles() {
		return ((Long) featureRoleDAO.createQuerySingleResult("select count(*) from FeatureRole o").getSingleResult()).intValue();
	}

	/**
	 * Load an existing FeatureRole entity
	 * 
	 */
	@Transactional
	public Set<FeatureRole> loadFeatureRoles() {
		return featureRoleDAO.findAllFeatureRoles();
	}

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	@Transactional
	public void deleteFeatureRole(FeatureRole featurerole) {
		featureRoleDAO.remove(featurerole);
		featureRoleDAO.flush();
	}

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	@Transactional
	public void saveFeatureRole(FeatureRole featurerole) {
		FeatureRole existingFeatureRole = featureRoleDAO.findFeatureRoleByPrimaryKey(featurerole.getFeatureId(), featurerole.getRoleId());

		if (existingFeatureRole != null) {
			if (existingFeatureRole != featurerole) {
				existingFeatureRole.setFeatureId(featurerole.getFeatureId());
				existingFeatureRole.setRoleId(featurerole.getRoleId());
				existingFeatureRole.setDateAdded(featurerole.getDateAdded());
				existingFeatureRole.setDateModified(featurerole.getDateModified());
				existingFeatureRole.setStatusId(featurerole.getStatusId());
			}
			featurerole = featureRoleDAO.store(existingFeatureRole);
		} else {
			featurerole = featureRoleDAO.store(featurerole);
		}
		featureRoleDAO.flush();
	}

	/**
	 */
	@Transactional
	public FeatureRole findFeatureRoleByPrimaryKey(Integer featureId, Integer roleId) {
		return featureRoleDAO.findFeatureRoleByPrimaryKey(featureId, roleId);
	}

	/**
	 * Return all FeatureRole entity
	 * 
	 */
	@Transactional
	public List<FeatureRole> findAllFeatureRoles(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<FeatureRole>(featureRoleDAO.findAllFeatureRoles(startResult, maxRows));
	}
}

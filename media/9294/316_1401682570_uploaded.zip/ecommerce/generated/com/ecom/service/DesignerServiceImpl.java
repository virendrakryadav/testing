package com.ecom.service;

import com.ecom.dao.DesignerDAO;

import com.ecom.domain.Designer;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Designer entities
 * 
 */

@Service("DesignerService")
@Transactional
public class DesignerServiceImpl implements DesignerService {

	/**
	 * DAO injected by Spring that manages Designer entities
	 * 
	 */
	@Autowired
	private DesignerDAO designerDAO;

	/**
	 * Instantiates a new DesignerServiceImpl.
	 *
	 */
	public DesignerServiceImpl() {
	}

	/**
	 * Return a count of all Designer entity
	 * 
	 */
	@Transactional
	public Integer countDesigners() {
		return ((Long) designerDAO.createQuerySingleResult("select count(o) from Designer o").getSingleResult()).intValue();
	}

	/**
	 * Return all Designer entity
	 * 
	 */
	@Transactional
	public List<Designer> findAllDesigners(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Designer>(designerDAO.findAllDesigners(startResult, maxRows));
	}

	/**
	 * Delete an existing Designer entity
	 * 
	 */
	@Transactional
	public void deleteDesigner(Designer designer) {
		designerDAO.remove(designer);
		designerDAO.flush();
	}

	/**
	 * Load an existing Designer entity
	 * 
	 */
	@Transactional
	public Set<Designer> loadDesigners() {
		return designerDAO.findAllDesigners();
	}

	/**
	 */
	@Transactional
	public Designer findDesignerByPrimaryKey(Integer designerId) {
		return designerDAO.findDesignerByPrimaryKey(designerId);
	}

	/**
	 * Save an existing Designer entity
	 * 
	 */
	@Transactional
	public void saveDesigner(Designer designer) {
		Designer existingDesigner = designerDAO.findDesignerByPrimaryKey(designer.getDesignerId());

		if (existingDesigner != null) {
			if (existingDesigner != designer) {
				existingDesigner.setDesignerId(designer.getDesignerId());
				existingDesigner.setStoreId(designer.getStoreId());
				existingDesigner.setSortOrder(designer.getSortOrder());
				existingDesigner.setDateAdded(designer.getDateAdded());
				existingDesigner.setDateModified(designer.getDateModified());
				existingDesigner.setStatusId(designer.getStatusId());
			}
			designer = designerDAO.store(existingDesigner);
		} else {
			designer = designerDAO.store(designer);
		}
		designerDAO.flush();
	}
}

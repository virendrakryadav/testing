package com.ecom.service;

import com.ecom.domain.DesignerDesc;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for DesignerDesc entities
 * 
 */
public interface DesignerDescService {

	/**
	 * Return all DesignerDesc entity
	 * 
	 */
	public List<DesignerDesc> findAllDesignerDescs(Integer startResult, Integer maxRows);

	/**
	 * Save an existing DesignerDesc entity
	 * 
	 */
	public void saveDesignerDesc(DesignerDesc designerdesc);

	/**
	 */
	public DesignerDesc findDesignerDescByPrimaryKey(Integer designerId, Integer langId);

	/**
	 * Delete an existing DesignerDesc entity
	 * 
	 */
	public void deleteDesignerDesc(DesignerDesc designerdesc_1);

	/**
	 * Return a count of all DesignerDesc entity
	 * 
	 */
	public Integer countDesignerDescs();

	/**
	 * Load an existing DesignerDesc entity
	 * 
	 */
	public Set<DesignerDesc> loadDesignerDescs();
}
package com.ecom.service;

import com.ecom.dao.AdminUserStoreDAO;

import com.ecom.domain.AdminUserStore;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for AdminUserStore entities
 * 
 */

@Service("AdminUserStoreService")
@Transactional
public class AdminUserStoreServiceImpl implements AdminUserStoreService {

	/**
	 * DAO injected by Spring that manages AdminUserStore entities
	 * 
	 */
	@Autowired
	private AdminUserStoreDAO adminUserStoreDAO;

	/**
	 * Instantiates a new AdminUserStoreServiceImpl.
	 *
	 */
	public AdminUserStoreServiceImpl() {
	}

	/**
	 * Return all AdminUserStore entity
	 * 
	 */
	@Transactional
	public List<AdminUserStore> findAllAdminUserStores(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<AdminUserStore>(adminUserStoreDAO.findAllAdminUserStores(startResult, maxRows));
	}

	/**
	 * Load an existing AdminUserStore entity
	 * 
	 */
	@Transactional
	public Set<AdminUserStore> loadAdminUserStores() {
		return adminUserStoreDAO.findAllAdminUserStores();
	}

	/**
	 */
	@Transactional
	public AdminUserStore findAdminUserStoreByPrimaryKey(Integer adminUserId, Integer storeId) {
		return adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminUserId, storeId);
	}

	/**
	 * Delete an existing AdminUserStore entity
	 * 
	 */
	@Transactional
	public void deleteAdminUserStore(AdminUserStore adminuserstore) {
		adminUserStoreDAO.remove(adminuserstore);
		adminUserStoreDAO.flush();
	}

	/**
	 * Return a count of all AdminUserStore entity
	 * 
	 */
	@Transactional
	public Integer countAdminUserStores() {
		return ((Long) adminUserStoreDAO.createQuerySingleResult("select count(*) from AdminUserStore o").getSingleResult()).intValue();
	}

	/**
	 * Save an existing AdminUserStore entity
	 * 
	 */
	@Transactional
	public void saveAdminUserStore(AdminUserStore adminuserstore) {
		AdminUserStore existingAdminUserStore = adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminuserstore.getAdminUserId(), adminuserstore.getStoreId());

		if (existingAdminUserStore != null) {
			if (existingAdminUserStore != adminuserstore) {
				existingAdminUserStore.setAdminUserId(adminuserstore.getAdminUserId());
				existingAdminUserStore.setStoreId(adminuserstore.getStoreId());
				existingAdminUserStore.setIsDefault(adminuserstore.getIsDefault());
				existingAdminUserStore.setDateAdded(adminuserstore.getDateAdded());
				existingAdminUserStore.setDateModified(adminuserstore.getDateModified());
				existingAdminUserStore.setStatusId(adminuserstore.getStatusId());
			}
			adminuserstore = adminUserStoreDAO.store(existingAdminUserStore);
		} else {
			adminuserstore = adminUserStoreDAO.store(adminuserstore);
		}
		adminUserStoreDAO.flush();
	}
}

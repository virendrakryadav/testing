package com.ecom.service;

import com.ecom.domain.Designer;
import com.ecom.domain.Product;
import com.ecom.domain.ProductCustomField;
import com.ecom.domain.ProductCustomFieldVal;
import com.ecom.domain.ProductDesc;
import com.ecom.domain.ProductKeyword;
import com.ecom.domain.ProductMedia;
import com.ecom.domain.Store;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for Product entities
 * 
 */
public interface ProductService {

	/**
	 * Save an existing ProductMedia entity
	 * 
	 */
	public Product saveProductProductMedias(Integer prodId, ProductMedia related_productmedias);

	/**
	 * Save an existing Store entity
	 * 
	 */
	public Product saveProductStore(Integer prodId_1, Store related_store);

	/**
	 * Delete an existing Product entity
	 * 
	 */
	public void deleteProduct(Product product);

	/**
	 * Return a count of all Product entity
	 * 
	 */
	public Integer countProducts();

	/**
	 * Delete an existing ProductDesc entity
	 * 
	 */
	public Product deleteProductProductDescs(Integer product_prodId, Integer related_productdescs_prodId, Integer related_productdescs_langId);

	/**
	 * Delete an existing ProductMedia entity
	 * 
	 */
	public Product deleteProductProductMedias(Integer product_prodId_1, Integer related_productmedias_prodId, Integer related_productmedias_langId, Integer related_productmedias_mediaId);

	/**
	 * Save an existing ProductCustomField entity
	 * 
	 */
	public Product saveProductProductCustomFields(Integer prodId_2, ProductCustomField related_productcustomfields);

	/**
	 * Delete an existing ProductKeyword entity
	 * 
	 */
	public Product deleteProductProductKeywords(Integer product_prodId_2, Integer related_productkeywords_prodId, Integer related_productkeywords_keywordId);

	/**
	 * Return all Product entity
	 * 
	 */
	public List<Product> findAllProducts(Integer startResult, Integer maxRows);

	/**
	 * Save an existing Designer entity
	 * 
	 */
	public Product saveProductDesigner(Integer prodId_3, Designer related_designer);

	/**
	 * Delete an existing ProductCustomField entity
	 * 
	 */
	public Product deleteProductProductCustomFields(Integer product_prodId_3, Integer related_productcustomfields_prodId, Integer related_productcustomfields_customFieldId);

	
	/**
	 * Save an existing Product entity
	 * 
	 */
	public void saveProductDetails(Product product,ProductDesc productDescription,LinkedHashSet<ProductKeyword> productHashSet);
	
	/**
	 * Save an existing Product entity
	 * 
	 */
	public void saveProduct(Product product_1);

	/**
	 * Delete an existing ProductCustomFieldVal entity
	 * 
	 */
	public Product deleteProductProductCustomFieldVals(Integer product_prodId_4, Integer related_productcustomfieldvals_prodId, Integer related_productcustomfieldvals_langId, Integer related_productcustomfieldvals_customFieldId);

	/**
	 * Delete an existing Designer entity
	 * 
	 */
	public Product deleteProductDesigner(Integer product_prodId_5, Integer related_designer_designerId);

	/**
	 * Save an existing ProductDesc entity
	 * 
	 */
	public Product saveProductProductDescs(Integer prodId_4, ProductDesc related_productdescs);

	/**
	 * Save an existing ProductCustomFieldVal entity
	 * 
	 */
	public Product saveProductProductCustomFieldVals(Integer prodId_5, ProductCustomFieldVal related_productcustomfieldvals);

	/**
	 * Load an existing Product entity
	 * 
	 */
	public Set<Product> loadProducts();

	/**
	 * Delete an existing Store entity
	 * 
	 */
	public Product deleteProductStore(Integer product_prodId_6, Integer related_store_storeId);

	/**
	 * Save an existing ProductKeyword entity
	 * 
	 */
	public Product saveProductProductKeywords(Integer prodId_6, ProductKeyword related_productkeywords);

	/**
	 */
	public Product findProductByPrimaryKey(Integer prodId_7);
}
package com.ecom.service;

import com.ecom.dao.FeatureDAO;
import com.ecom.dao.FeatureDescDAO;
import com.ecom.dao.FeatureRoleDAO;

import com.ecom.domain.Feature;
import com.ecom.domain.FeatureDesc;
import com.ecom.domain.FeatureRole;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Feature entities
 * 
 */

@Service("FeatureService")
@Transactional
public class FeatureServiceImpl implements FeatureService {

	/**
	 * DAO injected by Spring that manages Feature entities
	 * 
	 */
	@Autowired
	private FeatureDAO featureDAO;

	/**
	 * DAO injected by Spring that manages FeatureDesc entities
	 * 
	 */
	@Autowired
	private FeatureDescDAO featureDescDAO;

	/**
	 * DAO injected by Spring that manages FeatureRole entities
	 * 
	 */
	@Autowired
	private FeatureRoleDAO featureRoleDAO;

	/**
	 * Instantiates a new FeatureServiceImpl.
	 *
	 */
	public FeatureServiceImpl() {
	}

	/**
	 * Load an existing Feature entity
	 * 
	 */
	@Transactional
	public Set<Feature> loadFeatures() {
		return featureDAO.findAllFeatures();
	}

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	@Transactional
	public Feature saveFeatureFeatureRoles(Integer featureId, FeatureRole related_featureroles) {
		Feature feature = featureDAO.findFeatureByPrimaryKey(featureId, -1, -1);
		FeatureRole existingfeatureRoles = featureRoleDAO.findFeatureRoleByPrimaryKey(related_featureroles.getFeatureId(), related_featureroles.getRoleId());

		// copy into the existing record to preserve existing relationships
		if (existingfeatureRoles != null) {
			existingfeatureRoles.setFeatureId(related_featureroles.getFeatureId());
			existingfeatureRoles.setRoleId(related_featureroles.getRoleId());
			existingfeatureRoles.setDateAdded(related_featureroles.getDateAdded());
			existingfeatureRoles.setDateModified(related_featureroles.getDateModified());
			existingfeatureRoles.setStatusId(related_featureroles.getStatusId());
			related_featureroles = existingfeatureRoles;
		}

		related_featureroles.setFeature(feature);
		feature.getFeatureRoles().add(related_featureroles);
		related_featureroles = featureRoleDAO.store(related_featureroles);
		featureRoleDAO.flush();

		feature = featureDAO.store(feature);
		featureDAO.flush();

		return feature;
	}

	/**
	 */
	@Transactional
	public Feature findFeatureByPrimaryKey(Integer featureId) {
		return featureDAO.findFeatureByPrimaryKey(featureId);
	}

	/**
	 * Delete an existing FeatureDesc entity
	 * 
	 */
	@Transactional
	public Feature deleteFeatureFeatureDescs(Integer feature_featureId, Integer related_featuredescs_featureId, Integer related_featuredescs_langId) {
		FeatureDesc related_featuredescs = featureDescDAO.findFeatureDescByPrimaryKey(related_featuredescs_featureId, related_featuredescs_langId, -1, -1);

		Feature feature = featureDAO.findFeatureByPrimaryKey(feature_featureId, -1, -1);

		related_featuredescs.setFeature(null);
		feature.getFeatureDescs().remove(related_featuredescs);

		featureDescDAO.remove(related_featuredescs);
		featureDescDAO.flush();

		return feature;
	}

	/**
	 * Return all Feature entity
	 * 
	 */
	@Transactional
	public List<Feature> findAllFeatures(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Feature>(featureDAO.findAllFeatures(startResult, maxRows));
	}

	/**
	 * Save an existing Feature entity
	 * 
	 */
	@Transactional
	public void saveFeature(Feature feature) {
		Feature existingFeature = featureDAO.findFeatureByPrimaryKey(feature.getFeatureId());

		if (existingFeature != null) {
			if (existingFeature != feature) {
				existingFeature.setFeatureId(feature.getFeatureId());
				existingFeature.setInternalName(feature.getInternalName());
				existingFeature.setDateAdded(feature.getDateAdded());
				existingFeature.setDateModified(feature.getDateModified());
				existingFeature.setStatusId(feature.getStatusId());
			}
			feature = featureDAO.store(existingFeature);
		} else {
			feature = featureDAO.store(feature);
		}
		featureDAO.flush();
	}

	/**
	 * Save an existing FeatureDesc entity
	 * 
	 */
	@Transactional
	public Feature saveFeatureFeatureDescs(Integer featureId, FeatureDesc related_featuredescs) {
		Feature feature = featureDAO.findFeatureByPrimaryKey(featureId, -1, -1);
		FeatureDesc existingfeatureDescs = featureDescDAO.findFeatureDescByPrimaryKey(related_featuredescs.getFeatureId(), related_featuredescs.getLangId());

		// copy into the existing record to preserve existing relationships
		if (existingfeatureDescs != null) {
			existingfeatureDescs.setFeatureId(related_featuredescs.getFeatureId());
			existingfeatureDescs.setLangId(related_featuredescs.getLangId());
			existingfeatureDescs.setDescription(related_featuredescs.getDescription());
			existingfeatureDescs.setStoreId(related_featuredescs.getStoreId());
			related_featuredescs = existingfeatureDescs;
		}

		related_featuredescs.setFeature(feature);
		feature.getFeatureDescs().add(related_featuredescs);
		related_featuredescs = featureDescDAO.store(related_featuredescs);
		featureDescDAO.flush();

		feature = featureDAO.store(feature);
		featureDAO.flush();

		return feature;
	}

	/**
	 * Return a count of all Feature entity
	 * 
	 */
	@Transactional
	public Integer countFeatures() {
		return ((Long) featureDAO.createQuerySingleResult("select count(o) from Feature o").getSingleResult()).intValue();
	}

	/**
	 * Delete an existing Feature entity
	 * 
	 */
	@Transactional
	public void deleteFeature(Feature feature) {
		featureDAO.remove(feature);
		featureDAO.flush();
	}

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	@Transactional
	public Feature deleteFeatureFeatureRoles(Integer feature_featureId, Integer related_featureroles_featureId, Integer related_featureroles_roleId) {
		FeatureRole related_featureroles = featureRoleDAO.findFeatureRoleByPrimaryKey(related_featureroles_featureId, related_featureroles_roleId, -1, -1);

		Feature feature = featureDAO.findFeatureByPrimaryKey(feature_featureId, -1, -1);

		related_featureroles.setFeature(null);
		feature.getFeatureRoles().remove(related_featureroles);

		featureRoleDAO.remove(related_featureroles);
		featureRoleDAO.flush();

		return feature;
	}
}

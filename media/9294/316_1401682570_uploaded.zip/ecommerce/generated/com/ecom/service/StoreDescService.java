package com.ecom.service;

import com.ecom.domain.StoreDesc;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for StoreDesc entities
 * 
 */
public interface StoreDescService {

	/**
	 * Return all StoreDesc entity
	 * 
	 */
	public List<StoreDesc> findAllStoreDescs(Integer startResult, Integer maxRows);

	/**
	 * Save an existing StoreDesc entity
	 * 
	 */
	public void saveStoreDesc(StoreDesc storedesc);

	/**
	 * Load an existing StoreDesc entity
	 * 
	 */
	public Set<StoreDesc> loadStoreDescs();

	/**
	 */
	public StoreDesc findStoreDescByPrimaryKey(Integer storeId, Integer langId);

	/**
	 * Delete an existing StoreDesc entity
	 * 
	 */
	public void deleteStoreDesc(StoreDesc storedesc_1);

	/**
	 * Return a count of all StoreDesc entity
	 * 
	 */
	public Integer countStoreDescs();
}
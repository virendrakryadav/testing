package com.ecom.service;

import com.ecom.domain.AdminUserStore;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for AdminUserStore entities
 * 
 */
public interface AdminUserStoreService {

	/**
	 * Return all AdminUserStore entity
	 * 
	 */
	public List<AdminUserStore> findAllAdminUserStores(Integer startResult, Integer maxRows);

	/**
	 * Load an existing AdminUserStore entity
	 * 
	 */
	public Set<AdminUserStore> loadAdminUserStores();

	/**
	 */
	public AdminUserStore findAdminUserStoreByPrimaryKey(Integer adminUserId, Integer storeId);

	/**
	 * Delete an existing AdminUserStore entity
	 * 
	 */
	public void deleteAdminUserStore(AdminUserStore adminuserstore);

	/**
	 * Return a count of all AdminUserStore entity
	 * 
	 */
	public Integer countAdminUserStores();

	/**
	 * Save an existing AdminUserStore entity
	 * 
	 */
	public void saveAdminUserStore(AdminUserStore adminuserstore_1);
}
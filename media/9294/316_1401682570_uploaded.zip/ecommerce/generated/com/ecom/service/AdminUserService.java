package com.ecom.service;

import com.ecom.domain.AdminUser;
import com.ecom.domain.AdminUserStore;
import com.ecom.domain.Role;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

/**
 * Spring service that handles CRUD requests for AdminUser entities
 * 
 */
public interface AdminUserService {

	/**
	 * Delete an existing AdminUser entity
	 * 
	 */
	public void deleteAdminUser(AdminUser adminuser);

	/**
	 * Save an existing AdminUserStore entity
	 * 
	 */
	public AdminUser saveAdminUserAdminUserStores(Integer userId, AdminUserStore related_adminuserstores);

	/**
	 * Save an existing Role entity
	 * 
	 */
	public AdminUser saveAdminUserRole(Integer userId_1, Role related_role);

	/**
	 * Delete an existing AdminUserStore entity
	 * 
	 */
	public AdminUser deleteAdminUserAdminUserStores(Integer adminuser_userId, Integer related_adminuserstores_adminUserId, Integer related_adminuserstores_storeId);

	/**
	 * Return a count of all AdminUser entity
	 * 
	 */
	public Integer countAdminUsers();

	/**
	 * Return all AdminUser entity
	 * 
	 */
	public List<AdminUser> findAllAdminUsers(Integer startResult, Integer maxRows);

	/**
	 */
	public AdminUser findAdminUserByPrimaryKey(Integer userId_2);

	/**
	 * Delete an existing Role entity
	 * 
	 */
	public AdminUser deleteAdminUserRole(Integer adminuser_userId_1, Integer related_role_roleId);

	/**
	 * Save an existing AdminUser entity
	 * 
	 */
	public void saveAdminUser(AdminUser adminuser_1);

	/**
	 * Load an existing AdminUser entity
	 * 
	 */
	public Set<AdminUser> loadAdminUsers();
	
	public boolean validateAdminUsers(String name, String pswd, HttpServletRequest request);
}
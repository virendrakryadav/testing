package com.ecom.service;

import com.ecom.domain.AdminUser;
import com.ecom.domain.AdminUserStore;
import com.ecom.domain.Role;

import java.util.List;
import java.util.Set;

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;

import org.springframework.context.ApplicationContext;

import org.springframework.mock.web.MockHttpServletRequest;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.RequestScope;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.SessionScope;

/**
 * Class to run the service as a JUnit test. Each operation in the service is a separate test.
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration(locations = {
		"file:./resources/ecommerce-security-context.xml",
		"file:./resources/ecommerce-service-context.xml",
		"file:./resources/ecommerce-dao-context.xml",
		"file:./resources/ecommerce-web-context.xml" })
@Transactional
public class AdminUserServiceTest {

	/**
	 * The Spring application context.
	 *
	 */
	@SuppressWarnings("unused")
	private ApplicationContext context;

	/**
	 * The service being tested, injected by Spring.
	 *
	 */
	@Autowired
	protected AdminUserService service;

	/**
	 * Instantiates a new AdminUserServiceTest.
	 *
	 */
	public AdminUserServiceTest() {
		setupRequestContext();
	}

	/**
	 * Operation Unit Test
	 * Delete an existing AdminUser entity
	 * 
	 */
	@Test
	public void deleteAdminUser() {
		// TODO: JUnit - Populate test inputs for operation: deleteAdminUser 
		AdminUser adminuser = new com.ecom.domain.AdminUser();
		service.deleteAdminUser(adminuser);
	}

	/**
	 * Operation Unit Test
	 * Save an existing AdminUserStore entity
	 * 
	 */
	@Test
	public void saveAdminUserAdminUserStores() {
		// TODO: JUnit - Populate test inputs for operation: saveAdminUserAdminUserStores 
		Integer userId = 0;
		AdminUserStore related_adminuserstores = new com.ecom.domain.AdminUserStore();
		AdminUser response = null;
		response = service.saveAdminUserAdminUserStores(userId, related_adminuserstores);
		// TODO: JUnit - Add assertions to test outputs of operation: saveAdminUserAdminUserStores
	}

	/**
	 * Operation Unit Test
	 * Save an existing Role entity
	 * 
	 */
	@Test
	public void saveAdminUserRole() {
		// TODO: JUnit - Populate test inputs for operation: saveAdminUserRole 
		Integer userId_1 = 0;
		Role related_role = new com.ecom.domain.Role();
		AdminUser response = null;
		response = service.saveAdminUserRole(userId_1, related_role);
		// TODO: JUnit - Add assertions to test outputs of operation: saveAdminUserRole
	}

	/**
	 * Operation Unit Test
	 * Delete an existing AdminUserStore entity
	 * 
	 */
	@Test
	public void deleteAdminUserAdminUserStores() {
		// TODO: JUnit - Populate test inputs for operation: deleteAdminUserAdminUserStores 
		Integer adminuser_userId = 0;
		Integer related_adminuserstores_adminUserId = 0;
		Integer related_adminuserstores_storeId = 0;
		AdminUser response = null;
		response = service.deleteAdminUserAdminUserStores(adminuser_userId, related_adminuserstores_adminUserId, related_adminuserstores_storeId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteAdminUserAdminUserStores
	}

	/**
	 * Operation Unit Test
	 * Return a count of all AdminUser entity
	 * 
	 */
	@Test
	public void countAdminUsers() {
		Integer response = null;
		response = service.countAdminUsers();
		// TODO: JUnit - Add assertions to test outputs of operation: countAdminUsers
	}

	/**
	 * Operation Unit Test
	 * Return all AdminUser entity
	 * 
	 */
	@Test
	public void findAllAdminUsers() {
		// TODO: JUnit - Populate test inputs for operation: findAllAdminUsers 
		Integer startResult = 0;
		Integer maxRows = 0;
		List<AdminUser> response = null;
		response = service.findAllAdminUsers(startResult, maxRows);
		// TODO: JUnit - Add assertions to test outputs of operation: findAllAdminUsers
	}

	/**
	 * Operation Unit Test
	 */
	@Test
	public void findAdminUserByPrimaryKey() {
		// TODO: JUnit - Populate test inputs for operation: findAdminUserByPrimaryKey 
		Integer userId_2 = 0;
		AdminUser response = null;
		response = service.findAdminUserByPrimaryKey(userId_2);
		// TODO: JUnit - Add assertions to test outputs of operation: findAdminUserByPrimaryKey
	}

	/**
	 * Operation Unit Test
	 * Delete an existing Role entity
	 * 
	 */
	@Test
	public void deleteAdminUserRole() {
		// TODO: JUnit - Populate test inputs for operation: deleteAdminUserRole 
		Integer adminuser_userId_1 = 0;
		Integer related_role_roleId = 0;
		AdminUser response = null;
		response = service.deleteAdminUserRole(adminuser_userId_1, related_role_roleId);
		// TODO: JUnit - Add assertions to test outputs of operation: deleteAdminUserRole
	}

	/**
	 * Operation Unit Test
	 * Save an existing AdminUser entity
	 * 
	 */
	@Test
	public void saveAdminUser() {
		// TODO: JUnit - Populate test inputs for operation: saveAdminUser 
		AdminUser adminuser_1 = new com.ecom.domain.AdminUser();
		service.saveAdminUser(adminuser_1);
	}

	/**
	 * Operation Unit Test
	 * Load an existing AdminUser entity
	 * 
	 */
	@Test
	public void loadAdminUsers() {
		Set<AdminUser> response = null;
		response = service.loadAdminUsers();
		// TODO: JUnit - Add assertions to test outputs of operation: loadAdminUsers
	}

	/**
	 * Autowired to set the Spring application context.
	 *
	 */
	@Autowired
	public void setContext(ApplicationContext context) {
		this.context = context;
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("session", new SessionScope());
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("request", new RequestScope());
	}

	/**
	 * Sets Up the Request context
	 *
	 */
	private void setupRequestContext() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		ServletRequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
	}
}

package com.ecom.service;

import com.ecom.dao.ProductKeywordDAO;

import com.ecom.domain.ProductKeyword;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for ProductKeyword entities
 * 
 */

@Service("ProductKeywordService")
@Transactional
public class ProductKeywordServiceImpl implements ProductKeywordService {

	/**
	 * DAO injected by Spring that manages ProductKeyword entities
	 * 
	 */
	@Autowired
	private ProductKeywordDAO productKeywordDAO;

	/**
	 * Instantiates a new ProductKeywordServiceImpl.
	 *
	 */
	public ProductKeywordServiceImpl() {
	}

	/**
	 * Return a count of all ProductKeyword entity
	 * 
	 */
	@Transactional
	public Integer countProductKeywords() {
		return ((Long) productKeywordDAO.createQuerySingleResult("select count(*) from ProductKeyword o").getSingleResult()).intValue();
	}

	/**
	 * Save an existing ProductKeyword entity
	 * 
	 */
	@Transactional
	public void saveProductKeyword(ProductKeyword productkeyword) {
		ProductKeyword existingProductKeyword = productKeywordDAO.findProductKeywordByPrimaryKey(productkeyword.getProdId(), productkeyword.getKeywordId());

		if (existingProductKeyword != null) {
			if (existingProductKeyword != productkeyword) {
				existingProductKeyword.setProdId(productkeyword.getProdId());
				existingProductKeyword.setKeywordId(productkeyword.getKeywordId());
				existingProductKeyword.setKeywordWeight(productkeyword.getKeywordWeight());
				existingProductKeyword.setStoreId(productkeyword.getStoreId());
			}
			productkeyword = productKeywordDAO.store(existingProductKeyword);
		} else {
			productkeyword = productKeywordDAO.store(productkeyword);
		}
		productKeywordDAO.flush();
	}

	/**
	 * Delete an existing ProductKeyword entity
	 * 
	 */
	@Transactional
	public void deleteProductKeyword(ProductKeyword productkeyword) {
		productKeywordDAO.remove(productkeyword);
		productKeywordDAO.flush();
	}

	/**
	 * Load an existing ProductKeyword entity
	 * 
	 */
	@Transactional
	public Set<ProductKeyword> loadProductKeywords() {
		return productKeywordDAO.findAllProductKeywords();
	}

	/**
	 */
	@Transactional
	public ProductKeyword findProductKeywordByPrimaryKey(Integer prodId, Integer keywordId) {
		return productKeywordDAO.findProductKeywordByPrimaryKey(prodId, keywordId);
	}

	/**
	 * Return all ProductKeyword entity
	 * 
	 */
	@Transactional
	public List<ProductKeyword> findAllProductKeywords(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<ProductKeyword>(productKeywordDAO.findAllProductKeywords(startResult, maxRows));
	}
}

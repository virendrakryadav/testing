package com.ecom.service;

import com.ecom.domain.Designer;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for Designer entities
 * 
 */
public interface DesignerService {

	/**
	 * Return a count of all Designer entity
	 * 
	 */
	public Integer countDesigners();

	/**
	 * Return all Designer entity
	 * 
	 */
	public List<Designer> findAllDesigners(Integer startResult, Integer maxRows);

	/**
	 * Delete an existing Designer entity
	 * 
	 */
	public void deleteDesigner(Designer designer);

	/**
	 * Load an existing Designer entity
	 * 
	 */
	public Set<Designer> loadDesigners();

	/**
	 */
	public Designer findDesignerByPrimaryKey(Integer designerId);

	/**
	 * Save an existing Designer entity
	 * 
	 */
	public void saveDesigner(Designer designer_1);
}
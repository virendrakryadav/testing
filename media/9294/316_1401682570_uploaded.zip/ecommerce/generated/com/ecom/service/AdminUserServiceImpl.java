package com.ecom.service;

import com.ecom.dao.AdminUserDAO;
import com.ecom.dao.AdminUserStoreDAO;
import com.ecom.dao.LanguageDAO;
import com.ecom.dao.RoleDAO;
import com.ecom.dao.StoreDAO;
import com.ecom.dao.StoreDescDAO;

import com.ecom.domain.AdminUser;
import com.ecom.domain.AdminUserStore;
import com.ecom.domain.Role;
import com.ecom.session.UserSessionInfo;
import com.ecom.utils.ConfigAdminPortal;
import com.ecom.utils.Crypto;
import com.ecom.utils.Permissions;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for AdminUser entities
 * 
 */

@Service("AdminUserService")
@Transactional
public class AdminUserServiceImpl implements AdminUserService {

	/**
	 * DAO injected by Spring that manages AdminUser entities
	 * 
	 */
	@Autowired
	private AdminUserDAO adminUserDAO;

	/**
	 * DAO injected by Spring that manages AdminUserStore entities
	 * 
	 */
	@Autowired
	private AdminUserStoreDAO adminUserStoreDAO;

	/**
	 * DAO injected by Spring that manages Role entities
	 * 
	 */
	@Autowired
	private RoleDAO roleDAO;

	/**
	 * DAO injected by Spring that manages Language entities
	 * 
	 */
	@Autowired
	private LanguageDAO langDAO;

	/**
	 * DAO injected by Spring that manages StoreDesc entities
	 * 
	 */
	@Autowired
	private StoreDescDAO storeDescDAO;

	/**
	 * Instantiates a new AdminUserServiceImpl.
	 *
	 */
	public AdminUserServiceImpl() {
	}

	/**
	 * Delete an existing AdminUser entity
	 * 
	 */
	@Transactional
	public void deleteAdminUser(AdminUser adminuser) {
		adminUserDAO.remove(adminuser);
		adminUserDAO.flush();
	}

	/**
	 * Save an existing AdminUserStore entity
	 * 
	 */
	@Transactional
	public AdminUser saveAdminUserAdminUserStores(Integer userId, AdminUserStore related_adminuserstores) {
		AdminUser adminuser = adminUserDAO.findAdminUserByPrimaryKey(userId, -1, -1);
		AdminUserStore existingadminUserStores = adminUserStoreDAO.findAdminUserStoreByPrimaryKey(related_adminuserstores.getAdminUserId(), related_adminuserstores.getStoreId());

		// copy into the existing record to preserve existing relationships
		if (existingadminUserStores != null) {
			existingadminUserStores.setAdminUserId(related_adminuserstores.getAdminUserId());
			existingadminUserStores.setStoreId(related_adminuserstores.getStoreId());
			existingadminUserStores.setIsDefault(related_adminuserstores.getIsDefault());
			existingadminUserStores.setDateAdded(related_adminuserstores.getDateAdded());
			existingadminUserStores.setDateModified(related_adminuserstores.getDateModified());
			existingadminUserStores.setStatusId(related_adminuserstores.getStatusId());
			related_adminuserstores = existingadminUserStores;
		}

//		related_adminuserstores.setAdminUser(adminuser);
		adminuser.getAdminUserStores().add(related_adminuserstores);
		related_adminuserstores = adminUserStoreDAO.store(related_adminuserstores);
		adminUserStoreDAO.flush();

		adminuser = adminUserDAO.store(adminuser);
		adminUserDAO.flush();

		return adminuser;
	}

	/**
	 * Save an existing Role entity
	 * 
	 */
	@Transactional
	public AdminUser saveAdminUserRole(Integer userId, Role related_role) {
		AdminUser adminuser = adminUserDAO.findAdminUserByPrimaryKey(userId, -1, -1);
		Role existingrole = roleDAO.findRoleByPrimaryKey(related_role.getRoleId());

		// copy into the existing record to preserve existing relationships
		if (existingrole != null) {
			existingrole.setRoleId(related_role.getRoleId());
			existingrole.setDateAdded(related_role.getDateAdded());
			existingrole.setDateModified(related_role.getDateModified());
			existingrole.setStatusId(related_role.getStatusId());
			related_role = existingrole;
		} else {
			related_role = roleDAO.store(related_role);
			roleDAO.flush();
		}

		adminuser.setRole(related_role);
		related_role.getAdminUsers().add(adminuser);
		adminuser = adminUserDAO.store(adminuser);
		adminUserDAO.flush();

		related_role = roleDAO.store(related_role);
		roleDAO.flush();

		return adminuser;
	}

	/**
	 * Delete an existing AdminUserStore entity
	 * 
	 */
	@Transactional
	public AdminUser deleteAdminUserAdminUserStores(Integer adminuser_userId, Integer related_adminuserstores_adminUserId, Integer related_adminuserstores_storeId) {
		AdminUserStore related_adminuserstores = adminUserStoreDAO.findAdminUserStoreByPrimaryKey(related_adminuserstores_adminUserId, related_adminuserstores_storeId, -1, -1);

		AdminUser adminuser = adminUserDAO.findAdminUserByPrimaryKey(adminuser_userId, -1, -1);

//		related_adminuserstores.setAdminUser(null);
		adminuser.getAdminUserStores().remove(related_adminuserstores);

		adminUserStoreDAO.remove(related_adminuserstores);
		adminUserStoreDAO.flush();

		return adminuser;
	}

	/**
	 * Return a count of all AdminUser entity
	 * 
	 */
	@Transactional
	public Integer countAdminUsers() {
		return ((Long) adminUserDAO.createQuerySingleResult("select count(o) from AdminUser o").getSingleResult()).intValue();
	}

	/**
	 * Return all AdminUser entity
	 * 
	 */
	@Transactional
	public List<AdminUser> findAllAdminUsers(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<AdminUser>(adminUserDAO.findAllAdminUsers(startResult, maxRows));
	}

	/**
	 */
	@Transactional
	public AdminUser findAdminUserByPrimaryKey(Integer userId) {
		return adminUserDAO.findAdminUserByPrimaryKey(userId);
	}

	/**
	 * Delete an existing Role entity
	 * 
	 */
	@Transactional
	public AdminUser deleteAdminUserRole(Integer adminuser_userId, Integer related_role_roleId) {
		AdminUser adminuser = adminUserDAO.findAdminUserByPrimaryKey(adminuser_userId, -1, -1);
		Role related_role = roleDAO.findRoleByPrimaryKey(related_role_roleId, -1, -1);

		adminuser.setRole(null);
		related_role.getAdminUsers().remove(adminuser);
		adminuser = adminUserDAO.store(adminuser);
		adminUserDAO.flush();

		related_role = roleDAO.store(related_role);
		roleDAO.flush();

		roleDAO.remove(related_role);
		roleDAO.flush();

		return adminuser;
	}

	/**
	 * Save an existing AdminUser entity
	 * 
	 */
	@Transactional
	public void saveAdminUser(AdminUser adminuser) {
		AdminUser existingAdminUser = adminUserDAO.findAdminUserByPrimaryKey(adminuser.getUserId());

		if (existingAdminUser != null) {
			if (existingAdminUser != adminuser) {
				existingAdminUser.setUserId(adminuser.getUserId());
				existingAdminUser.setName(adminuser.getName());
				if (existingAdminUser.getPassword() != adminuser.getPassword())//password changed
				{
					existingAdminUser.setPassword(Crypto.encrypt(adminuser.getPassword(),
						                                     ConfigAdminPortal.getPWDEncriptionKey()));
				}
				existingAdminUser.setEmail(adminuser.getEmail());
				existingAdminUser.setDateAdded(adminuser.getDateAdded());
				existingAdminUser.setLastLoginDate(adminuser.getLastLoginDate());
				existingAdminUser.setLangId(adminuser.getLangId());
				existingAdminUser.setStatusId(adminuser.getStatusId());
			}
			adminuser = adminUserDAO.store(existingAdminUser);
		} else {
			adminuser.setPassword(Crypto.encrypt(adminuser.getPassword(),
                    				ConfigAdminPortal.getPWDEncriptionKey()));
			adminuser = adminUserDAO.store(adminuser);
		}
		adminUserDAO.flush();
	}

	/**
	 * Load an existing AdminUser entity
	 * 
	 */
	@Transactional
	public Set<AdminUser> loadAdminUsers() {
		return adminUserDAO.findAllAdminUsers();
	}
	
	@Override
	public boolean validateAdminUsers(String userName, String pswd, HttpServletRequest request) {
//		System.out.println("userName "+userName);
		Set <AdminUser> adminUserSet=adminUserDAO.findAdminUserByName(userName);
		if(adminUserSet==null || adminUserSet.isEmpty() ){
			return false;
		}else{
			Iterator<AdminUser> it=adminUserSet.iterator();
			AdminUser adus=it.next();
			
			String storedPwd = Crypto.decrypt(adus.getPassword(), ConfigAdminPortal.getPWDEncriptionKey());
//			System.out.println("adus.getPassword() "+storedPwd);
			if (storedPwd == null)
				storedPwd = "";
			if(storedPwd.equals(pswd))
			{
				HttpSession session = request.getSession(true);				
				UserSessionInfo userSessionInfo = new UserSessionInfo();			
				session.setAttribute(UserSessionInfo.USER_SESSION_INFO_KEY, userSessionInfo);
				userSessionInfo.adminUser = adus;
				userSessionInfo.permissions = new Permissions(adus.getRole().getRoleId());
				userSessionInfo.currentLang = langDAO.findLanguageByPrimaryKey(adus.getLangId());
				userSessionInfo.currentStoreDesc = null;
				Set<AdminUserStore> stores = adminUserStoreDAO.findAdminUserStoreByAdminUserId(adus.getUserId());
				if (stores != null)
				{
					for (AdminUserStore store : stores)
					{
						if (store.getIsDefault() != null && store.getIsDefault() == true)
						{
							userSessionInfo.currentStoreDesc = storeDescDAO.findStoreDescByPrimaryKey(
																            store.getStoreId(),adus.getLangId());
							break;							
						}
					}
				}
				return true;
			}else{
				return false;
			}
		}
	}	
}

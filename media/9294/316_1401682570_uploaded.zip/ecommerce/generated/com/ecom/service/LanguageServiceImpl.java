package com.ecom.service;

import com.ecom.dao.LanguageDAO;

import com.ecom.domain.Language;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Language entities
 * 
 */

@Service("LanguageService")
@Transactional
public class LanguageServiceImpl implements LanguageService {

	/**
	 * DAO injected by Spring that manages Language entities
	 * 
	 */
	@Autowired
	private LanguageDAO languageDAO;

	/**
	 * Instantiates a new LanguageServiceImpl.
	 *
	 */
	public LanguageServiceImpl() {
	}

	/**
	 * Save an existing Language entity
	 * 
	 */
	@Transactional
	public void saveLanguage(Language language) {
		Language existingLanguage = languageDAO.findLanguageByPrimaryKey(language.getLangId());

		if (existingLanguage != null) {
			if (existingLanguage != language) {
				existingLanguage.setLangId(language.getLangId());
				existingLanguage.setName(language.getName());
				existingLanguage.setCode(language.getCode());
				existingLanguage.setImageLocation(language.getImageLocation());
				existingLanguage.setDirectory(language.getDirectory());
				existingLanguage.setSortOrder(language.getSortOrder());
				existingLanguage.setLocale(language.getLocale());
				existingLanguage.setDateAdded(language.getDateAdded());
				existingLanguage.setDateModified(language.getDateModified());
				existingLanguage.setStatusId(language.getStatusId());
			}
			language = languageDAO.store(existingLanguage);
		} else {
			language = languageDAO.store(language);
		}
		languageDAO.flush();
	}

	/**
	 * Return a count of all Language entity
	 * 
	 */
	@Transactional
	public Integer countLanguages() {
		return ((Long) languageDAO.createQuerySingleResult("select count(o) from Language o").getSingleResult()).intValue();
	}

	/**
	 * Delete an existing Language entity
	 * 
	 */
	@Transactional
	public void deleteLanguage(Language language) {
		languageDAO.remove(language);
		languageDAO.flush();
	}

	/**
	 * Load an existing Language entity
	 * 
	 */
	@Transactional
	public Set<Language> loadLanguages() {
		return languageDAO.findAllLanguages();
	}

	/**
	 */
	@Transactional
	public Language findLanguageByPrimaryKey(Integer langId) {
		return languageDAO.findLanguageByPrimaryKey(langId);
	}

	/**
	 * Return all Language entity
	 * 
	 */
	@Transactional
	public List<Language> findAllLanguages(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Language>(languageDAO.findAllLanguages(startResult, maxRows));
	}
}

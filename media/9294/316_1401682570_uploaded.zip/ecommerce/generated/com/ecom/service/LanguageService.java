package com.ecom.service;

import com.ecom.domain.Language;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for Language entities
 * 
 */
public interface LanguageService {

	/**
	 * Save an existing Language entity
	 * 
	 */
	public void saveLanguage(Language language);

	/**
	 * Return a count of all Language entity
	 * 
	 */
	public Integer countLanguages();

	/**
	 * Delete an existing Language entity
	 * 
	 */
	public void deleteLanguage(Language language_1);

	/**
	 * Load an existing Language entity
	 * 
	 */
	public Set<Language> loadLanguages();

	/**
	 */
	public Language findLanguageByPrimaryKey(Integer langId);

	/**
	 * Return all Language entity
	 * 
	 */
	public List<Language> findAllLanguages(Integer startResult, Integer maxRows);
}
package com.ecom.service;

import com.ecom.domain.ProductKeyword;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for ProductKeyword entities
 * 
 */
public interface ProductKeywordService {

	/**
	 * Return a count of all ProductKeyword entity
	 * 
	 */
	public Integer countProductKeywords();

	/**
	 * Save an existing ProductKeyword entity
	 * 
	 */
	public void saveProductKeyword(ProductKeyword productkeyword);

	/**
	 * Delete an existing ProductKeyword entity
	 * 
	 */
	public void deleteProductKeyword(ProductKeyword productkeyword_1);

	/**
	 * Load an existing ProductKeyword entity
	 * 
	 */
	public Set<ProductKeyword> loadProductKeywords();

	/**
	 */
	public ProductKeyword findProductKeywordByPrimaryKey(Integer prodId, Integer keywordId);

	/**
	 * Return all ProductKeyword entity
	 * 
	 */
	public List<ProductKeyword> findAllProductKeywords(Integer startResult, Integer maxRows);
}
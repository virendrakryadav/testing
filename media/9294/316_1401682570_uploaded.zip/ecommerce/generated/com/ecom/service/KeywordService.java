package com.ecom.service;

import com.ecom.domain.Keyword;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for Keyword entities
 * 
 */
public interface KeywordService {

	/**
	 * Return all Keyword entity
	 * 
	 */
	public List<Keyword> findAllKeywords(Integer startResult, Integer maxRows);

	/**
	 * Load an existing Keyword entity
	 * 
	 */
	public Set<Keyword> loadKeywords();

	/**
	 * Save an existing Keyword entity
	 * 
	 */
	public void saveKeyword(Keyword keyword);

	/**
	 * Return a count of all Keyword entity
	 * 
	 */
	public Integer countKeywords();

	/**
	 */
	public Keyword findKeywordByPrimaryKey(Integer keywordId);

	/**
	 * Delete an existing Keyword entity
	 * 
	 */
	public void deleteKeyword(Keyword keyword_1);
}
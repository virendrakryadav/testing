package com.ecom.service;

import com.ecom.dao.DesignerDAO;
import com.ecom.dao.ProductCustomFieldDAO;
import com.ecom.dao.ProductCustomFieldValDAO;
import com.ecom.dao.ProductDAO;
import com.ecom.dao.ProductDescDAO;
import com.ecom.dao.ProductKeywordDAO;
import com.ecom.dao.ProductMediaDAO;
import com.ecom.dao.StoreDAO;

import com.ecom.domain.Designer;
import com.ecom.domain.Product;
import com.ecom.domain.ProductCustomField;
import com.ecom.domain.ProductCustomFieldVal;
import com.ecom.domain.ProductDesc;
import com.ecom.domain.ProductKeyword;
import com.ecom.domain.ProductMedia;
import com.ecom.domain.Store;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Product entities
 * 
 */

@Service("ProductService")
@Transactional
public class ProductServiceImpl implements ProductService {

	/**
	 * DAO injected by Spring that manages Designer entities
	 * 
	 */
	@Autowired
	private DesignerDAO designerDAO;

	/**
	 * DAO injected by Spring that manages ProductCustomField entities
	 * 
	 */
	@Autowired
	private ProductCustomFieldDAO productCustomFieldDAO;

	/**
	 * DAO injected by Spring that manages ProductCustomFieldVal entities
	 * 
	 */
	@Autowired
	private ProductCustomFieldValDAO productCustomFieldValDAO;

	/**
	 * DAO injected by Spring that manages Product entities
	 * 
	 */
	@Autowired
	private ProductDAO productDAO;

	/**
	 * DAO injected by Spring that manages ProductDesc entities
	 * 
	 */
	@Autowired
	private ProductDescDAO productDescDAO;

	/**
	 * DAO injected by Spring that manages ProductKeyword entities
	 * 
	 */
	@Autowired
	private ProductKeywordDAO productKeywordDAO;

	/**
	 * DAO injected by Spring that manages ProductMedia entities
	 * 
	 */
	@Autowired
	private ProductMediaDAO productMediaDAO;

	/**
	 * DAO injected by Spring that manages Store entities
	 * 
	 */
	@Autowired
	private StoreDAO storeDAO;

	/**
	 * Instantiates a new ProductServiceImpl.
	 *
	 */
	public ProductServiceImpl() {
	}

	/**
	 * Save an existing ProductMedia entity
	 * 
	 */
	@Transactional
	public Product saveProductProductMedias(Integer prodId, ProductMedia related_productmedias) {
		Product product = productDAO.findProductByPrimaryKey(prodId, -1, -1);
		ProductMedia existingproductMedias = productMediaDAO.findProductMediaByPrimaryKey(related_productmedias.getProdId(), related_productmedias.getLangId(), related_productmedias.getMediaId());

		// copy into the existing record to preserve existing relationships
		if (existingproductMedias != null) {
			existingproductMedias.setProdId(related_productmedias.getProdId());
			existingproductMedias.setLangId(related_productmedias.getLangId());
			existingproductMedias.setMediaId(related_productmedias.getMediaId());
			existingproductMedias.setSortOrder(related_productmedias.getSortOrder());
			related_productmedias = existingproductMedias;
		}

		related_productmedias.setProduct(product);
		product.getProductMedias().add(related_productmedias);
		related_productmedias = productMediaDAO.store(related_productmedias);
		productMediaDAO.flush();

		product = productDAO.store(product);
		productDAO.flush();

		return product;
	}

	/**
	 * Save an existing Store entity
	 * 
	 */
	@Transactional
	public Product saveProductStore(Integer prodId, Store related_store) {
		Product product = productDAO.findProductByPrimaryKey(prodId, -1, -1);
		Store existingstore = storeDAO.findStoreByPrimaryKey(related_store.getStoreId());

		// copy into the existing record to preserve existing relationships
		if (existingstore != null) {
			existingstore.setStoreId(related_store.getStoreId());
			existingstore.setInternalName(related_store.getInternalName());
			existingstore.setStoreUrl(related_store.getStoreUrl());
			existingstore.setAdminEmail(related_store.getAdminEmail());
			existingstore.setMaxProducts(related_store.getMaxProducts());
			existingstore.setDateAdded(related_store.getDateAdded());
			existingstore.setDateModified(related_store.getDateModified());
			existingstore.setStatusId(related_store.getStatusId());
			existingstore.setWebsiteId(related_store.getWebsiteId());
			existingstore.setGroupId(related_store.getGroupId());
			related_store = existingstore;
		} else {
			related_store = storeDAO.store(related_store);
			storeDAO.flush();
		}

		product.setStoreId(related_store.getStoreId());
		related_store.getProducts().add(product);
		product = productDAO.store(product);
		productDAO.flush();

		related_store = storeDAO.store(related_store);
		storeDAO.flush();

		return product;
	}

	/**
	 * Delete an existing Product entity
	 * 
	 */
	@Transactional
	public void deleteProduct(Product product) {
		productDAO.remove(product);
		productDAO.flush();
	}

	/**
	 * Return a count of all Product entity
	 * 
	 */
	@Transactional
	public Integer countProducts() {
		return ((Long) productDAO.createQuerySingleResult("select count(o) from Product o").getSingleResult()).intValue();
	}

	/**
	 * Delete an existing ProductDesc entity
	 * 
	 */
	@Transactional
	public Product deleteProductProductDescs(Integer product_prodId, Integer related_productdescs_prodId, Integer related_productdescs_langId) {
		ProductDesc related_productdescs = productDescDAO.findProductDescByPrimaryKey(related_productdescs_prodId, related_productdescs_langId, -1, -1);

		Product product = productDAO.findProductByPrimaryKey(product_prodId, -1, -1);

		//related_productdescs.setProduct(null);
		product.getProductDescs().remove(related_productdescs);

		productDescDAO.remove(related_productdescs);
		productDescDAO.flush();

		return product;
	}

	/**
	 * Delete an existing ProductMedia entity
	 * 
	 */
	@Transactional
	public Product deleteProductProductMedias(Integer product_prodId, Integer related_productmedias_prodId, Integer related_productmedias_langId, Integer related_productmedias_mediaId) {
		ProductMedia related_productmedias = productMediaDAO.findProductMediaByPrimaryKey(related_productmedias_prodId, related_productmedias_langId, related_productmedias_mediaId, -1, -1);

		Product product = productDAO.findProductByPrimaryKey(product_prodId, -1, -1);

		related_productmedias.setProduct(null);
		product.getProductMedias().remove(related_productmedias);

		productMediaDAO.remove(related_productmedias);
		productMediaDAO.flush();

		return product;
	}

	/**
	 * Save an existing ProductCustomField entity
	 * 
	 */
	@Transactional
	public Product saveProductProductCustomFields(Integer prodId, ProductCustomField related_productcustomfields) {
		Product product = productDAO.findProductByPrimaryKey(prodId, -1, -1);
		ProductCustomField existingproductCustomFields = productCustomFieldDAO.findProductCustomFieldByPrimaryKey(related_productcustomfields.getProdId(), related_productcustomfields.getCustomFieldId());

		// copy into the existing record to preserve existing relationships
		if (existingproductCustomFields != null) {
			existingproductCustomFields.setProdId(related_productcustomfields.getProdId());
			existingproductCustomFields.setCustomFieldId(related_productcustomfields.getCustomFieldId());
			existingproductCustomFields.setSortOrder(related_productcustomfields.getSortOrder());
			related_productcustomfields = existingproductCustomFields;
		}

		related_productcustomfields.setProduct(product);
		product.getProductCustomFields().add(related_productcustomfields);
		related_productcustomfields = productCustomFieldDAO.store(related_productcustomfields);
		productCustomFieldDAO.flush();

		product = productDAO.store(product);
		productDAO.flush();

		return product;
	}

	/**
	 * Delete an existing ProductKeyword entity
	 * 
	 */
	@Transactional
	public Product deleteProductProductKeywords(Integer product_prodId, Integer related_productkeywords_prodId, Integer related_productkeywords_keywordId) {
		ProductKeyword related_productkeywords = productKeywordDAO.findProductKeywordByPrimaryKey(related_productkeywords_prodId, related_productkeywords_keywordId, -1, -1);

		Product product = productDAO.findProductByPrimaryKey(product_prodId, -1, -1);

		//related_productkeywords.setProduct(null);
		product.getProductKeywords().remove(related_productkeywords);

		productKeywordDAO.remove(related_productkeywords);
		productKeywordDAO.flush();

		return product;
	}

	/**
	 * Return all Product entity
	 * 
	 */
	@Transactional
	public List<Product> findAllProducts(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Product>(productDAO.findAllProducts(startResult, maxRows));
	}

	/**
	 * Save an existing Designer entity
	 * 
	 */
	@Transactional
	public Product saveProductDesigner(Integer prodId, Designer related_designer) {
		Product product = productDAO.findProductByPrimaryKey(prodId, -1, -1);
		Designer existingdesigner = designerDAO.findDesignerByPrimaryKey(related_designer.getDesignerId());

		// copy into the existing record to preserve existing relationships
		if (existingdesigner != null) {
			existingdesigner.setDesignerId(related_designer.getDesignerId());
			existingdesigner.setSortOrder(related_designer.getSortOrder());
			existingdesigner.setDateAdded(related_designer.getDateAdded());
			existingdesigner.setDateModified(related_designer.getDateModified());
			existingdesigner.setStatusId(related_designer.getStatusId());
			related_designer = existingdesigner;
		} else {
			related_designer = designerDAO.store(related_designer);
			designerDAO.flush();
		}

		product.setDesignerId(related_designer.getDesignerId());
		//related_designer.getProducts().add(product);
		product = productDAO.store(product);
		productDAO.flush();

		related_designer = designerDAO.store(related_designer);
		designerDAO.flush();

		return product;
	}

	/**
	 * Delete an existing ProductCustomField entity
	 * 
	 */
	@Transactional
	public Product deleteProductProductCustomFields(Integer product_prodId, Integer related_productcustomfields_prodId, Integer related_productcustomfields_customFieldId) {
		ProductCustomField related_productcustomfields = productCustomFieldDAO.findProductCustomFieldByPrimaryKey(related_productcustomfields_prodId, related_productcustomfields_customFieldId, -1, -1);

		Product product = productDAO.findProductByPrimaryKey(product_prodId, -1, -1);

		related_productcustomfields.setProduct(null);
		product.getProductCustomFields().remove(related_productcustomfields);

		productCustomFieldDAO.remove(related_productcustomfields);
		productCustomFieldDAO.flush();

		return product;
	}

	/**
	 * Save an existing Product entity
	 * 
	 */
	@Transactional
	public void saveProduct(Product product) {
		Product existingProduct = productDAO.findProductByPrimaryKey(product.getProdId());
		product.setDateModified(Calendar.getInstance());
		product.setDateAdded(Calendar.getInstance());
		if (existingProduct != null) {
			if (existingProduct != product) {
				existingProduct.setProdId(product.getProdId());
				existingProduct.setInternalName(product.getInternalName());
				existingProduct.setMasterCatId(product.getMasterCatId());
				existingProduct.setTaxClassId(product.getTaxClassId());
				existingProduct.setOrdered(product.getOrdered());
				existingProduct.setOrderUnits(product.getOrderUnits());
				existingProduct.setProductCost(product.getProductCost());
				existingProduct.setMargin(product.getMargin());
				existingProduct.setCustom(product.getCustom());
				existingProduct.setDuty(product.getDuty());
				existingProduct.setComputedPrice(product.getComputedPrice());
				existingProduct.setUseEnteredPrice(product.getUseEnteredPrice());
				existingProduct.setEnteredPrice(product.getEnteredPrice());
				existingProduct.setSortOrder(product.getSortOrder());
				existingProduct.setDateAdded(product.getDateAdded());
				existingProduct.setStatusId(product.getStatusId());
			}
			product = productDAO.store(existingProduct);
		} else {
			// Need to set based on user's locale or GMT
			product.setDateAdded(Calendar.getInstance());
			Product productReturned = productDAO.store(product);
			product.setProdId(productReturned.getProdId());
		}
		productDAO.flush();
	}

	/**
	 * Delete an existing ProductCustomFieldVal entity
	 * 
	 */
	@Transactional
	public Product deleteProductProductCustomFieldVals(Integer product_prodId, Integer related_productcustomfieldvals_prodId, Integer related_productcustomfieldvals_langId, Integer related_productcustomfieldvals_customFieldId) {
		ProductCustomFieldVal related_productcustomfieldvals = productCustomFieldValDAO.findProductCustomFieldValByPrimaryKey(related_productcustomfieldvals_prodId, related_productcustomfieldvals_langId, related_productcustomfieldvals_customFieldId, -1, -1);

		Product product = productDAO.findProductByPrimaryKey(product_prodId, -1, -1);

		related_productcustomfieldvals.setProduct(null);
		product.getProductCustomFieldVals().remove(related_productcustomfieldvals);

		productCustomFieldValDAO.remove(related_productcustomfieldvals);
		productCustomFieldValDAO.flush();

		return product;
	}

	/**
	 * Delete an existing Designer entity
	 * 
	 */
	@Transactional
	public Product deleteProductDesigner(Integer product_prodId, Integer related_designer_designerId) {
		Product product = productDAO.findProductByPrimaryKey(product_prodId, -1, -1);
		Designer related_designer = designerDAO.findDesignerByPrimaryKey(related_designer_designerId, -1, -1);

		product.setDesignerId(null);
		//related_designer.getProducts().remove(product);
		product = productDAO.store(product);
		productDAO.flush();

		related_designer = designerDAO.store(related_designer);
		designerDAO.flush();

		designerDAO.remove(related_designer);
		designerDAO.flush();

		return product;
	}

	/**
	 * Save an existing ProductDesc entity
	 * 
	 */
	@Transactional
	public Product saveProductProductDescs(Integer prodId, ProductDesc related_productdescs) {
		Product product = productDAO.findProductByPrimaryKey(prodId, -1, -1);
		ProductDesc existingproductDescs = productDescDAO.findProductDescByPrimaryKey(related_productdescs.getProdId(), related_productdescs.getLangId());

		// copy into the existing record to preserve existing relationships
		if (existingproductDescs != null) {
			existingproductDescs.setProdId(related_productdescs.getProdId());
			existingproductDescs.setLangId(related_productdescs.getLangId());
			existingproductDescs.setPublicName(related_productdescs.getPublicName());
			existingproductDescs.setSummary(related_productdescs.getSummary());
			existingproductDescs.setDescription(related_productdescs.getDescription());
			existingproductDescs.setUrl(related_productdescs.getUrl());
			related_productdescs = existingproductDescs;
		}

		//related_productdescs.setProduct(product);
		product.getProductDescs().add(related_productdescs);
		related_productdescs = productDescDAO.store(related_productdescs);
		productDescDAO.flush();

		product = productDAO.store(product);
		productDAO.flush();

		return product;
	}

	/**
	 * Save an existing ProductCustomFieldVal entity
	 * 
	 */
	@Transactional
	public Product saveProductProductCustomFieldVals(Integer prodId, ProductCustomFieldVal related_productcustomfieldvals) {
		Product product = productDAO.findProductByPrimaryKey(prodId, -1, -1);
		ProductCustomFieldVal existingproductCustomFieldVals = productCustomFieldValDAO.findProductCustomFieldValByPrimaryKey(related_productcustomfieldvals.getProdId(), related_productcustomfieldvals.getLangId(), related_productcustomfieldvals.getCustomFieldId());

		// copy into the existing record to preserve existing relationships
		if (existingproductCustomFieldVals != null) {
			existingproductCustomFieldVals.setProdId(related_productcustomfieldvals.getProdId());
			existingproductCustomFieldVals.setLangId(related_productcustomfieldvals.getLangId());
			existingproductCustomFieldVals.setCustomFieldId(related_productcustomfieldvals.getCustomFieldId());
			existingproductCustomFieldVals.setValue(related_productcustomfieldvals.getValue());
			related_productcustomfieldvals = existingproductCustomFieldVals;
		}

		related_productcustomfieldvals.setProduct(product);
		product.getProductCustomFieldVals().add(related_productcustomfieldvals);
		related_productcustomfieldvals = productCustomFieldValDAO.store(related_productcustomfieldvals);
		productCustomFieldValDAO.flush();

		product = productDAO.store(product);
		productDAO.flush();

		return product;
	}

	/**
	 * Load an existing Product entity
	 * 
	 */
	@Transactional
	public Set<Product> loadProducts() {
		return productDAO.findAllProducts();
	}

	/**
	 * Delete an existing Store entity
	 * 
	 */
	@Transactional
	public Product deleteProductStore(Integer product_prodId, Integer related_store_storeId) {
		Product product = productDAO.findProductByPrimaryKey(product_prodId, -1, -1);
		Store related_store = storeDAO.findStoreByPrimaryKey(related_store_storeId, -1, -1);

		product.setStoreId(null);
		related_store.getProducts().remove(product);
		product = productDAO.store(product);
		productDAO.flush();

		related_store = storeDAO.store(related_store);
		storeDAO.flush();

		storeDAO.remove(related_store);
		storeDAO.flush();

		return product;
	}

	/**
	 * Save an existing ProductKeyword entity
	 * 
	 */
	@Transactional
	public Product saveProductProductKeywords(Integer prodId, ProductKeyword related_productkeywords) {
		Product product = productDAO.findProductByPrimaryKey(prodId, -1, -1);
		ProductKeyword existingproductKeywords = productKeywordDAO.findProductKeywordByPrimaryKey(related_productkeywords.getProdId(), related_productkeywords.getKeywordId());

		// copy into the existing record to preserve existing relationships
		if (existingproductKeywords != null) {
			existingproductKeywords.setProdId(related_productkeywords.getProdId());
			existingproductKeywords.setKeywordId(related_productkeywords.getKeywordId());
			existingproductKeywords.setKeywordWeight(related_productkeywords.getKeywordWeight());
			related_productkeywords = existingproductKeywords;
		}

		//related_productkeywords.setProduct(product);
		product.getProductKeywords().add(related_productkeywords);
		related_productkeywords = productKeywordDAO.store(related_productkeywords);
		productKeywordDAO.flush();

		product = productDAO.store(product);
		productDAO.flush();

		return product;
	}

	/**
	 * Save an existing Product entity
	 * 
	 */
	@Transactional
	public void saveProductDetails(Product product,ProductDesc productDescription,LinkedHashSet<ProductKeyword> productHashSet){
		productDAO.store(product);
		productDAO.flush();
		
		Integer prodId = product.getProdId();
		productDescription.setProdId(prodId);
		productDescDAO.store(productDescription);
		productDescDAO.flush();
		
		for(ProductKeyword productKeyword:productHashSet){
			productKeyword.setProdId(prodId);
			productKeywordDAO.store(productKeyword);
			productKeywordDAO.flush();
		}
	}
	/**
	 */
	@Transactional
	public Product findProductByPrimaryKey(Integer prodId) {
		return productDAO.findProductByPrimaryKey(prodId);
	}
}

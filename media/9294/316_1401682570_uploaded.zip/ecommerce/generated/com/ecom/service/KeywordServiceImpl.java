package com.ecom.service;

import com.ecom.dao.KeywordDAO;

import com.ecom.domain.Keyword;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Keyword entities
 * 
 */

@Service("KeywordService")
@Transactional
public class KeywordServiceImpl implements KeywordService {

	/**
	 * DAO injected by Spring that manages Keyword entities
	 * 
	 */
	@Autowired
	private KeywordDAO keywordDAO;

	/**
	 * Instantiates a new KeywordServiceImpl.
	 *
	 */
	public KeywordServiceImpl() {
	}

	/**
	 * Return all Keyword entity
	 * 
	 */
	@Transactional
	public List<Keyword> findAllKeywords(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Keyword>(keywordDAO.findAllKeywords(startResult, maxRows));
	}

	/**
	 * Load an existing Keyword entity
	 * 
	 */
	@Transactional
	public Set<Keyword> loadKeywords() {
		return keywordDAO.findAllKeywords();
	}

	/**
	 * Save an existing Keyword entity
	 * 
	 */
	@Transactional
	public void saveKeyword(Keyword keyword) {
		Keyword existingKeyword = keywordDAO.findKeywordByPrimaryKey(keyword.getKeywordId());

		if (existingKeyword != null) {
			if (existingKeyword != keyword) {
				existingKeyword.setKeywordId(keyword.getKeywordId());
				existingKeyword.setStoreId(keyword.getStoreId());
				existingKeyword.setDateAdded(keyword.getDateAdded());
				existingKeyword.setDateModified(keyword.getDateModified());
				existingKeyword.setStatusId(keyword.getStatusId());
			}
			keyword = keywordDAO.store(existingKeyword);
		} else {
			keyword = keywordDAO.store(keyword);
		}
		keywordDAO.flush();
	}

	/**
	 * Return a count of all Keyword entity
	 * 
	 */
	@Transactional
	public Integer countKeywords() {
		return ((Long) keywordDAO.createQuerySingleResult("select count(o) from Keyword o").getSingleResult()).intValue();
	}

	/**
	 */
	@Transactional
	public Keyword findKeywordByPrimaryKey(Integer keywordId) {
		return keywordDAO.findKeywordByPrimaryKey(keywordId);
	}

	/**
	 * Delete an existing Keyword entity
	 * 
	 */
	@Transactional
	public void deleteKeyword(Keyword keyword) {
		keywordDAO.remove(keyword);
		keywordDAO.flush();
	}
}

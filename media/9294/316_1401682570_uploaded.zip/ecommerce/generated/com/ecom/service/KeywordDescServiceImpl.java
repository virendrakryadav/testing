package com.ecom.service;

import com.ecom.dao.KeywordDescDAO;

import com.ecom.domain.KeywordDesc;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for KeywordDesc entities
 * 
 */

@Service("KeywordDescService")
@Transactional
public class KeywordDescServiceImpl implements KeywordDescService {

	/**
	 * DAO injected by Spring that manages KeywordDesc entities
	 * 
	 */
	@Autowired
	private KeywordDescDAO keywordDescDAO;

	/**
	 * Instantiates a new KeywordDescServiceImpl.
	 *
	 */
	public KeywordDescServiceImpl() {
	}

	/**
	 */
	@Transactional
	public KeywordDesc findKeywordDescByPrimaryKey(Integer keywordId, Integer langId) {
		return keywordDescDAO.findKeywordDescByPrimaryKey(keywordId, langId);
	}

	/**
	 * Return all KeywordDesc entity
	 * 
	 */
	@Transactional
	public List<KeywordDesc> findAllKeywordDescs(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<KeywordDesc>(keywordDescDAO.findAllKeywordDescs(startResult, maxRows));
	}

	/**
	 * Delete an existing KeywordDesc entity
	 * 
	 */
	@Transactional
	public void deleteKeywordDesc(KeywordDesc keyworddesc) {
		keywordDescDAO.remove(keyworddesc);
		keywordDescDAO.flush();
	}

	/**
	 * Load an existing KeywordDesc entity
	 * 
	 */
	@Transactional
	public Set<KeywordDesc> loadKeywordDescs() {
		return keywordDescDAO.findAllKeywordDescs();
	}

	/**
	 * Save an existing KeywordDesc entity
	 * 
	 */
	@Transactional
	public void saveKeywordDesc(KeywordDesc keyworddesc) {
		KeywordDesc existingKeywordDesc = keywordDescDAO.findKeywordDescByPrimaryKey(keyworddesc.getKeywordId(), keyworddesc.getLangId());

		if (existingKeywordDesc != null) {
			if (existingKeywordDesc != keyworddesc) {
				existingKeywordDesc.setKeywordId(keyworddesc.getKeywordId());
				existingKeywordDesc.setLangId(keyworddesc.getLangId());
				existingKeywordDesc.setDescription(keyworddesc.getDescription());
			}
			keyworddesc = keywordDescDAO.store(existingKeywordDesc);
		} else {
			keyworddesc = keywordDescDAO.store(keyworddesc);
		}
		keywordDescDAO.flush();
	}

	/**
	 * Return a count of all KeywordDesc entity
	 * 
	 */
	@Transactional
	public Integer countKeywordDescs() {
		return ((Long) keywordDescDAO.createQuerySingleResult("select count(*) from KeywordDesc o").getSingleResult()).intValue();
	}
}

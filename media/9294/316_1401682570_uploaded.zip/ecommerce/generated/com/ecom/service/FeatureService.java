package com.ecom.service;

import com.ecom.domain.Feature;
import com.ecom.domain.FeatureDesc;
import com.ecom.domain.FeatureRole;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for Feature entities
 * 
 */
public interface FeatureService {

	/**
	 * Load an existing Feature entity
	 * 
	 */
	public Set<Feature> loadFeatures();

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	public Feature saveFeatureFeatureRoles(Integer featureId, FeatureRole related_featureroles);

	/**
	 */
	public Feature findFeatureByPrimaryKey(Integer featureId_1);

	/**
	 * Delete an existing FeatureDesc entity
	 * 
	 */
	public Feature deleteFeatureFeatureDescs(Integer feature_featureId, Integer related_featuredescs_featureId, Integer related_featuredescs_langId);

	/**
	 * Return all Feature entity
	 * 
	 */
	public List<Feature> findAllFeatures(Integer startResult, Integer maxRows);

	/**
	 * Save an existing Feature entity
	 * 
	 */
	public void saveFeature(Feature feature);

	/**
	 * Save an existing FeatureDesc entity
	 * 
	 */
	public Feature saveFeatureFeatureDescs(Integer featureId_2, FeatureDesc related_featuredescs);

	/**
	 * Return a count of all Feature entity
	 * 
	 */
	public Integer countFeatures();

	/**
	 * Delete an existing Feature entity
	 * 
	 */
	public void deleteFeature(Feature feature_1);

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	public Feature deleteFeatureFeatureRoles(Integer feature_featureId_1, Integer related_featureroles_featureId, Integer related_featureroles_roleId);
}
package com.ecom.service;

import com.ecom.domain.FeatureRole;

import java.util.List;
import java.util.Set;

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;

import org.springframework.context.ApplicationContext;

import org.springframework.mock.web.MockHttpServletRequest;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.RequestScope;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.SessionScope;

/**
 * Class to run the service as a JUnit test. Each operation in the service is a separate test.
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration(locations = {
		"file:./resources/HelpServer-security-context.xml",
		"file:./resources/HelpServer-service-context.xml",
		"file:./resources/HelpServer-dao-context.xml",
		"file:./resources/HelpServer-web-context.xml" })
@Transactional
public class FeatureRoleServiceTest {

	/**
	 * The Spring application context.
	 *
	 */
	@SuppressWarnings("unused")
	private ApplicationContext context;

	/**
	 * The service being tested, injected by Spring.
	 *
	 */
	@Autowired
	protected FeatureRoleService service;

	/**
	 * Instantiates a new FeatureRoleServiceTest.
	 *
	 */
	public FeatureRoleServiceTest() {
		setupRequestContext();
	}

	/**
	 * Operation Unit Test
	 * Save an existing FeatureRole entity
	 * 
	 */
	@Test
	public void saveFeatureRole() {
		// TODO: JUnit - Populate test inputs for operation: saveFeatureRole 
		FeatureRole featurerole = new com.ecom.domain.FeatureRole();
		service.saveFeatureRole(featurerole);
	}

	/**
	 * Operation Unit Test
	 * Delete an existing FeatureRole entity
	 * 
	 */
	@Test
	public void deleteFeatureRole() {
		// TODO: JUnit - Populate test inputs for operation: deleteFeatureRole 
		FeatureRole featurerole_1 = new com.ecom.domain.FeatureRole();
		service.deleteFeatureRole(featurerole_1);
	}

	/**
	 * Operation Unit Test
	 * Return a count of all FeatureRole entity
	 * 
	 */
	@Test
	public void countFeatureRoles() {
		Integer response = null;
		response = service.countFeatureRoles();
		// TODO: JUnit - Add assertions to test outputs of operation: countFeatureRoles
	}

	/**
	 * Operation Unit Test
	 */
	@Test
	public void findFeatureRoleByPrimaryKey() {
		// TODO: JUnit - Populate test inputs for operation: findFeatureRoleByPrimaryKey 
		Integer featureId = 0;
		Integer roleId = 0;
		FeatureRole response = null;
		response = service.findFeatureRoleByPrimaryKey(featureId, roleId);
		// TODO: JUnit - Add assertions to test outputs of operation: findFeatureRoleByPrimaryKey
	}

	/**
	 * Operation Unit Test
	 * Return all FeatureRole entity
	 * 
	 */
	@Test
	public void findAllFeatureRoles() {
		// TODO: JUnit - Populate test inputs for operation: findAllFeatureRoles 
		Integer startResult = 0;
		Integer maxRows = 0;
		List<FeatureRole> response = null;
		response = service.findAllFeatureRoles(startResult, maxRows);
		// TODO: JUnit - Add assertions to test outputs of operation: findAllFeatureRoles
	}

	/**
	 * Operation Unit Test
	 * Load an existing FeatureRole entity
	 * 
	 */
	@Test
	public void loadFeatureRoles() {
		Set<FeatureRole> response = null;
		response = service.loadFeatureRoles();
		// TODO: JUnit - Add assertions to test outputs of operation: loadFeatureRoles
	}

	/**
	 * Autowired to set the Spring application context.
	 *
	 */
	@Autowired
	public void setContext(ApplicationContext context) {
		this.context = context;
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("session", new SessionScope());
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("request", new RequestScope());
	}

	/**
	 * Sets Up the Request context
	 *
	 */
	private void setupRequestContext() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		ServletRequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
	}
}

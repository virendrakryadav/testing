package com.ecom.service;

import com.ecom.dao.StoreDescDAO;

import com.ecom.domain.StoreDesc;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for StoreDesc entities
 * 
 */

@Service("StoreDescService")
@Transactional
public class StoreDescServiceImpl implements StoreDescService {

	/**
	 * DAO injected by Spring that manages StoreDesc entities
	 * 
	 */
	@Autowired
	private StoreDescDAO storeDescDAO;

	/**
	 * Instantiates a new StoreDescServiceImpl.
	 *
	 */
	public StoreDescServiceImpl() {
	}

	/**
	 * Return all StoreDesc entity
	 * 
	 */
	@Transactional
	public List<StoreDesc> findAllStoreDescs(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<StoreDesc>(storeDescDAO.findAllStoreDescs(startResult, maxRows));
	}

	/**
	 * Save an existing StoreDesc entity
	 * 
	 */
	@Transactional
	public void saveStoreDesc(StoreDesc storedesc) {
		StoreDesc existingStoreDesc = storeDescDAO.findStoreDescByPrimaryKey(storedesc.getStoreId(), storedesc.getLangId());

		if (existingStoreDesc != null) {
			if (existingStoreDesc != storedesc) {
				existingStoreDesc.setStoreId(storedesc.getStoreId());
				existingStoreDesc.setLangId(storedesc.getLangId());
				existingStoreDesc.setCssFilename(storedesc.getCssFilename());
				existingStoreDesc.setLogoFilename(storedesc.getLogoFilename());
			}
			storedesc = storeDescDAO.store(existingStoreDesc);
		} else {
			storedesc = storeDescDAO.store(storedesc);
		}
		storeDescDAO.flush();
	}

	/**
	 * Load an existing StoreDesc entity
	 * 
	 */
	@Transactional
	public Set<StoreDesc> loadStoreDescs() {
		return storeDescDAO.findAllStoreDescs();
	}

	/**
	 */
	@Transactional
	public StoreDesc findStoreDescByPrimaryKey(Integer storeId, Integer langId) {
		return storeDescDAO.findStoreDescByPrimaryKey(storeId, langId);
	}

	/**
	 * Delete an existing StoreDesc entity
	 * 
	 */
	@Transactional
	public void deleteStoreDesc(StoreDesc storedesc) {
		storeDescDAO.remove(storedesc);
		storeDescDAO.flush();
	}

	/**
	 * Return a count of all StoreDesc entity
	 * 
	 */
	@Transactional
	public Integer countStoreDescs() {
		return ((Long) storeDescDAO.createQuerySingleResult("select count(*) from StoreDesc o").getSingleResult()).intValue();
	}
}

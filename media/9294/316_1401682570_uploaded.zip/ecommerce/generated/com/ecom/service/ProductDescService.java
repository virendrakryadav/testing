package com.ecom.service;

import com.ecom.domain.ProductDesc;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for ProductDesc entities
 * 
 */
public interface ProductDescService {

	/**
	 * Save an existing ProductDesc entity
	 * 
	 */
	public void saveProductDesc(ProductDesc productdesc);

	/**
	 * Return all ProductDesc entity
	 * 
	 */
	public List<ProductDesc> findAllProductDescs(Integer startResult, Integer maxRows);

	/**
	 * Delete an existing ProductDesc entity
	 * 
	 */
	public void deleteProductDesc(ProductDesc productdesc_1);

	/**
	 */
	public ProductDesc findProductDescByPrimaryKey(Integer prodId, Integer langId);

	/**
	 * Return a count of all ProductDesc entity
	 * 
	 */
	public Integer countProductDescs();

	/**
	 * Load an existing ProductDesc entity
	 * 
	 */
	public Set<ProductDesc> loadProductDescs();
}
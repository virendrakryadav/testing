package com.ecom.service;

import com.ecom.domain.FeatureRole;

import java.util.List;
import java.util.Set;

/**
 * Spring service that handles CRUD requests for FeatureRole entities
 * 
 */
public interface FeatureRoleService {

	/**
	 * Return a count of all FeatureRole entity
	 * 
	 */
	public Integer countFeatureRoles();

	/**
	 * Load an existing FeatureRole entity
	 * 
	 */
	public Set<FeatureRole> loadFeatureRoles();

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	public void deleteFeatureRole(FeatureRole featurerole);

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	public void saveFeatureRole(FeatureRole featurerole_1);

	/**
	 */
	public FeatureRole findFeatureRoleByPrimaryKey(Integer featureId, Integer roleId);

	/**
	 * Return all FeatureRole entity
	 * 
	 */
	public List<FeatureRole> findAllFeatureRoles(Integer startResult, Integer maxRows);
}
package com.ecom.service;

import com.ecom.dao.DesignerDescDAO;

import com.ecom.domain.DesignerDesc;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for DesignerDesc entities
 * 
 */

@Service("DesignerDescService")
@Transactional
public class DesignerDescServiceImpl implements DesignerDescService {

	/**
	 * DAO injected by Spring that manages DesignerDesc entities
	 * 
	 */
	@Autowired
	private DesignerDescDAO designerDescDAO;

	/**
	 * Instantiates a new DesignerDescServiceImpl.
	 *
	 */
	public DesignerDescServiceImpl() {
	}

	/**
	 * Return all DesignerDesc entity
	 * 
	 */
	@Transactional
	public List<DesignerDesc> findAllDesignerDescs(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<DesignerDesc>(designerDescDAO.findAllDesignerDescs(startResult, maxRows));
	}

	/**
	 * Save an existing DesignerDesc entity
	 * 
	 */
	@Transactional
	public void saveDesignerDesc(DesignerDesc designerdesc) {
		DesignerDesc existingDesignerDesc = designerDescDAO.findDesignerDescByPrimaryKey(designerdesc.getDesignerId(), designerdesc.getLangId());

		if (existingDesignerDesc != null) {
			if (existingDesignerDesc != designerdesc) {
				existingDesignerDesc.setDesignerId(designerdesc.getDesignerId());
				existingDesignerDesc.setLangId(designerdesc.getLangId());
				existingDesignerDesc.setName(designerdesc.getName());
				existingDesignerDesc.setDescription(designerdesc.getDescription());
				existingDesignerDesc.setProfile(designerdesc.getProfile());
				existingDesignerDesc.setUrl(designerdesc.getUrl());
				existingDesignerDesc.setImageLocation(designerdesc.getImageLocation());
				existingDesignerDesc.setMetaTagsTitle(designerdesc.getMetaTagsTitle());
				existingDesignerDesc.setMetaKeywords(designerdesc.getMetaKeywords());
				existingDesignerDesc.setMetaDesc(designerdesc.getMetaDesc());
				existingDesignerDesc.setStoreId(designerdesc.getStoreId());
			}
			designerdesc = designerDescDAO.store(existingDesignerDesc);
		} else {
			designerdesc = designerDescDAO.store(designerdesc);
		}
		designerDescDAO.flush();
	}

	/**
	 */
	@Transactional
	public DesignerDesc findDesignerDescByPrimaryKey(Integer designerId, Integer langId) {
		return designerDescDAO.findDesignerDescByPrimaryKey(designerId, langId);
	}

	/**
	 * Delete an existing DesignerDesc entity
	 * 
	 */
	@Transactional
	public void deleteDesignerDesc(DesignerDesc designerdesc) {
		designerDescDAO.remove(designerdesc);
		designerDescDAO.flush();
	}

	/**
	 * Return a count of all DesignerDesc entity
	 * 
	 */
	@Transactional
	public Integer countDesignerDescs() {
		return ((Long) designerDescDAO.createQuerySingleResult("select count(*) from DesignerDesc o").getSingleResult()).intValue();
	}

	/**
	 * Load an existing DesignerDesc entity
	 * 
	 */
	@Transactional
	public Set<DesignerDesc> loadDesignerDescs() {
		return designerDescDAO.findAllDesignerDescs();
	}
}

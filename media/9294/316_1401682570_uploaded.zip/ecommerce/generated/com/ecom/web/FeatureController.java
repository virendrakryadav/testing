package com.ecom.web;

import com.ecom.dao.FeatureDAO;
import com.ecom.dao.FeatureDescDAO;
import com.ecom.dao.FeatureRoleDAO;

import com.ecom.domain.Feature;
import com.ecom.domain.FeatureDesc;
import com.ecom.domain.FeatureRole;

import com.ecom.service.FeatureService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for Feature entities
 * 
 */

@Controller("FeatureController")
public class FeatureController {

	/**
	 * DAO injected by Spring that manages Feature entities
	 * 
	 */
	@Autowired
	private FeatureDAO featureDAO;

	/**
	 * DAO injected by Spring that manages FeatureDesc entities
	 * 
	 */
	@Autowired
	private FeatureDescDAO featureDescDAO;

	/**
	 * DAO injected by Spring that manages FeatureRole entities
	 * 
	 */
	@Autowired
	private FeatureRoleDAO featureRoleDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for Feature entities
	 * 
	 */
	@Autowired
	private FeatureService featureService;

	/**
	 * Save an existing FeatureDesc entity
	 * 
	 */
	@RequestMapping("/saveFeatureFeatureDescs")
	public ModelAndView saveFeatureFeatureDescs(@RequestParam Integer feature_featureId, @ModelAttribute FeatureDesc featuredescs) {
		Feature parent_feature = featureService.saveFeatureFeatureDescs(feature_featureId, featuredescs);

		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("feature", parent_feature);
		mav.setViewName("feature/viewFeature.jsp");

		return mav;
	}

	/**
	 * Create a new FeatureDesc entity
	 * 
	 */
	@RequestMapping("/newFeatureFeatureDescs")
	public ModelAndView newFeatureFeatureDescs(@RequestParam Integer feature_featureId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("featuredesc", new FeatureDesc());
		mav.addObject("newFlag", true);
		mav.setViewName("feature/featuredescs/editFeatureDescs.jsp");

		return mav;
	}

	/**
	 * Delete an existing Feature entity
	 * 
	 */
	@RequestMapping("/deleteFeature")
	public String deleteFeature(@RequestParam Integer featureIdKey) {
		Feature feature = featureDAO.findFeatureByPrimaryKey(featureIdKey);
		featureService.deleteFeature(feature);
		return "forward:/indexFeature";
	}

	/**
	 */
	@RequestMapping("/featureController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Save an existing Feature entity
	 * 
	 */
	@RequestMapping("/saveFeature")
	public String saveFeature(@ModelAttribute Feature feature) {
		featureService.saveFeature(feature);
		return "forward:/indexFeature";
	}

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/saveFeatureFeatureRoles")
	public ModelAndView saveFeatureFeatureRoles(@RequestParam Integer feature_featureId, @ModelAttribute FeatureRole featureroles) {
		Feature parent_feature = featureService.saveFeatureFeatureRoles(feature_featureId, featureroles);

		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("feature", parent_feature);
		mav.setViewName("feature/viewFeature.jsp");

		return mav;
	}

	/**
	 * Create a new Feature entity
	 * 
	 */
	@RequestMapping("/newFeature")
	public ModelAndView newFeature() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("feature", new Feature());
		mav.addObject("newFlag", true);
		mav.setViewName("feature/editFeature.jsp");

		return mav;
	}

	/**
	 * Edit an existing FeatureDesc entity
	 * 
	 */
	@RequestMapping("/editFeatureFeatureDescs")
	public ModelAndView editFeatureFeatureDescs(@RequestParam Integer feature_featureId, @RequestParam Integer featuredescs_featureId, @RequestParam Integer featuredescs_langId) {
		FeatureDesc featuredesc = featureDescDAO.findFeatureDescByPrimaryKey(featuredescs_featureId, featuredescs_langId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("featuredesc", featuredesc);
		mav.setViewName("feature/featuredescs/editFeatureDescs.jsp");

		return mav;
	}

	/**
	 * Select the child FeatureRole entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteFeatureFeatureRoles")
	public ModelAndView confirmDeleteFeatureFeatureRoles(@RequestParam Integer feature_featureId, @RequestParam Integer related_featureroles_featureId, @RequestParam Integer related_featureroles_roleId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featurerole", featureRoleDAO.findFeatureRoleByPrimaryKey(related_featureroles_featureId, related_featureroles_roleId));
		mav.addObject("feature_featureId", feature_featureId);
		mav.setViewName("feature/featureroles/deleteFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Entry point to show all Feature entities
	 * 
	 */
	public String indexFeature() {
		return "redirect:/indexFeature";
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Select an existing Feature entity
	 * 
	 */
	@RequestMapping("/selectFeature")
	public ModelAndView selectFeature(@RequestParam Integer featureIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("feature", featureDAO.findFeatureByPrimaryKey(featureIdKey));
		mav.setViewName("feature/viewFeature.jsp");

		return mav;
	}

	/**
	 * Select the Feature entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteFeature")
	public ModelAndView confirmDeleteFeature(@RequestParam Integer featureIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("feature", featureDAO.findFeatureByPrimaryKey(featureIdKey));
		mav.setViewName("feature/deleteFeature.jsp");

		return mav;
	}

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/deleteFeatureFeatureRoles")
	public ModelAndView deleteFeatureFeatureRoles(@RequestParam Integer feature_featureId, @RequestParam Integer related_featureroles_featureId, @RequestParam Integer related_featureroles_roleId) {
		ModelAndView mav = new ModelAndView();

		Feature feature = featureService.deleteFeatureFeatureRoles(feature_featureId, related_featureroles_featureId, related_featureroles_roleId);

		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("feature", feature);
		mav.setViewName("feature/viewFeature.jsp");

		return mav;
	}

	/**
	 * Edit an existing Feature entity
	 * 
	 */
	@RequestMapping("/editFeature")
	public ModelAndView editFeature(@RequestParam Integer featureIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("feature", featureDAO.findFeatureByPrimaryKey(featureIdKey));
		mav.setViewName("feature/editFeature.jsp");

		return mav;
	}

	/**
	 * View an existing FeatureDesc entity
	 * 
	 */
	@RequestMapping("/selectFeatureFeatureDescs")
	public ModelAndView selectFeatureFeatureDescs(@RequestParam Integer feature_featureId, @RequestParam Integer featuredescs_featureId, @RequestParam Integer featuredescs_langId) {
		FeatureDesc featuredesc = featureDescDAO.findFeatureDescByPrimaryKey(featuredescs_featureId, featuredescs_langId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("featuredesc", featuredesc);
		mav.setViewName("feature/featuredescs/viewFeatureDescs.jsp");

		return mav;
	}

	/**
	 * Show all FeatureRole entities by Feature
	 * 
	 */
	@RequestMapping("/listFeatureFeatureRoles")
	public ModelAndView listFeatureFeatureRoles(@RequestParam Integer featureIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("feature", featureDAO.findFeatureByPrimaryKey(featureIdKey));
		mav.setViewName("feature/featureroles/listFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Show all Feature entities
	 * 
	 */
	@RequestMapping("/indexFeature")
	public ModelAndView listFeatures() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("features", featureService.loadFeatures());

		mav.setViewName("feature/listFeatures.jsp");

		return mav;
	}

	/**
	 * View an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/selectFeatureFeatureRoles")
	public ModelAndView selectFeatureFeatureRoles(@RequestParam Integer feature_featureId, @RequestParam Integer featureroles_featureId, @RequestParam Integer featureroles_roleId) {
		FeatureRole featurerole = featureRoleDAO.findFeatureRoleByPrimaryKey(featureroles_featureId, featureroles_roleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("featurerole", featurerole);
		mav.setViewName("feature/featureroles/viewFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Show all FeatureDesc entities by Feature
	 * 
	 */
	@RequestMapping("/listFeatureFeatureDescs")
	public ModelAndView listFeatureFeatureDescs(@RequestParam Integer featureIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("feature", featureDAO.findFeatureByPrimaryKey(featureIdKey));
		mav.setViewName("feature/featuredescs/listFeatureDescs.jsp");

		return mav;
	}

	/**
	 * Edit an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/editFeatureFeatureRoles")
	public ModelAndView editFeatureFeatureRoles(@RequestParam Integer feature_featureId, @RequestParam Integer featureroles_featureId, @RequestParam Integer featureroles_roleId) {
		FeatureRole featurerole = featureRoleDAO.findFeatureRoleByPrimaryKey(featureroles_featureId, featureroles_roleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("featurerole", featurerole);
		mav.setViewName("feature/featureroles/editFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Select the child FeatureDesc entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteFeatureFeatureDescs")
	public ModelAndView confirmDeleteFeatureFeatureDescs(@RequestParam Integer feature_featureId, @RequestParam Integer related_featuredescs_featureId, @RequestParam Integer related_featuredescs_langId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featuredesc", featureDescDAO.findFeatureDescByPrimaryKey(related_featuredescs_featureId, related_featuredescs_langId));
		mav.addObject("feature_featureId", feature_featureId);
		mav.setViewName("feature/featuredescs/deleteFeatureDescs.jsp");

		return mav;
	}

	/**
	 * Create a new FeatureRole entity
	 * 
	 */
	@RequestMapping("/newFeatureFeatureRoles")
	public ModelAndView newFeatureFeatureRoles(@RequestParam Integer feature_featureId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("featurerole", new FeatureRole());
		mav.addObject("newFlag", true);
		mav.setViewName("feature/featureroles/editFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Delete an existing FeatureDesc entity
	 * 
	 */
	@RequestMapping("/deleteFeatureFeatureDescs")
	public ModelAndView deleteFeatureFeatureDescs(@RequestParam Integer feature_featureId, @RequestParam Integer related_featuredescs_featureId, @RequestParam Integer related_featuredescs_langId) {
		ModelAndView mav = new ModelAndView();

		Feature feature = featureService.deleteFeatureFeatureDescs(feature_featureId, related_featuredescs_featureId, related_featuredescs_langId);

		mav.addObject("feature_featureId", feature_featureId);
		mav.addObject("feature", feature);
		mav.setViewName("feature/viewFeature.jsp");

		return mav;
	}
}
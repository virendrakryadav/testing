package com.ecom.web;


import java.math.BigDecimal;
import java.util.LinkedHashSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ecom.domain.Product;
import com.ecom.domain.ProductDesc;
import com.ecom.domain.ProductKeyword;

import com.ecom.service.KeywordDescService;
import com.ecom.service.ProductDescService;
import com.ecom.service.ProductKeywordService;
import com.ecom.service.ProductService;
import com.ecom.service.DesignerService;
import com.ecom.session.UserSessionInfo;
import com.ecom.utils.Common;

@org.springframework.stereotype.Controller("ProductManagerController")
public class ProductManagerController {

	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private ProductService productService;
	
	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private ProductDescService productDescService;
	
	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private DesignerService designerService;
	
	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private KeywordDescService keywordDescService;
	
	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private ProductKeywordService productKeywordService;
	
	
	@RequestMapping("/saveProduct")
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		try{
			UserSessionInfo  userSessionInfo = Common.getUserSessionInfo(request);
			Integer langId = userSessionInfo.currentLang.getLangId();
			Integer storeId = userSessionInfo.currentStoreDesc.getStoreId();
			//ProductKeyword pk = new ProductKeyword();
			LinkedHashSet<ProductKeyword> linkedHS= new LinkedHashSet<ProductKeyword>();
			String product_internalName = request.getParameter("product_internalName");
			String public_name = request.getParameter("public_name");
			String prod_summary = request.getParameter("prod_summary");
			String product_masterCatId = request.getParameter("product_masterCatId");
			String product_productCost = request.getParameter("product_productCost");
			String product_margin = request.getParameter("product_margin");
			String product_custom = request.getParameter("product_custom");
			String product_duty = request.getParameter("product_duty");
			String product_enteredPrice = request.getParameter("product_enteredPrice");
			String product_useEnteredPrice = request.getParameter("product_useEnteredPrice");
			String product_computedPrice = request.getParameter("product_computedPrice");
			String product_designerId = request.getParameter("product_designerId");
			String keywordChk[] = request.getParameterValues("keywordChk");
			String product_prodId = request.getParameter("product_prodId");
			
			
			boolean isAdd = false;
			
			String str =" product_internalName "+ product_internalName +"    public_name "+public_name+" product_masterCatId "+product_masterCatId;
			System.out.println("The variables are ["+str+"]");
			// Populate Product 
			Product product = new Product();
			ProductDesc productDescription = new ProductDesc();
			
			if(isValid(product_prodId)){
				product.setProdId(new Integer(product_prodId));
			}else {
				isAdd = true;
			}
			
			product.setStoreId(storeId);

			if(isValid(product_internalName )){
				product.setInternalName(product_internalName);
			}
			
			if(isValid(product_masterCatId )){
				product.setMasterCatId(new Integer(product_masterCatId));
			}
			
			if(isValid(product_productCost )){
				product.setProductCost(new BigDecimal(product_productCost));
			}
			
			if(isValid(product_margin )){
				product.setMargin(new BigDecimal(product_margin));
			}
			
			if(isValid(product_custom )){
				product.setCustom(new BigDecimal(product_custom));
			}
			if(isValid(product_duty )){
				product.setDuty(new BigDecimal(product_duty));
			}
			
			if(isValid(product_enteredPrice)){
				product.setEnteredPrice(new BigDecimal(product_enteredPrice));
			}
			
			if(isValid(product_computedPrice)){
				product.setComputedPrice(new BigDecimal(product_computedPrice));
			}
			if(product_useEnteredPrice != null){
				product.setUseEnteredPrice(true);
			}
			
			if(isValid(product_designerId)){
				product.setDesignerId(new Integer(product_designerId));
			}
			
			if(isValid(public_name)){
				productDescription.setPublicName(public_name);
				productDescription.setLangId(langId);
			}
			
			if(isValid(prod_summary)){
				productDescription.setSummary(prod_summary);
			}
			
			//LinkedHashSet <ProductDesc>linkedProductDescs = new LinkedHashSet<ProductDesc>();
			//product.setProductDescs(linkedProductDescs);
			
			//productService.saveProduct(product);
			//System.out.println("The product Id after save is ["+product.getProdId()+"]");
			
			if(keywordChk != null){
				for(int i=0;i<keywordChk.length;i++){
					System.out.println("The output for param key["+i+"]["+request.getParameter("key"+keywordChk[i])+"]");
					System.out.println("The output for param weight["+i+"]["+request.getParameter("weight"+keywordChk[i])+"]");
				}
			}
			/*
			productDescription.setProdId(product.getProdId());
			productDescription.setStoreId(product.getStoreId());
			productDescService.saveProductDesc(productDescription);
			*/
			if(keywordChk != null){
				if(keywordChk.length > 0){
					String weight[] = new String[keywordChk.length];
					String keyword[]  = new String[keywordChk.length];
					int i=0;
					
					for(String s:keywordChk){
						weight[i] = request.getParameter("weight"+s);
						keyword[i++] = request.getParameter("key"+s);
					}
					
					for(int j=0;j<keyword.length;j++){
						System.out.println("The keyword length is "+keyword.length);
						ProductKeyword pk = new ProductKeyword();
						pk.setKeywordWeight(new Integer(weight[j]));
						pk.setKeywordId(new Integer(keyword[j]));
						pk.setProdId(product.getProdId());
						pk.setStoreId(product.getStoreId());
						linkedHS.add(pk);
					}
				}
			}
			productService.saveProductDetails(product,productDescription,linkedHS);
			mav.addObject("products", productService.loadProducts());
			mav.setViewName("product/listProducts.jsp");
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return mav;
	}
	
	private static boolean isValid(String val){
		if(val != null && val.trim().trim().length()>0){
			return true;
		}
		return false;
	}
}

package com.ecom.web;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ecom.session.UserSessionInfo;
import com.ecom.utils.Common;

@Controller("HelpTextController")
public class HelpTextController 
{
	/**
	 * Constructor of the object.
	 */
	public HelpTextController() {
		super();
	}

	@RequestMapping("/getHelpText")
	public ResponseEntity<String>  getHelp(HttpServletRequest request)
	{
		String key = request.getParameter("key");
		System.out.println("getHelp "+key);
		String helpText;
		try
		{
			if (key == null){
				helpText = "Invalid help key ["+key+"].";//System debug error message,so no I18N
			}else
			{
				//Note: help feature us uses not very often, so reloading resource file
				//as when needed. But, can be cached.
				ResourceBundle bundle = Common.getResourceBundle(request,Common.RESOURCE_NAME_ADMIN_HELP);
				helpText = bundle.getString(key);			
				if (helpText == null){
					helpText = "No help available for the key ["+key+"].";//System debug error message,so no I18N
				}
			}
		}catch (Exception e)
		{
			helpText = "Error in getting help text:" +e.getMessage();//System debug error message,so no I18N
		}
		System.out.println("getHelp test "+helpText);
		HttpHeaders responseHeaders = new HttpHeaders();
//		responseHeaders.set("MyResponseHeader", helpText);
		System.out.println("getHelp leaving");
		return new ResponseEntity<String>(helpText, responseHeaders, HttpStatus.CREATED);
	}	
}

package com.ecom.web;

import com.ecom.dao.StoreDescDAO;

import com.ecom.domain.StoreDesc;

import com.ecom.service.StoreDescService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for StoreDesc entities
 * 
 */

@Controller("StoreDescController")
public class StoreDescController {

	/**
	 * DAO injected by Spring that manages StoreDesc entities
	 * 
	 */
	@Autowired
	private StoreDescDAO storeDescDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for StoreDesc entities
	 * 
	 */
	@Autowired
	private StoreDescService storeDescService;

	/**
	 */
	@RequestMapping("/storedescController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Edit an existing StoreDesc entity
	 * 
	 */
	@RequestMapping("/editStoreDesc")
	public ModelAndView editStoreDesc(@RequestParam Integer storeIdKey, @RequestParam Integer langIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("storedesc", storeDescDAO.findStoreDescByPrimaryKey(storeIdKey, langIdKey));
		mav.setViewName("storedesc/editStoreDesc.jsp");

		return mav;
	}

	/**
	 * Select an existing StoreDesc entity
	 * 
	 */
	@RequestMapping("/selectStoreDesc")
	public ModelAndView selectStoreDesc(@RequestParam Integer storeIdKey, @RequestParam Integer langIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("storedesc", storeDescDAO.findStoreDescByPrimaryKey(storeIdKey, langIdKey));
		mav.setViewName("storedesc/viewStoreDesc.jsp");

		return mav;
	}

	/**
	 * Delete an existing StoreDesc entity
	 * 
	 */
	@RequestMapping("/deleteStoreDesc")
	public String deleteStoreDesc(@RequestParam Integer storeIdKey, @RequestParam Integer langIdKey) {
		StoreDesc storedesc = storeDescDAO.findStoreDescByPrimaryKey(storeIdKey, langIdKey);
		storeDescService.deleteStoreDesc(storedesc);
		return "forward:/indexStoreDesc";
	}

	/**
	 * Create a new StoreDesc entity
	 * 
	 */
	@RequestMapping("/newStoreDesc")
	public ModelAndView newStoreDesc() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("storedesc", new StoreDesc());
		mav.addObject("newFlag", true);
		mav.setViewName("storedesc/editStoreDesc.jsp");

		return mav;
	}

	/**
	 * Entry point to show all StoreDesc entities
	 * 
	 */
	public String indexStoreDesc() {
		return "redirect:/indexStoreDesc";
	}

	/**
	 * Show all StoreDesc entities
	 * 
	 */
	@RequestMapping("/indexStoreDesc")
	public ModelAndView listStoreDescs() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("storedescs", storeDescService.loadStoreDescs());

		mav.setViewName("storedesc/listStoreDescs.jsp");

		return mav;
	}

	/**
	 * Save an existing StoreDesc entity
	 * 
	 */
	@RequestMapping("/saveStoreDesc")
	public String saveStoreDesc(@ModelAttribute StoreDesc storedesc) {
		storeDescService.saveStoreDesc(storedesc);
		return "forward:/indexStoreDesc";
	}

	/**
	 * Select the StoreDesc entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteStoreDesc")
	public ModelAndView confirmDeleteStoreDesc(@RequestParam Integer storeIdKey, @RequestParam Integer langIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("storedesc", storeDescDAO.findStoreDescByPrimaryKey(storeIdKey, langIdKey));
		mav.setViewName("storedesc/deleteStoreDesc.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}
}
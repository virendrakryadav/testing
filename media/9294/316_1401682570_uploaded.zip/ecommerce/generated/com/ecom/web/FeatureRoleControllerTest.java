package com.ecom.web;

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;

import org.springframework.context.ApplicationContext;

import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import org.springframework.test.context.ContextConfiguration;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.RequestScope;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.SessionScope;

/**
 * Unit test for the <code>FeatureRoleController</code> controller.
 *
 * @see com.ecom.roles.web.FeatureRoleController
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"file:./resources/HelpServer-security-context.xml",
		"file:./resources/HelpServer-service-context.xml",
		"file:./resources/HelpServer-dao-context.xml",
		"file:./resources/HelpServer-web-context.xml" })
public class FeatureRoleControllerTest {
	/**
	 * The Spring application context.
	 *
	 */
	private ApplicationContext context;

	/**
	 * Test <code>indexFeatureRole()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GetindexFeatureRole() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/indexFeatureRole");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Test <code>selectFeatureRole()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GetselectFeatureRole() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/selectFeatureRole");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Test <code>editFeatureRole()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GeteditFeatureRole() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/editFeatureRole");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Test <code>saveFeatureRole()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GetsaveFeatureRole() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/saveFeatureRole");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Test <code>newFeatureRole()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GetnewFeatureRole() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/newFeatureRole");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Test <code>confirmDeleteFeatureRole()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GetconfirmDeleteFeatureRole() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/confirmDeleteFeatureRole");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Test <code>deleteFeatureRole()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GetdeleteFeatureRole() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/deleteFeatureRole");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Test <code>featureroleControllerbinaryaction()</code>.
	 */
	@Test
	@SuppressWarnings("unused")
	public void GetfeatureroleControllerbinaryaction() throws Exception {
		MockHttpServletRequest request = getMockHttpServletRequest();
		request.setRequestURI("/featureroleController/binary.action");
		MockHttpServletResponse response = getMockHttpServletResponse();

		// Get the singleton controller instance
		FeatureRoleController controller = (FeatureRoleController) context.getBean("FeatureRoleController");

		// TODO Invoke method and Assert return values

	}

	/**
	 * Autowired to set the Spring application context.
	 *
	 */
	@Autowired
	public void setContext(ApplicationContext context) {
		this.context = context;
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("session", new SessionScope());
		((DefaultListableBeanFactory) context.getAutowireCapableBeanFactory()).registerScope("request", new RequestScope());
	}

	/**
	 * Returns a mock HttpServletRequest object.
	 *
	 */
	private MockHttpServletRequest getMockHttpServletRequest() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		ServletRequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
		return request;
	}

	/**
	 * Returns a mock HttpServletResponse object.
	 *
	 */
	private MockHttpServletResponse getMockHttpServletResponse() {
		return new MockHttpServletResponse();
	}
}
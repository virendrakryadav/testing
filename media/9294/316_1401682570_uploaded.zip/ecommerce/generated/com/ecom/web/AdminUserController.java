package com.ecom.web;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import com.ecom.dao.AdminUserDAO;
import com.ecom.dao.AdminUserStoreDAO;
import com.ecom.dao.LanguageDAO;
import com.ecom.dao.RoleDAO;

import com.ecom.domain.AdminUser;
import com.ecom.domain.AdminUserStore;
import com.ecom.domain.Language;
import com.ecom.domain.Role;

import com.ecom.service.AdminUserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;
import com.ecom.service.ProductService;
import com.ecom.session.UserSessionInfo;
import com.ecom.utils.Permissions;

/**
 * Spring MVC controller that handles CRUD requests for AdminUser entities
 * 
 */

@Controller("AdminUserController")
public class AdminUserController {

	/**
	 * DAO injected by Spring that manages AdminUser entities
	 * 
	 */
	@Autowired
	private AdminUserDAO adminUserDAO;

	/**
	 * DAO injected by Spring that manages AdminUserStore entities
	 * 
	 */
	@Autowired
	private AdminUserStoreDAO adminUserStoreDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private ProductService productService;

	/**
	 * DAO injected by Spring that manages AdminUserStore entities
	 * 
	 */
	@Autowired
	private LanguageDAO languageDAO;

	/**
	 * DAO injected by Spring that manages Role entities
	 * 
	 */
	@Autowired
	private RoleDAO roleDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for AdminUser entities
	 * 
	 */
	@Autowired
	private AdminUserService adminUserService;

	@RequestMapping(method = RequestMethod.GET) 
	public String showUserForm(ModelMap model)  { 
		UserSessionInfo userSessionInfo = new UserSessionInfo(); 
		model.addAttribute(userSessionInfo); 
		return "userForm"; 
	} 

	/**
	 * Select the AdminUser entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteAdminUser")
	public ModelAndView confirmDeleteAdminUser(@RequestParam Integer userIdKey) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser", adminUserDAO.findAdminUserByPrimaryKey(userIdKey));
		mav.setViewName("adminuser/deleteAdminUser.jsp");

		return mav;
	}

	/**
	 * View an existing Role entity
	 * 
	 */
	@RequestMapping("/selectAdminUserRole")
	public ModelAndView selectAdminUserRole(@RequestParam Integer adminuser_userId, @RequestParam Integer role_roleId) {
		Role role = roleDAO.findRoleByPrimaryKey(role_roleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("role", role);
		mav.setViewName("adminuser/role/viewRole.jsp");

		return mav;
	}

	/**
	 * Select the child AdminUserStore entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteAdminUserAdminUserStores")
	public ModelAndView confirmDeleteAdminUserAdminUserStores(@RequestParam Integer adminuser_userId, @RequestParam Integer related_adminuserstores_adminUserId, @RequestParam Integer related_adminuserstores_storeId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuserstore", adminUserStoreDAO.findAdminUserStoreByPrimaryKey(related_adminuserstores_adminUserId, related_adminuserstores_storeId));
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.setViewName("adminuser/adminuserstores/deleteAdminUserStores.jsp");

		return mav;
	}

	/**
	 * Entry point to show all AdminUser entities
	 * 
	 */
	public String indexAdminUser() {
		return "redirect:/indexAdminUser";
	}

	/**
	 * Show all AdminUser entities
	 * 
	 */
	@RequestMapping("/indexAdminUser")
	public ModelAndView listAdminUsers() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminusers", adminUserService.loadAdminUsers());

		mav.setViewName("adminuser/listAdminUsers.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/adminuserController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Show all AdminUserStore entities by AdminUser
	 * 
	 */
	@RequestMapping("/listAdminUserAdminUserStores")
	public ModelAndView listAdminUserAdminUserStores(@RequestParam Integer userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuser", adminUserDAO.findAdminUserByPrimaryKey(userIdKey));
		mav.setViewName("adminuser/adminuserstores/listAdminUserStores.jsp");

		return mav;
	}

	/**
	 * Edit an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/editAdminUserAdminUserStores")
	public ModelAndView editAdminUserAdminUserStores(@RequestParam Integer adminuser_userId, @RequestParam Integer adminuserstores_adminUserId, @RequestParam Integer adminuserstores_storeId) {

		AdminUserStore adminuserstore = adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminuserstores_adminUserId, adminuserstores_storeId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("adminuserstore", adminuserstore);	
		
		mav.setViewName("adminuser/adminuserstores/editAdminUserStores.jsp");

		return mav;
	}

	/**
	 * Save an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/saveAdminUserAdminUserStores")
	public ModelAndView saveAdminUserAdminUserStores(@RequestParam Integer adminuser_userId, @ModelAttribute AdminUserStore adminuserstores) {
		AdminUser parent_adminuser = adminUserService.saveAdminUserAdminUserStores(adminuser_userId, adminuserstores);

		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("adminuser", parent_adminuser);
		mav.setViewName("adminuser/viewAdminUser.jsp");

		return mav;
	}

	/**
	 * Create a new AdminUserStore entity
	 * 
	 */
	@RequestMapping("/newAdminUserAdminUserStores")
	public ModelAndView newAdminUserAdminUserStores(@RequestParam Integer adminuser_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("adminuserstore", new AdminUserStore());
		mav.addObject("newFlag", true);
		mav.setViewName("adminuser/adminuserstores/editAdminUserStores.jsp");

		return mav;
	}

	/**
	 * Edit an existing AdminUser entity
	 * 
	 */
	@RequestMapping("/editAdminUser")
	public ModelAndView editAdminUser(@RequestParam Integer userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuser", adminUserDAO.findAdminUserByPrimaryKey(userIdKey));
		setLanguages(mav);
		mav.setViewName("adminuser/editAdminUser.jsp");

		return mav;
	}

	/**
	 * Edit an existing Role entity
	 * 
	 */
	@RequestMapping("/editAdminUserRole")
	public ModelAndView editAdminUserRole(@RequestParam Integer adminuser_userId, @RequestParam Integer role_roleId) {
		Role role = roleDAO.findRoleByPrimaryKey(role_roleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("role", role);
		mav.setViewName("adminuser/role/editRole.jsp");

		return mav;
	}

	/**
	 * Delete an existing AdminUser entity
	 * 
	 */
	@RequestMapping("/deleteAdminUser")
	public String deleteAdminUser(@RequestParam Integer userIdKey) {
		AdminUser adminuser = adminUserDAO.findAdminUserByPrimaryKey(userIdKey);
		adminUserService.deleteAdminUser(adminuser);
		return "forward:/indexAdminUser";
	}

	private void setLanguages(ModelAndView mav)
	{
		Set<Language> set = languageDAO.findAllLanguages();
		Iterator<Language> i = set.iterator();
		ArrayList<Language> list = new ArrayList<Language>();
		while (i.hasNext())
		{
			list.add(i.next());
		}
		
		System.out.print("lang size "+list.size());
		
		mav.addObject("languages",list);		
	}
	/**
	 * Create a new AdminUser entity
	 * 
	 */
	@RequestMapping("/newAdminUser")
	public ModelAndView newAdminUser() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuser", new AdminUser());
		mav.addObject("newFlag", true);
		setLanguages(mav);
		mav.setViewName("adminuser/editAdminUser.jsp");

		return mav;
	}

	/**
	 * Save an existing Role entity
	 * 
	 */
	@RequestMapping("/saveAdminUserRole")
	public ModelAndView saveAdminUserRole(@RequestParam Integer adminuser_userId, @ModelAttribute Role role) {
		AdminUser parent_adminuser = adminUserService.saveAdminUserRole(adminuser_userId, role);

		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("adminuser", parent_adminuser);
		mav.setViewName("adminuser/viewAdminUser.jsp");

		return mav;
	}

	/**
	 * Show all Role entities by AdminUser
	 * 
	 */
	@RequestMapping("/listAdminUserRole")
	public ModelAndView listAdminUserRole(@RequestParam Integer userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuser", adminUserDAO.findAdminUserByPrimaryKey(userIdKey));
		mav.setViewName("adminuser/role/listRole.jsp");

		return mav;
	}

	/**
	 * Create a new Role entity
	 * 
	 */
	@RequestMapping("/newAdminUserRole")
	public ModelAndView newAdminUserRole(@RequestParam Integer adminuser_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("role", new Role());
		mav.addObject("newFlag", true);
		mav.setViewName("adminuser/role/editRole.jsp");

		return mav;
	}

	/**
	 * Delete an existing Role entity
	 * 
	 */
	@RequestMapping("/deleteAdminUserRole")
	public ModelAndView deleteAdminUserRole(@RequestParam Integer adminuser_userId, @RequestParam Integer related_role_roleId) {
		ModelAndView mav = new ModelAndView();

		AdminUser adminuser = adminUserService.deleteAdminUserRole(adminuser_userId, related_role_roleId);

		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("adminuser", adminuser);
		mav.setViewName("adminuser/viewAdminUser.jsp");

		return mav;
	}

	/**
	 * Delete an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/deleteAdminUserAdminUserStores")
	public ModelAndView deleteAdminUserAdminUserStores(@RequestParam Integer adminuser_userId, @RequestParam Integer related_adminuserstores_adminUserId, @RequestParam Integer related_adminuserstores_storeId) {
		ModelAndView mav = new ModelAndView();

		AdminUser adminuser = adminUserService.deleteAdminUserAdminUserStores(adminuser_userId, related_adminuserstores_adminUserId, related_adminuserstores_storeId);

		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("adminuser", adminuser);
		mav.setViewName("adminuser/viewAdminUser.jsp");

		return mav;
	}

	/**
	 * Save an existing AdminUser entity
	 * 
	 */
	@RequestMapping("/saveAdminUser")
	public String saveAdminUser(@ModelAttribute AdminUser adminuser) {
		adminUserService.saveAdminUser(adminuser);
		return "forward:/indexAdminUser";
	}

	/**
	 * Select an existing AdminUser entity
	 * 
	 */
	@RequestMapping("/selectAdminUser")
	public ModelAndView selectAdminUser(@RequestParam Integer userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuser", adminUserDAO.findAdminUserByPrimaryKey(userIdKey));
		mav.setViewName("adminuser/viewAdminUser.jsp");

		return mav;
	}

	/**
	 * Select the child Role entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteAdminUserRole")
	public ModelAndView confirmDeleteAdminUserRole(@RequestParam Integer adminuser_userId, @RequestParam Integer related_role_roleId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("role", roleDAO.findRoleByPrimaryKey(related_role_roleId));
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.setViewName("adminuser/role/deleteRole.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		System.out.println("**** initBinder  *****");
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * View an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/selectAdminUserAdminUserStores")
	public ModelAndView selectAdminUserAdminUserStores(@RequestParam Integer adminuser_userId, @RequestParam Integer adminuserstores_adminUserId, @RequestParam Integer adminuserstores_storeId) {
		AdminUserStore adminuserstore = adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminuserstores_adminUserId, adminuserstores_storeId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("adminuser_userId", adminuser_userId);
		mav.addObject("adminuserstore", adminuserstore);
		mav.setViewName("adminuser/adminuserstores/viewAdminUserStores.jsp");

		return mav;
	}
	
	/**
	 * Create a new AdminUser entity
	 * 
	 */
	@RequestMapping("/loginAdminUser")
	public ModelAndView loginAdminUser() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuser", new AdminUser());
		mav.addObject("newFlag", true);
		mav.setViewName("adminuser/loginAdminUser.jsp");

		return mav;
	}
	
	/**
	 * Show all AdminUser entities
	 * 
	 */
//	@Autowired(required=true)
//	private HttpServletRequest request;
	@RequestMapping("/validateAdminUser")
	public ModelAndView validateAdminUsers(@ModelAttribute AdminUser adminuser, 
										   HttpServletRequest request ) {
		
		System.out.println("inside validate user pn "+request.getParameter("name"));
		System.out.println("inside validate user pn "+request.getParameter("password"));
		   
		ModelAndView mav = new ModelAndView();
		String userName=adminuser.getName();//request.getParameter("userName");
		String password=adminuser.getPassword();//request.getParameter("userPassword");

		System.out.println("inside validate user pwd "+password);		
		if(adminUserService.validateAdminUsers(userName,password, request)){
			mav.addObject("products", productService.loadProducts());
			boolean isAddAllowed = false;
			boolean isDelAllowed = false;
			boolean isEditAllowed = false;
			boolean isViewAllowed = false;
			isAddAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_ADD_PRODUCT);
			isDelAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_DELETE_PRODUCT);
			isEditAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_EDIT_PRODUCT);
			isViewAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_VIEW_PRODUCT);
	        System.out.println("Is Del Allowed "+isDelAllowed);
	        isDelAllowed = false;
			mav.addObject("isAddAllowed",isAddAllowed);
			mav.addObject("isEditAllowed",isEditAllowed);
			mav.addObject("isDelAllowed",isDelAllowed);
			mav.addObject("isViewAllowed",isViewAllowed);
			mav.setViewName("product/listProducts.jsp");
			//mav.setViewName("adminuser/userSuccess.jsp");
		}else{
			mav.addObject("adminuser", new AdminUser());
			mav.addObject("ERR_MSG", "Invalid User/Password");
			mav.setViewName("adminuser/loginAdminUser.jsp");
		}
		//mav.addObject("adminusers", adminUserService.validateAdminUsers());

		//mav.setViewName("adminuser/listAdminUsers.jsp");

		return mav;
	}	
}
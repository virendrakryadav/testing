package com.ecom.web;

import com.ecom.dao.LanguageDAO;

import com.ecom.domain.Language;

import com.ecom.service.LanguageService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for Language entities
 * 
 */

@Controller("LanguageController")
public class LanguageController {

	/**
	 * DAO injected by Spring that manages Language entities
	 * 
	 */
	@Autowired
	private LanguageDAO languageDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for Language entities
	 * 
	 */
	@Autowired
	private LanguageService languageService;

	/**
	 * Select an existing Language entity
	 * 
	 */
	@RequestMapping("/selectLanguage")
	public ModelAndView selectLanguage(@RequestParam Integer langIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("language", languageDAO.findLanguageByPrimaryKey(langIdKey));
		mav.setViewName("language/viewLanguage.jsp");

		return mav;
	}

	/**
	 * Entry point to show all Language entities
	 * 
	 */
	public String indexLanguage() {
		return "redirect:/indexLanguage";
	}

	/**
	 * Edit an existing Language entity
	 * 
	 */
	@RequestMapping("/editLanguage")
	public ModelAndView editLanguage(@RequestParam Integer langIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("language", languageDAO.findLanguageByPrimaryKey(langIdKey));
		mav.setViewName("language/editLanguage.jsp");

		return mav;
	}

	/**
	 * Show all Language entities
	 * 
	 */
	@RequestMapping("/indexLanguage")
	public ModelAndView listLanguages() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("languages", languageService.loadLanguages());

		mav.setViewName("language/listLanguages.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Save an existing Language entity
	 * 
	 */
	@RequestMapping("/saveLanguage")
	public String saveLanguage(@ModelAttribute Language language) {
		languageService.saveLanguage(language);
		return "forward:/indexLanguage";
	}

	/**
	 * Delete an existing Language entity
	 * 
	 */
	@RequestMapping("/deleteLanguage")
	public String deleteLanguage(@RequestParam Integer langIdKey) {
		Language language = languageDAO.findLanguageByPrimaryKey(langIdKey);
		languageService.deleteLanguage(language);
		return "forward:/indexLanguage";
	}

	/**
	 * Create a new Language entity
	 * 
	 */
	@RequestMapping("/newLanguage")
	public ModelAndView newLanguage() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("language", new Language());
		mav.addObject("newFlag", true);
		mav.setViewName("language/editLanguage.jsp");

		return mav;
	}

	/**
	 * Select the Language entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteLanguage")
	public ModelAndView confirmDeleteLanguage(@RequestParam Integer langIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("language", languageDAO.findLanguageByPrimaryKey(langIdKey));
		mav.setViewName("language/deleteLanguage.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/languageController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}
}
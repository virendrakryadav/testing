package com.ecom.web;

import java.util.ArrayList;
import java.util.Set;

import com.ecom.dao.CategoryDAO;
import com.ecom.dao.CategoryDescDAO;
import com.ecom.dao.DesignerDAO;
import com.ecom.dao.DesignerDescDAO;
import com.ecom.dao.KeywordDAO;
import com.ecom.dao.KeywordDescDAO;
import com.ecom.dao.ProductCustomFieldDAO;
import com.ecom.dao.ProductCustomFieldValDAO;
import com.ecom.dao.ProductDAO;
import com.ecom.dao.ProductDescDAO;
import com.ecom.dao.ProductKeywordDAO;
import com.ecom.dao.ProductMediaDAO;
import com.ecom.dao.StoreDAO;

import com.ecom.domain.Category;
import com.ecom.domain.CategoryDesc;
import com.ecom.domain.Designer;
import com.ecom.domain.DesignerDesc;
import com.ecom.domain.Keyword;
import com.ecom.domain.KeywordDesc;
import com.ecom.domain.Product;
import com.ecom.domain.ProductCustomField;
import com.ecom.domain.ProductCustomFieldVal;
import com.ecom.domain.ProductDesc;
import com.ecom.domain.ProductKeyword;
import com.ecom.domain.ProductMedia;
import com.ecom.domain.Store;

import com.ecom.service.ProductService;
import com.ecom.session.UserSessionInfo;
import com.ecom.utils.Permissions;
import com.ecom.utils.Common;
import com.ecom.utils.Util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for Product entities
 * 
 */

@Controller("ProductController")
public class ProductController {

	/**
	 * DAO injected by Spring that manages Designer entities
	 * 
	 */
	@Autowired
	private DesignerDAO designerDAO;

	/**
	 * DAO injected by Spring that manages Designer entities
	 * 
	 */
	@Autowired
	private DesignerDescDAO designerDescDAO;
	/**
	 * DAO injected by Spring that manages ProductCustomField entities
	 * 
	 */
	@Autowired
	private ProductCustomFieldDAO productCustomFieldDAO;

	/**
	 * DAO injected by Spring that manages ProductCustomFieldVal entities
	 * 
	 */
	@Autowired
	private ProductCustomFieldValDAO productCustomFieldValDAO;

	/**
	 * DAO injected by Spring that manages Product entities
	 * 
	 */
	@Autowired
	private ProductDAO productDAO;

	/**
	 * DAO injected by Spring that manages ProductDesc entities
	 * 
	 */
	@Autowired
	private ProductDescDAO productDescDAO;

	/**
	 * DAO injected by Spring that manages ProductKeyword entities
	 * 
	 */
	@Autowired
	private ProductKeywordDAO productKeywordDAO;

	/**
	 * DAO injected by Spring that manages ProductMedia entities
	 * 
	 */
	@Autowired
	private ProductMediaDAO productMediaDAO;

	/**
	 * DAO injected by Spring that manages Store entities
	 * 
	 */
	@Autowired
	private StoreDAO storeDAO;

	
	@Autowired 
	private KeywordDAO keywordDAO;
	
	/**
	 * DAO injected by Spring that manages Store entities
	 * 
	 */
	@Autowired
	private KeywordDescDAO keywordDescDAO;
	
	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private ProductService productService;

	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private CategoryDAO categoryDAO;
	
	/**
	 * Service injected by Spring that provides CRUD operations for Product entities
	 * 
	 */
	@Autowired
	private CategoryDescDAO categoryDescDAO;
		
	/**
	 * Entry point to show all Product entities
	 * 
	 */
	public String indexProduct() {
		return "redirect:/indexProduct";
	}

	/**
	 * Save an existing ProductCustomField entity
	 * 
	 */
	@RequestMapping("/saveProductProductCustomFields")
	public ModelAndView saveProductProductCustomFields(@RequestParam Integer product_prodId, @ModelAttribute ProductCustomField productcustomfields) {
		Product parent_product = productService.saveProductProductCustomFields(product_prodId, productcustomfields);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", parent_product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Edit an existing ProductCustomField entity
	 * 
	 */
	@RequestMapping("/editProductProductCustomFields")
	public ModelAndView editProductProductCustomFields(@RequestParam Integer product_prodId, @RequestParam Integer productcustomfields_prodId, @RequestParam Integer productcustomfields_customFieldId) {
		ProductCustomField productcustomfield = productCustomFieldDAO.findProductCustomFieldByPrimaryKey(productcustomfields_prodId, productcustomfields_customFieldId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productcustomfield", productcustomfield);
		mav.setViewName("product/productcustomfields/editProductCustomFields.jsp");

		return mav;
	}

	/**
	 * Edit an existing ProductCustomFieldVal entity
	 * 
	 */
	@RequestMapping("/editProductProductCustomFieldVals")
	public ModelAndView editProductProductCustomFieldVals(@RequestParam Integer product_prodId, @RequestParam Integer productcustomfieldvals_prodId, @RequestParam Integer productcustomfieldvals_langId, @RequestParam Integer productcustomfieldvals_customFieldId) {
		ProductCustomFieldVal productcustomfieldval = productCustomFieldValDAO.findProductCustomFieldValByPrimaryKey(productcustomfieldvals_prodId, productcustomfieldvals_langId, productcustomfieldvals_customFieldId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productcustomfieldval", productcustomfieldval);
		mav.setViewName("product/productcustomfieldvals/editProductCustomFieldVals.jsp");

		return mav;
	}

	/**
	 * Select the child Store entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProductStore")
	public ModelAndView confirmDeleteProductStore(@RequestParam Integer product_prodId, @RequestParam Integer related_store_storeId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("store", storeDAO.findStoreByPrimaryKey(related_store_storeId));
		mav.addObject("product_prodId", product_prodId);
		mav.setViewName("product/store/deleteStore.jsp");

		return mav;
	}

	/**
	 * View an existing ProductCustomField entity
	 * 
	 */
	@RequestMapping("/selectProductProductCustomFields")
	public ModelAndView selectProductProductCustomFields(@RequestParam Integer product_prodId, @RequestParam Integer productcustomfields_prodId, @RequestParam Integer productcustomfields_customFieldId) {
		ProductCustomField productcustomfield = productCustomFieldDAO.findProductCustomFieldByPrimaryKey(productcustomfields_prodId, productcustomfields_customFieldId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productcustomfield", productcustomfield);
		mav.setViewName("product/productcustomfields/viewProductCustomFields.jsp");

		return mav;
	}

	/**
	 * Delete an existing ProductCustomFieldVal entity
	 * 
	 */
	@RequestMapping("/deleteProductProductCustomFieldVals")
	public ModelAndView deleteProductProductCustomFieldVals(@RequestParam Integer product_prodId, @RequestParam Integer related_productcustomfieldvals_prodId, @RequestParam Integer related_productcustomfieldvals_langId, @RequestParam Integer related_productcustomfieldvals_customFieldId) {
		ModelAndView mav = new ModelAndView();

		Product product = productService.deleteProductProductCustomFieldVals(product_prodId, related_productcustomfieldvals_prodId, related_productcustomfieldvals_langId, related_productcustomfieldvals_customFieldId);

		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Select the child ProductCustomFieldVal entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProductProductCustomFieldVals")
	public ModelAndView confirmDeleteProductProductCustomFieldVals(@RequestParam Integer product_prodId, @RequestParam Integer related_productcustomfieldvals_prodId, @RequestParam Integer related_productcustomfieldvals_langId, @RequestParam Integer related_productcustomfieldvals_customFieldId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("productcustomfieldval", productCustomFieldValDAO.findProductCustomFieldValByPrimaryKey(related_productcustomfieldvals_prodId, related_productcustomfieldvals_langId, related_productcustomfieldvals_customFieldId));
		mav.addObject("product_prodId", product_prodId);
		mav.setViewName("product/productcustomfieldvals/deleteProductCustomFieldVals.jsp");

		return mav;
	}

	/**
	 * View an existing Store entity
	 * 
	 */
	@RequestMapping("/selectProductStore")
	public ModelAndView selectProductStore(@RequestParam Integer product_prodId, @RequestParam Integer store_storeId) {
		Store store = storeDAO.findStoreByPrimaryKey(store_storeId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("store", store);
		mav.setViewName("product/store/viewStore.jsp");

		return mav;
	}

	/**
	 * Save an existing Designer entity
	 * 
	 */
	@RequestMapping("/saveProductDesigner")
	public ModelAndView saveProductDesigner(@RequestParam Integer product_prodId, @ModelAttribute Designer designer) {
		Product parent_product = productService.saveProductDesigner(product_prodId, designer);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", parent_product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Select the child Designer entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProductDesigner")
	public ModelAndView confirmDeleteProductDesigner(@RequestParam Integer product_prodId, @RequestParam Integer related_designer_designerId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("designer", designerDAO.findDesignerByPrimaryKey(related_designer_designerId));
		mav.addObject("product_prodId", product_prodId);
		mav.setViewName("product/designer/deleteDesigner.jsp");

		return mav;
	}

	/**
	 * Select the child ProductKeyword entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProductProductKeywords")
	public ModelAndView confirmDeleteProductProductKeywords(@RequestParam Integer product_prodId, @RequestParam Integer related_productkeywords_prodId, @RequestParam Integer related_productkeywords_keywordId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("productkeyword", productKeywordDAO.findProductKeywordByPrimaryKey(related_productkeywords_prodId, related_productkeywords_keywordId));
		mav.addObject("product_prodId", product_prodId);
		mav.setViewName("product/productkeywords/deleteProductKeywords.jsp");

		return mav;
	}

	/**
	 * Save an existing ProductDesc entity
	 * 
	 */
	@RequestMapping("/saveProductProductDescs")
	public ModelAndView saveProductProductDescs(@RequestParam Integer product_prodId, @ModelAttribute ProductDesc productdescs) {
		Product parent_product = productService.saveProductProductDescs(product_prodId, productdescs);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", parent_product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Select the child ProductCustomField entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProductProductCustomFields")
	public ModelAndView confirmDeleteProductProductCustomFields(@RequestParam Integer product_prodId, @RequestParam Integer related_productcustomfields_prodId, @RequestParam Integer related_productcustomfields_customFieldId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("productcustomfield", productCustomFieldDAO.findProductCustomFieldByPrimaryKey(related_productcustomfields_prodId, related_productcustomfields_customFieldId));
		mav.addObject("product_prodId", product_prodId);
		mav.setViewName("product/productcustomfields/deleteProductCustomFields.jsp");

		return mav;
	}

	/**
	 * Edit an existing Designer entity
	 * 
	 */
	@RequestMapping("/editProductDesigner")
	public ModelAndView editProductDesigner(@RequestParam Integer product_prodId, @RequestParam Integer designer_designerId) {
		Designer designer = designerDAO.findDesignerByPrimaryKey(designer_designerId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("designer", designer);
		mav.setViewName("product/designer/editDesigner.jsp");

		return mav;
	}

	/**
	 * Edit an existing ProductKeyword entity
	 * 
	 */
	@RequestMapping("/editProductProductKeywords")
	public ModelAndView editProductProductKeywords(@RequestParam Integer product_prodId, @RequestParam Integer productkeywords_prodId, @RequestParam Integer productkeywords_keywordId) {
		ProductKeyword productkeyword = productKeywordDAO.findProductKeywordByPrimaryKey(productkeywords_prodId, productkeywords_keywordId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productkeyword", productkeyword);
		mav.setViewName("product/productkeywords/editProductKeywords.jsp");

		return mav;
	}

	/**
	 * Save an existing ProductMedia entity
	 * 
	 */
	@RequestMapping("/saveProductProductMedias")
	public ModelAndView saveProductProductMedias(@RequestParam Integer product_prodId, @ModelAttribute ProductMedia productmedias) {
		Product parent_product = productService.saveProductProductMedias(product_prodId, productmedias);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", parent_product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Select the child ProductMedia entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProductProductMedias")
	public ModelAndView confirmDeleteProductProductMedias(@RequestParam Integer product_prodId, @RequestParam Integer related_productmedias_prodId, @RequestParam Integer related_productmedias_langId, @RequestParam Integer related_productmedias_mediaId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("productmedia", productMediaDAO.findProductMediaByPrimaryKey(related_productmedias_prodId, related_productmedias_langId, related_productmedias_mediaId));
		mav.addObject("product_prodId", product_prodId);
		mav.setViewName("product/productmedias/deleteProductMedias.jsp");

		return mav;
	}

	/**
	 * Create a new ProductKeyword entity
	 * 
	 */
	@RequestMapping("/newProductProductKeywords")
	public ModelAndView newProductProductKeywords(@RequestParam Integer product_prodId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productkeyword", new ProductKeyword());
		mav.addObject("newFlag", true);
		mav.setViewName("product/productkeywords/editProductKeywords.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/productController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * View an existing ProductKeyword entity
	 * 
	 */
	@RequestMapping("/selectProductProductKeywords")
	public ModelAndView selectProductProductKeywords(@RequestParam Integer product_prodId, @RequestParam Integer productkeywords_prodId, @RequestParam Integer productkeywords_keywordId) {
		ProductKeyword productkeyword = productKeywordDAO.findProductKeywordByPrimaryKey(productkeywords_prodId, productkeywords_keywordId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productkeyword", productkeyword);
		mav.setViewName("product/productkeywords/viewProductKeywords.jsp");

		return mav;
	}

	/**
	 * Create a new Designer entity
	 * 
	 */
	@RequestMapping("/newProductDesigner")
	public ModelAndView newProductDesigner(@RequestParam Integer product_prodId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("designer", new Designer());
		mav.addObject("newFlag", true);
		mav.setViewName("product/designer/editDesigner.jsp");

		return mav;
	}

	/**
	 * Show all Designer entities by Product
	 * 
	 */
	@RequestMapping("/listProductDesigner")
	public ModelAndView listProductDesigner(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/designer/listDesigner.jsp");

		return mav;
	}

	/**
	 * Delete an existing Product entity
	 * 
	 */
	@RequestMapping("/deleteProduct")
	public String deleteProduct(@RequestParam Integer prodIdKey) {
		Product product = productDAO.findProductByPrimaryKey(prodIdKey);
		productService.deleteProduct(product);
		return "forward:/indexProduct";
	}

	/**
	 * Create a new ProductCustomField entity
	 * 
	 */
	@RequestMapping("/newProductProductCustomFields")
	public ModelAndView newProductProductCustomFields(@RequestParam Integer product_prodId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productcustomfield", new ProductCustomField());
		mav.addObject("newFlag", true);
		mav.setViewName("product/productcustomfields/editProductCustomFields.jsp");

		return mav;
	}

	/**
	 * Edit an existing ProductMedia entity
	 * 
	 */
	@RequestMapping("/editProductProductMedias")
	public ModelAndView editProductProductMedias(@RequestParam Integer product_prodId, @RequestParam Integer productmedias_prodId, @RequestParam Integer productmedias_langId, @RequestParam Integer productmedias_mediaId) {
		ProductMedia productmedia = productMediaDAO.findProductMediaByPrimaryKey(productmedias_prodId, productmedias_langId, productmedias_mediaId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productmedia", productmedia);
		mav.setViewName("product/productmedias/editProductMedias.jsp");

		return mav;
	}

	/**
	 * Create a new ProductCustomFieldVal entity
	 * 
	 */
	@RequestMapping("/newProductProductCustomFieldVals")
	public ModelAndView newProductProductCustomFieldVals(@RequestParam Integer product_prodId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productcustomfieldval", new ProductCustomFieldVal());
		mav.addObject("newFlag", true);
		mav.setViewName("product/productcustomfieldvals/editProductCustomFieldVals.jsp");

		return mav;
	}

	/**
	 * Delete an existing Store entity
	 * 
	 */
	@RequestMapping("/deleteProductStore")
	public ModelAndView deleteProductStore(@RequestParam Integer product_prodId, @RequestParam Integer related_store_storeId) {
		ModelAndView mav = new ModelAndView();

		Product product = productService.deleteProductStore(product_prodId, related_store_storeId);

		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * View an existing Designer entity
	 * 
	 */
	@RequestMapping("/selectProductDesigner")
	public ModelAndView selectProductDesigner(@RequestParam Integer product_prodId, @RequestParam Integer designer_designerId) {
		Designer designer = designerDAO.findDesignerByPrimaryKey(designer_designerId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("designer", designer);
		mav.setViewName("product/designer/viewDesigner.jsp");

		return mav;
	}

	/**
	 * Delete an existing ProductMedia entity
	 * 
	 */
	@RequestMapping("/deleteProductProductMedias")
	public ModelAndView deleteProductProductMedias(@RequestParam Integer product_prodId, @RequestParam Integer related_productmedias_prodId, @RequestParam Integer related_productmedias_langId, @RequestParam Integer related_productmedias_mediaId) {
		ModelAndView mav = new ModelAndView();

		Product product = productService.deleteProductProductMedias(product_prodId, related_productmedias_prodId, related_productmedias_langId, related_productmedias_mediaId);

		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * View an existing ProductDesc entity
	 * 
	 */
	@RequestMapping("/selectProductProductDescs")
	public ModelAndView selectProductProductDescs(@RequestParam Integer product_prodId, @RequestParam Integer productdescs_prodId, @RequestParam Integer productdescs_langId) {
		ProductDesc productdesc = productDescDAO.findProductDescByPrimaryKey(productdescs_prodId, productdescs_langId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productdesc", productdesc);
		mav.setViewName("product/productdescs/viewProductDescs.jsp");

		return mav;
	}

	/**
	 * Show all ProductMedia entities by Product
	 * 
	 */
	@RequestMapping("/listProductProductMedias")
	public ModelAndView listProductProductMedias(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/productmedias/listProductMedias.jsp");

		return mav;
	}

	/**
	 * Save an existing ProductKeyword entity
	 * 
	 */
	@RequestMapping("/saveProductProductKeywords")
	public ModelAndView saveProductProductKeywords(@RequestParam Integer product_prodId, @ModelAttribute ProductKeyword productkeywords) {
		Product parent_product = productService.saveProductProductKeywords(product_prodId, productkeywords);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", parent_product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Save an existing Product entity
	 * 
	 */
	@RequestMapping("/saveProductAndDetails")
	public String saveProduct(@ModelAttribute Product product) {
		System.out.println("The output is product ["+product+"]");
		System.out.println("The output is "+product.getProductDescs());
		productService.saveProduct(product);
		return "forward:/indexProduct";
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Select the Product entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProduct")
	public ModelAndView confirmDeleteProduct(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/deleteProduct.jsp");

		return mav;
	}

	/**
	 * Show all ProductCustomFieldVal entities by Product
	 * 
	 */
	@RequestMapping("/listProductProductCustomFieldVals")
	public ModelAndView listProductProductCustomFieldVals(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/productcustomfieldvals/listProductCustomFieldVals.jsp");

		return mav;
	}

	/**
	 * Create a new ProductDesc entity
	 * 
	 */
	@RequestMapping("/newProductProductDescs")
	public ModelAndView newProductProductDescs(@RequestParam Integer product_prodId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productdesc", new ProductDesc());
		mav.addObject("newFlag", true);
		mav.setViewName("product/productdescs/editProductDescs.jsp");

		return mav;
	}

	/**
	 * Delete an existing ProductDesc entity
	 * 
	 */
	@RequestMapping("/deleteProductProductDescs")
	public ModelAndView deleteProductProductDescs(@RequestParam Integer product_prodId, @RequestParam Integer related_productdescs_prodId, @RequestParam Integer related_productdescs_langId) {
		ModelAndView mav = new ModelAndView();

		Product product = productService.deleteProductProductDescs(product_prodId, related_productdescs_prodId, related_productdescs_langId);

		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Save an existing ProductCustomFieldVal entity
	 * 
	 */
	@RequestMapping("/saveProductProductCustomFieldVals")
	public ModelAndView saveProductProductCustomFieldVals(@RequestParam Integer product_prodId, @ModelAttribute ProductCustomFieldVal productcustomfieldvals) {
		Product parent_product = productService.saveProductProductCustomFieldVals(product_prodId, productcustomfieldvals);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", parent_product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Show all ProductCustomField entities by Product
	 * 
	 */
	@RequestMapping("/listProductProductCustomFields")
	public ModelAndView listProductProductCustomFields(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/productcustomfields/listProductCustomFields.jsp");

		return mav;
	}

	/**
	 * Create a new Product entity
	 * 
	 */
	@RequestMapping("/newProduct")
	public ModelAndView newProduct(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", new Product());
		mav.addObject("newFlag", true);
		UserSessionInfo  userSessionInfo = Common.getUserSessionInfo(request);
		populateModel(mav,userSessionInfo);
		mav.setViewName("product/editProduct.jsp");

		return mav;
	}

	/**
	 * Select the child ProductDesc entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteProductProductDescs")
	public ModelAndView confirmDeleteProductProductDescs(@RequestParam Integer product_prodId, @RequestParam Integer related_productdescs_prodId, @RequestParam Integer related_productdescs_langId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("productdesc", productDescDAO.findProductDescByPrimaryKey(related_productdescs_prodId, related_productdescs_langId));
		mav.addObject("product_prodId", product_prodId);
		mav.setViewName("product/productdescs/deleteProductDescs.jsp");

		return mav;
	}

	/**
	 * Delete an existing Designer entity
	 * 
	 */
	@RequestMapping("/deleteProductDesigner")
	public ModelAndView deleteProductDesigner(@RequestParam Integer product_prodId, @RequestParam Integer related_designer_designerId) {
		ModelAndView mav = new ModelAndView();

		Product product = productService.deleteProductDesigner(product_prodId, related_designer_designerId);

		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Show all Store entities by Product
	 * 
	 */
	@RequestMapping("/listProductStore")
	public ModelAndView listProductStore(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/store/listStore.jsp");

		return mav;
	}

	/**
	 * Delete an existing ProductKeyword entity
	 * 
	 */
	@RequestMapping("/deleteProductProductKeywords")
	public ModelAndView deleteProductProductKeywords(@RequestParam Integer product_prodId, @RequestParam Integer related_productkeywords_prodId, @RequestParam Integer related_productkeywords_keywordId) {
		ModelAndView mav = new ModelAndView();

		Product product = productService.deleteProductProductKeywords(product_prodId, related_productkeywords_prodId, related_productkeywords_keywordId);

		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Edit an existing ProductDesc entity
	 * 
	 */
	@RequestMapping("/editProductProductDescs")
	public ModelAndView editProductProductDescs(@RequestParam Integer product_prodId, @RequestParam Integer productdescs_prodId, @RequestParam Integer productdescs_langId) {
		ProductDesc productdesc = productDescDAO.findProductDescByPrimaryKey(productdescs_prodId, productdescs_langId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productdesc", productdesc);
		mav.setViewName("product/productdescs/editProductDescs.jsp");

		return mav;
	}

	/**
	 * Save an existing Store entity
	 * 
	 */
	@RequestMapping("/saveProductStore")
	public ModelAndView saveProductStore(@RequestParam Integer product_prodId, @ModelAttribute Store store) {
		Product parent_product = productService.saveProductStore(product_prodId, store);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", parent_product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * View an existing ProductCustomFieldVal entity
	 * 
	 */
	@RequestMapping("/selectProductProductCustomFieldVals")
	public ModelAndView selectProductProductCustomFieldVals(@RequestParam Integer product_prodId, @RequestParam Integer productcustomfieldvals_prodId, @RequestParam Integer productcustomfieldvals_langId, @RequestParam Integer productcustomfieldvals_customFieldId) {
		ProductCustomFieldVal productcustomfieldval = productCustomFieldValDAO.findProductCustomFieldValByPrimaryKey(productcustomfieldvals_prodId, productcustomfieldvals_langId, productcustomfieldvals_customFieldId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productcustomfieldval", productcustomfieldval);
		mav.setViewName("product/productcustomfieldvals/viewProductCustomFieldVals.jsp");

		return mav;
	}

	/**
	 * Show all ProductDesc entities by Product
	 * 
	 */
	@RequestMapping("/listProductProductDescs")
	public ModelAndView listProductProductDescs(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/productdescs/listProductDescs.jsp");

		return mav;
	}

	/**
	 * Edit an existing Store entity
	 * 
	 */
	@RequestMapping("/editProductStore")
	public ModelAndView editProductStore(@RequestParam Integer product_prodId, @RequestParam Integer store_storeId) {
		Store store = storeDAO.findStoreByPrimaryKey(store_storeId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("store", store);
		mav.setViewName("product/store/editStore.jsp");

		return mav;
	}

	/**
	 * Create a new Store entity
	 * 
	 */
	@RequestMapping("/newProductStore")
	public ModelAndView newProductStore(@RequestParam Integer product_prodId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("store", new Store());
		mav.addObject("newFlag", true);
		mav.setViewName("product/store/editStore.jsp");

		return mav;
	}

	/**
	 * Select an existing Product entity
	 * 
	 */
	@RequestMapping("/selectProduct")
	public ModelAndView selectProduct(@RequestParam Integer prodIdKey,HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		UserSessionInfo  userSessionInfo = Common.getUserSessionInfo(request);
		populateModel(mav,userSessionInfo);
		mav.addObject("viewFlag", true);
		mav.setViewName("product/editProduct.jsp");
		return mav;
	}

	/**
	 * Show all ProductKeyword entities by Product
	 * 
	 */
	@RequestMapping("/listProductProductKeywords")
	public ModelAndView listProductProductKeywords(@RequestParam Integer prodIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		mav.setViewName("product/productkeywords/listProductKeywords.jsp");

		return mav;
	}

	/**
	 * Edit an existing Product entity
	 * 
	 */
	@RequestMapping("/editProduct")
	public ModelAndView editProduct(@RequestParam Integer prodIdKey,HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("product", productDAO.findProductByPrimaryKey(prodIdKey));
		UserSessionInfo  userSessionInfo = Common.getUserSessionInfo(request);
		populateModel(mav,userSessionInfo);
		mav.setViewName("product/editProduct.jsp");
		return mav;
	}

	/**
	 * Sets the data in the model
	 * @param mav
	 */
	private void populateModel(ModelAndView mav, UserSessionInfo userSessionInfo){

		System.out.println("The current lang is ["+userSessionInfo.currentLang+"]");
		Integer langId = userSessionInfo.currentLang.getLangId();
		Integer storeId = userSessionInfo.currentStoreDesc.getStoreId();
		
		Set<DesignerDesc> designerDescs = designerDescDAO.findDesignerDescByStoreId(storeId);
		ArrayList <DesignerDesc>alDesignerDesc = new ArrayList<DesignerDesc>();
		for(DesignerDesc designerDesc:designerDescs){
			alDesignerDesc.add(designerDesc);
		}

		// The Designer needs to be picked based on session session
		mav.addObject("designer",alDesignerDesc);
		
		Set<ProductDesc> productDescs = productDescDAO.findProductDescByStoreId(storeId);
		ArrayList <ProductDesc>alProductDesc = new ArrayList<ProductDesc>();
		
		for(ProductDesc productDesc: productDescs){
			alProductDesc.add(productDesc);
		}

		// The Designer needs to be picked based on session session
		mav.addObject("productdecs",alProductDesc);
		
		// populate keywords
		Set<Keyword> keywords = keywordDAO.findKeywordByStoreId(storeId); 
		ArrayList <KeywordDesc>alKeywordDesc = new ArrayList<KeywordDesc>();
		for(Keyword keyword:keywords){
			alKeywordDesc.add(keywordDescDAO.findKeywordDescByPrimaryKey(keyword.getKeywordId(),langId));
		}
		mav.addObject("keywords",alKeywordDesc);
		mav.addObject("weights", Util.getWeights());
		
		//populate Categories
		Set<Category>  catagories = categoryDAO.findCategoryByStoreId(storeId);
		ArrayList <CategoryDesc>alCategory = new ArrayList <CategoryDesc>();
		for(Category category:catagories){
			alCategory.add(categoryDescDAO.findCategoryDescByPrimaryKey(category.getCategoryId(), langId));
		}
		mav.addObject("category",alCategory);
	}
	/**
	 * View an existing ProductMedia entity
	 * 
	 */
	@RequestMapping("/selectProductProductMedias")
	public ModelAndView selectProductProductMedias(@RequestParam Integer product_prodId, @RequestParam Integer productmedias_prodId, @RequestParam Integer productmedias_langId, @RequestParam Integer productmedias_mediaId) {
		ProductMedia productmedia = productMediaDAO.findProductMediaByPrimaryKey(productmedias_prodId, productmedias_langId, productmedias_mediaId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productmedia", productmedia);
		mav.setViewName("product/productmedias/viewProductMedias.jsp");

		return mav;
	}

	/**
	 * Delete an existing ProductCustomField entity
	 * 
	 */
	@RequestMapping("/deleteProductProductCustomFields")
	public ModelAndView deleteProductProductCustomFields(@RequestParam Integer product_prodId, @RequestParam Integer related_productcustomfields_prodId, @RequestParam Integer related_productcustomfields_customFieldId) {
		ModelAndView mav = new ModelAndView();

		Product product = productService.deleteProductProductCustomFields(product_prodId, related_productcustomfields_prodId, related_productcustomfields_customFieldId);

		mav.addObject("product_prodId", product_prodId);
		mav.addObject("product", product);
		mav.setViewName("product/viewProduct.jsp");

		return mav;
	}

	/**
	 * Show all Product entities
	 * 
	 */
	@RequestMapping("/indexProduct")
	public ModelAndView listProducts(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("products", productService.loadProducts());
		boolean isAddAllowed= true;
		boolean isDelAllowed =true;
		boolean isEditAllowed = true;
		boolean isViewAllowed =true;
		try
		{
			//isAddAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_ADD_PRODUCT);
			//isDelAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_DELETE_PRODUCT);
			//isEditAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_EDIT_PRODUCT);
			//isViewAllowed = Permissions.isFeatureAllowed(request, Permissions.FEATURE_VIEW_PRODUCT);
		}catch (Exception e)
		{

		}
		mav.addObject("isAddAllowed",isAddAllowed);
		mav.addObject("isEditAllowed",isEditAllowed);
		mav.addObject("isDelAllowed",isDelAllowed);
		mav.addObject("isViewAllowed",isViewAllowed);

		mav.setViewName("product/listProducts.jsp");

		return mav;
	}

	/**
	 * Create a new ProductMedia entity
	 * 
	 */
	@RequestMapping("/newProductProductMedias")
	public ModelAndView newProductProductMedias(@RequestParam Integer product_prodId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("product_prodId", product_prodId);
		mav.addObject("productmedia", new ProductMedia());
		mav.addObject("newFlag", true);
		mav.setViewName("product/productmedias/editProductMedias.jsp");

		return mav;
	}
}
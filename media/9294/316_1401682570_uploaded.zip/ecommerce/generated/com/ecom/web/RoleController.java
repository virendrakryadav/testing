package com.ecom.web;

import com.ecom.dao.FeatureRoleDAO;
import com.ecom.dao.RoleDAO;
import com.ecom.dao.RoleDescDAO;

import com.ecom.domain.FeatureRole;
import com.ecom.domain.Role;
import com.ecom.domain.RoleDesc;

import com.ecom.service.RoleService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for Role entities
 * 
 */

@Controller("RoleController")
public class RoleController {

	/**
	 * DAO injected by Spring that manages FeatureRole entities
	 * 
	 */
	@Autowired
	private FeatureRoleDAO featureRoleDAO;

	/**
	 * DAO injected by Spring that manages Role entities
	 * 
	 */
	@Autowired
	private RoleDAO roleDAO;

	/**
	 * DAO injected by Spring that manages RoleDesc entities
	 * 
	 */
	@Autowired
	private RoleDescDAO roleDescDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for Role entities
	 * 
	 */
	@Autowired
	private RoleService roleService;

	/**
	 * Select an existing Role entity
	 * 
	 */
	@RequestMapping("/selectRole")
	public ModelAndView selectRole(@RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("role", roleDAO.findRoleByPrimaryKey(roleIdKey));
		mav.setViewName("role/viewRole.jsp");

		return mav;
	}

	/**
	 * Show all RoleDesc entities by Role
	 * 
	 */
	@RequestMapping("/listRoleRoleDescs")
	public ModelAndView listRoleRoleDescs(@RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("role", roleDAO.findRoleByPrimaryKey(roleIdKey));
		mav.setViewName("role/roledescs/listRoleDescs.jsp");

		return mav;
	}

	/**
	 * Entry point to show all Role entities
	 * 
	 */
	public String indexRole() {
		return "redirect:/indexRole";
	}

	/**
	 * Show all Role entities
	 * 
	 */
	@RequestMapping("/indexRole")
	public ModelAndView listRoles() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("roles", roleService.loadRoles());

		mav.setViewName("role/listRoles.jsp");

		return mav;
	}

	/**
	 * Delete an existing RoleDesc entity
	 * 
	 */
	@RequestMapping("/deleteRoleRoleDescs")
	public ModelAndView deleteRoleRoleDescs(@RequestParam Integer role_roleId, @RequestParam Integer related_roledescs_roleId, @RequestParam Integer related_roledescs_langId) {
		ModelAndView mav = new ModelAndView();

		Role role = roleService.deleteRoleRoleDescs(role_roleId, related_roledescs_roleId, related_roledescs_langId);

		mav.addObject("role_roleId", role_roleId);
		mav.addObject("role", role);
		mav.setViewName("role/viewRole.jsp");

		return mav;
	}

	/**
	 * Save an existing RoleDesc entity
	 * 
	 */
	@RequestMapping("/saveRoleRoleDescs")
	public ModelAndView saveRoleRoleDescs(@RequestParam Integer role_roleId, @ModelAttribute RoleDesc roledescs) {
		Role parent_role = roleService.saveRoleRoleDescs(role_roleId, roledescs);

		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("role", parent_role);
		mav.setViewName("role/viewRole.jsp");

		return mav;
	}

	/**
	 * Create a new Role entity
	 * 
	 */
	@RequestMapping("/newRole")
	public ModelAndView newRole() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("role", new Role());
		mav.addObject("newFlag", true);
		mav.setViewName("role/editRole.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/roleController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Save an existing Role entity
	 * 
	 */
	@RequestMapping("/saveRole")
	public String saveRole(@ModelAttribute Role role) {
		roleService.saveRole(role);
		return "forward:/indexRole";
	}

	/**
	 * Select the Role entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteRole")
	public ModelAndView confirmDeleteRole(@RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("role", roleDAO.findRoleByPrimaryKey(roleIdKey));
		mav.setViewName("role/deleteRole.jsp");

		return mav;
	}

	/**
	 * Show all FeatureRole entities by Role
	 * 
	 */
	@RequestMapping("/listRoleFeatureRoles")
	public ModelAndView listRoleFeatureRoles(@RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("role", roleDAO.findRoleByPrimaryKey(roleIdKey));
		mav.setViewName("role/featureroles/listFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Edit an existing RoleDesc entity
	 * 
	 */
	@RequestMapping("/editRoleRoleDescs")
	public ModelAndView editRoleRoleDescs(@RequestParam Integer role_roleId, @RequestParam Integer roledescs_roleId, @RequestParam Integer roledescs_langId) {
		RoleDesc roledesc = roleDescDAO.findRoleDescByPrimaryKey(roledescs_roleId, roledescs_langId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("roledesc", roledesc);
		mav.setViewName("role/roledescs/editRoleDescs.jsp");

		return mav;
	}

	/**
	 * Select the child FeatureRole entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteRoleFeatureRoles")
	public ModelAndView confirmDeleteRoleFeatureRoles(@RequestParam Integer role_roleId, @RequestParam Integer related_featureroles_featureId, @RequestParam Integer related_featureroles_roleId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featurerole", featureRoleDAO.findFeatureRoleByPrimaryKey(related_featureroles_featureId, related_featureroles_roleId));
		mav.addObject("role_roleId", role_roleId);
		mav.setViewName("role/featureroles/deleteFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Edit an existing Role entity
	 * 
	 */
	@RequestMapping("/editRole")
	public ModelAndView editRole(@RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("role", roleDAO.findRoleByPrimaryKey(roleIdKey));
		mav.setViewName("role/editRole.jsp");

		return mav;
	}

	/**
	 * Create a new RoleDesc entity
	 * 
	 */
	@RequestMapping("/newRoleRoleDescs")
	public ModelAndView newRoleRoleDescs(@RequestParam Integer role_roleId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("roledesc", new RoleDesc());
		mav.addObject("newFlag", true);
		mav.setViewName("role/roledescs/editRoleDescs.jsp");

		return mav;
	}

	/**
	 * Select the child RoleDesc entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteRoleRoleDescs")
	public ModelAndView confirmDeleteRoleRoleDescs(@RequestParam Integer role_roleId, @RequestParam Integer related_roledescs_roleId, @RequestParam Integer related_roledescs_langId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("roledesc", roleDescDAO.findRoleDescByPrimaryKey(related_roledescs_roleId, related_roledescs_langId));
		mav.addObject("role_roleId", role_roleId);
		mav.setViewName("role/roledescs/deleteRoleDescs.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/saveRoleFeatureRoles")
	public ModelAndView saveRoleFeatureRoles(@RequestParam Integer role_roleId, @ModelAttribute FeatureRole featureroles) {
		Role parent_role = roleService.saveRoleFeatureRoles(role_roleId, featureroles);

		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("role", parent_role);
		mav.setViewName("role/viewRole.jsp");

		return mav;
	}

	/**
	 * View an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/selectRoleFeatureRoles")
	public ModelAndView selectRoleFeatureRoles(@RequestParam Integer role_roleId, @RequestParam Integer featureroles_featureId, @RequestParam Integer featureroles_roleId) {
		FeatureRole featurerole = featureRoleDAO.findFeatureRoleByPrimaryKey(featureroles_featureId, featureroles_roleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("featurerole", featurerole);
		mav.setViewName("role/featureroles/viewFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Delete an existing Role entity
	 * 
	 */
	@RequestMapping("/deleteRole")
	public String deleteRole(@RequestParam Integer roleIdKey) {
		Role role = roleDAO.findRoleByPrimaryKey(roleIdKey);
		roleService.deleteRole(role);
		return "forward:/indexRole";
	}

	/**
	 * Create a new FeatureRole entity
	 * 
	 */
	@RequestMapping("/newRoleFeatureRoles")
	public ModelAndView newRoleFeatureRoles(@RequestParam Integer role_roleId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("featurerole", new FeatureRole());
		mav.addObject("newFlag", true);
		mav.setViewName("role/featureroles/editFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Edit an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/editRoleFeatureRoles")
	public ModelAndView editRoleFeatureRoles(@RequestParam Integer role_roleId, @RequestParam Integer featureroles_featureId, @RequestParam Integer featureroles_roleId) {
		FeatureRole featurerole = featureRoleDAO.findFeatureRoleByPrimaryKey(featureroles_featureId, featureroles_roleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("featurerole", featurerole);
		mav.setViewName("role/featureroles/editFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/deleteRoleFeatureRoles")
	public ModelAndView deleteRoleFeatureRoles(@RequestParam Integer role_roleId, @RequestParam Integer related_featureroles_featureId, @RequestParam Integer related_featureroles_roleId) {
		ModelAndView mav = new ModelAndView();

		Role role = roleService.deleteRoleFeatureRoles(role_roleId, related_featureroles_featureId, related_featureroles_roleId);

		mav.addObject("role_roleId", role_roleId);
		mav.addObject("role", role);
		mav.setViewName("role/viewRole.jsp");

		return mav;
	}

	/**
	 * View an existing RoleDesc entity
	 * 
	 */
	@RequestMapping("/selectRoleRoleDescs")
	public ModelAndView selectRoleRoleDescs(@RequestParam Integer role_roleId, @RequestParam Integer roledescs_roleId, @RequestParam Integer roledescs_langId) {
		RoleDesc roledesc = roleDescDAO.findRoleDescByPrimaryKey(roledescs_roleId, roledescs_langId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("role_roleId", role_roleId);
		mav.addObject("roledesc", roledesc);
		mav.setViewName("role/roledescs/viewRoleDescs.jsp");

		return mav;
	}
}
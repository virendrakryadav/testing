package com.ecom.web;

import com.ecom.dao.AdminUserStoreDAO;

import com.ecom.domain.AdminUserStore;

import com.ecom.service.AdminUserStoreService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for AdminUserStore entities
 * 
 */

@Controller("AdminUserStoreController")
public class AdminUserStoreController {

	/**
	 * DAO injected by Spring that manages AdminUserStore entities
	 * 
	 */
	@Autowired
	private AdminUserStoreDAO adminUserStoreDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for AdminUserStore entities
	 * 
	 */
	@Autowired
	private AdminUserStoreService adminUserStoreService;

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 */
	@RequestMapping("/adminuserstoreController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Show all AdminUserStore entities
	 * 
	 */
	@RequestMapping("/indexAdminUserStore")
	public ModelAndView listAdminUserStores() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuserstores", adminUserStoreService.loadAdminUserStores());

		mav.setViewName("adminuserstore/listAdminUserStores.jsp");

		return mav;
	}

	/**
	 * Entry point to show all AdminUserStore entities
	 * 
	 */
	public String indexAdminUserStore() {
		return "redirect:/indexAdminUserStore";
	}

	/**
	 * Select the AdminUserStore entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteAdminUserStore")
	public ModelAndView confirmDeleteAdminUserStore(@RequestParam Integer adminUserIdKey, @RequestParam Integer storeIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuserstore", adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminUserIdKey, storeIdKey));
		mav.setViewName("adminuserstore/deleteAdminUserStore.jsp");

		return mav;
	}

	/**
	 * Delete an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/deleteAdminUserStore")
	public String deleteAdminUserStore(@RequestParam Integer adminUserIdKey, @RequestParam Integer storeIdKey) {
		AdminUserStore adminuserstore = adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminUserIdKey, storeIdKey);
		adminUserStoreService.deleteAdminUserStore(adminuserstore);
		return "forward:/indexAdminUserStore";
	}

	/**
	 * Save an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/saveAdminUserStore")
	public String saveAdminUserStore(@ModelAttribute AdminUserStore adminuserstore) {
		adminUserStoreService.saveAdminUserStore(adminuserstore);
		return "forward:/indexAdminUserStore";
	}

	/**
	 * Select an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/selectAdminUserStore")
	public ModelAndView selectAdminUserStore(@RequestParam Integer adminUserIdKey, @RequestParam Integer storeIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuserstore", adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminUserIdKey, storeIdKey));
		mav.setViewName("adminuserstore/viewAdminUserStore.jsp");

		return mav;
	}

	/**
	 * Edit an existing AdminUserStore entity
	 * 
	 */
	@RequestMapping("/editAdminUserStore")
	public ModelAndView editAdminUserStore(@RequestParam Integer adminUserIdKey, @RequestParam Integer storeIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuserstore", adminUserStoreDAO.findAdminUserStoreByPrimaryKey(adminUserIdKey, storeIdKey));
		mav.setViewName("adminuserstore/editAdminUserStore.jsp");

		return mav;
	}

	/**
	 * Create a new AdminUserStore entity
	 * 
	 */
	@RequestMapping("/newAdminUserStore")
	public ModelAndView newAdminUserStore() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("adminuserstore", new AdminUserStore());
		mav.addObject("newFlag", true);
		mav.setViewName("adminuserstore/editAdminUserStore.jsp");

		return mav;
	}
}
package com.ecom.web;

import java.lang.annotation.Annotation;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

import com.ecom.domain.AdminUser;


public class EcomController implements Controller{
	
	public ModelAndView handleRequest(HttpServletRequest request,
            HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();

		System.out.println("Hello Welcome to Cistems");
		mav.addObject("adminuser", new AdminUser());
		mav.addObject("newFlag", true);
		mav.setViewName("adminuser/loginAdminUser.jsp");

		return mav;
       // return new ModelAndView("/WEB-INF/jsp/loginAdminUser.jsp");
    }

	@Override
	public Class<? extends Annotation> annotationType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String value() {
		// TODO Auto-generated method stub
		return null;
	}



}

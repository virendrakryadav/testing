package com.ecom.web;

import com.ecom.dao.FeatureRoleDAO;

import com.ecom.domain.FeatureRole;

import com.ecom.service.FeatureRoleService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for FeatureRole entities
 * 
 */

@Controller("FeatureRoleController")
public class FeatureRoleController {

	/**
	 * DAO injected by Spring that manages FeatureRole entities
	 * 
	 */
	@Autowired
	private FeatureRoleDAO featureRoleDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for FeatureRole entities
	 * 
	 */
	@Autowired
	private FeatureRoleService featureRoleService;

	/**
	 * Delete an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/deleteFeatureRole")
	public String deleteFeatureRole(@RequestParam Integer featureIdKey, @RequestParam Integer roleIdKey) {
		FeatureRole featurerole = featureRoleDAO.findFeatureRoleByPrimaryKey(featureIdKey, roleIdKey);
		featureRoleService.deleteFeatureRole(featurerole);
		return "forward:/indexFeatureRole";
	}

	/**
	 * Select the FeatureRole entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteFeatureRole")
	public ModelAndView confirmDeleteFeatureRole(@RequestParam Integer featureIdKey, @RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featurerole", featureRoleDAO.findFeatureRoleByPrimaryKey(featureIdKey, roleIdKey));
		mav.setViewName("featurerole/deleteFeatureRole.jsp");

		return mav;
	}

	/**
	 * Select an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/selectFeatureRole")
	public ModelAndView selectFeatureRole(@RequestParam Integer featureIdKey, @RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featurerole", featureRoleDAO.findFeatureRoleByPrimaryKey(featureIdKey, roleIdKey));
		mav.setViewName("featurerole/viewFeatureRole.jsp");

		return mav;
	}

	/**
	 * Entry point to show all FeatureRole entities
	 * 
	 */
	public String indexFeatureRole() {
		return "redirect:/indexFeatureRole";
	}

	/**
	 * Create a new FeatureRole entity
	 * 
	 */
	@RequestMapping("/newFeatureRole")
	public ModelAndView newFeatureRole() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featurerole", new FeatureRole());
		mav.addObject("newFlag", true);
		mav.setViewName("featurerole/editFeatureRole.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/featureroleController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Show all FeatureRole entities
	 * 
	 */
	@RequestMapping("/indexFeatureRole")
	public ModelAndView listFeatureRoles() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featureroles", featureRoleService.loadFeatureRoles());

		mav.setViewName("featurerole/listFeatureRoles.jsp");

		return mav;
	}

	/**
	 * Save an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/saveFeatureRole")
	public String saveFeatureRole(@ModelAttribute FeatureRole featurerole) {
		featureRoleService.saveFeatureRole(featurerole);
		return "forward:/indexFeatureRole";
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Edit an existing FeatureRole entity
	 * 
	 */
	@RequestMapping("/editFeatureRole")
	public ModelAndView editFeatureRole(@RequestParam Integer featureIdKey, @RequestParam Integer roleIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("featurerole", featureRoleDAO.findFeatureRoleByPrimaryKey(featureIdKey, roleIdKey));
		mav.setViewName("featurerole/editFeatureRole.jsp");

		return mav;
	}
}
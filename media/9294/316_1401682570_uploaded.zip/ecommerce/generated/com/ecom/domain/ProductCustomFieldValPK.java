package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class ProductCustomFieldValPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public ProductCustomFieldValPK() {
	}

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer prodId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer langId;
	/**
	 */

	@Column(name = "custom_field_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer customFieldId;

	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setCustomFieldId(Integer customFieldId) {
		this.customFieldId = customFieldId;
	}

	/**
	 */
	public Integer getCustomFieldId() {
		return this.customFieldId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		result = (int) (prime * result + ((customFieldId == null) ? 0 : customFieldId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProductCustomFieldValPK))
			return false;
		ProductCustomFieldValPK equalCheck = (ProductCustomFieldValPK) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		if ((customFieldId == null && equalCheck.customFieldId != null) || (customFieldId != null && equalCheck.customFieldId == null))
			return false;
		if (customFieldId != null && !customFieldId.equals(equalCheck.customFieldId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("ProductCustomFieldValPK");
		sb.append(" prodId: ").append(getProdId());
		sb.append(" langId: ").append(getLangId());
		sb.append(" customFieldId: ").append(getCustomFieldId());
		return sb.toString();
	}
}

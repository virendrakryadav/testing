package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import javax.persistence.Id;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.KeywordDescPK.class)
@Entity
@NamedQueries({
	@NamedQuery(name = "findAllKeywordDescs", query = "select myKeywordDesc from KeywordDesc myKeywordDesc"),
	@NamedQuery(name = "findKeywordDescByDescription", query = "select myKeywordDesc from KeywordDesc myKeywordDesc where myKeywordDesc.description = ?1"),
	@NamedQuery(name = "findKeywordDescByDescriptionContaining", query = "select myKeywordDesc from KeywordDesc myKeywordDesc where myKeywordDesc.description like ?1"),
	@NamedQuery(name = "findKeywordDescByKeywordId", query = "select myKeywordDesc from KeywordDesc myKeywordDesc where myKeywordDesc.keywordId = ?1"),
	@NamedQuery(name = "findKeywordDescByLangId", query = "select myKeywordDesc from KeywordDesc myKeywordDesc where myKeywordDesc.langId = ?1"),
	@NamedQuery(name = "findKeywordDescByPrimaryKey", query = "select myKeywordDesc from KeywordDesc myKeywordDesc where myKeywordDesc.keywordId = ?1 and myKeywordDesc.langId = ?2") })

@Table(schema = "ecom", name = "keyword_desc")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "KeywordDesc")
public class KeywordDesc implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "keyword_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer keywordId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "description", length = 32, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String description;

	/**
	 */
	public void setKeywordId(Integer keywordId) {
		this.keywordId = keywordId;
	}

	/**
	 */
	public Integer getKeywordId() {
		return this.keywordId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 */
	public KeywordDesc() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(KeywordDesc that) {
		setKeywordId(that.getKeywordId());
		setLangId(that.getLangId());
		setDescription(that.getDescription());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("keywordId=[").append(keywordId).append("] ");
		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("description=[").append(description).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((keywordId == null) ? 0 : keywordId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof KeywordDesc))
			return false;
		KeywordDesc equalCheck = (KeywordDesc) obj;
		if ((keywordId == null && equalCheck.keywordId != null) || (keywordId != null && equalCheck.keywordId == null))
			return false;
		if (keywordId != null && !keywordId.equals(equalCheck.keywordId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}
}

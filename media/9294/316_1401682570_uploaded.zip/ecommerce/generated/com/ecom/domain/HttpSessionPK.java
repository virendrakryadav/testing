package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class HttpSessionPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public HttpSessionPK() {
	}

	/**
	 */

	@Column(name = "session_id", length = 256, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public String sessionId;
	/**
	 */

	@Column(name = "website_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer websiteId;

	/**
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	/**
	 */
	public String getSessionId() {
		return this.sessionId;
	}

	/**
	 */
	public void setWebsiteId(Integer websiteId) {
		this.websiteId = websiteId;
	}

	/**
	 */
	public Integer getWebsiteId() {
		return this.websiteId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((sessionId == null) ? 0 : sessionId.hashCode()));
		result = (int) (prime * result + ((websiteId == null) ? 0 : websiteId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof HttpSessionPK))
			return false;
		HttpSessionPK equalCheck = (HttpSessionPK) obj;
		if ((sessionId == null && equalCheck.sessionId != null) || (sessionId != null && equalCheck.sessionId == null))
			return false;
		if (sessionId != null && !sessionId.equals(equalCheck.sessionId))
			return false;
		if ((websiteId == null && equalCheck.websiteId != null) || (websiteId != null && equalCheck.websiteId == null))
			return false;
		if (websiteId != null && !websiteId.equals(equalCheck.websiteId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("HttpSessionPK");
		sb.append(" sessionId: ").append(getSessionId());
		sb.append(" websiteId: ").append(getWebsiteId());
		return sb.toString();
	}
}

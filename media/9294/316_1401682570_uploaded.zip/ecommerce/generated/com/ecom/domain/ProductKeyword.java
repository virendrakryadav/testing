package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.ProductKeywordPK.class)
@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProductKeywords", query = "select myProductKeyword from ProductKeyword myProductKeyword"),
		@NamedQuery(name = "findProductKeywordByKeywordId", query = "select myProductKeyword from ProductKeyword myProductKeyword where myProductKeyword.keywordId = ?1"),
		@NamedQuery(name = "findProductKeywordByKeywordWeight", query = "select myProductKeyword from ProductKeyword myProductKeyword where myProductKeyword.keywordWeight = ?1"),
		@NamedQuery(name = "findProductKeywordByPrimaryKey", query = "select myProductKeyword from ProductKeyword myProductKeyword where myProductKeyword.prodId = ?1 and myProductKeyword.keywordId = ?2"),
		@NamedQuery(name = "findProductKeywordByProdId", query = "select myProductKeyword from ProductKeyword myProductKeyword where myProductKeyword.prodId = ?1"),
		@NamedQuery(name = "findProductKeywordByStoreId", query = "select myProductKeyword from ProductKeyword myProductKeyword where myProductKeyword.storeId = ?1") })
@Table(schema = "ecom", name = "product_keyword")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "ProductKeyword")
public class ProductKeyword implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer prodId;
	/**
	 */

	@Column(name = "keyword_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer keywordId;
	/**
	 */

	@Column(name = "keyword_weight")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer keywordWeight;
	/**
	 */

	@Column(name = "store_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;
	
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "keyword_id", referencedColumnName = "keyword_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Keyword keyword;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "prod_id", referencedColumnName = "prod_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Product product;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id", insertable = false, updatable = false) })
	@XmlTransient
	Store store;

	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setKeywordId(Integer keywordId) {
		this.keywordId = keywordId;
	}

	/**
	 */
	public Integer getKeywordId() {
		return this.keywordId;
	}

	/**
	 */
	public void setKeywordWeight(Integer keywordWeight) {
		this.keywordWeight = keywordWeight;
	}

	/**
	 */
	public Integer getKeywordWeight() {
		return this.keywordWeight;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}
	
	/**
	 */
	public void setKeyword(Keyword keyword) {
		this.keyword = keyword;
	}

	/**
	 */
	public Keyword getKeyword() {
		return keyword;
	}

	/**
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}


	/**
	 */
	public ProductKeyword() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProductKeyword that) {
		setProdId(that.getProdId());
		setKeywordId(that.getKeywordId());
		setKeywordWeight(that.getKeywordWeight());
		setStoreId(that.getStoreId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("prodId=[").append(prodId).append("] ");
		buffer.append("keywordId=[").append(keywordId).append("] ");
		buffer.append("keywordWeight=[").append(keywordWeight).append("] ");
		buffer.append("storeId=[").append(storeId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		result = (int) (prime * result + ((keywordId == null) ? 0 : keywordId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProductKeyword))
			return false;
		ProductKeyword equalCheck = (ProductKeyword) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		if ((keywordId == null && equalCheck.keywordId != null) || (keywordId != null && equalCheck.keywordId == null))
			return false;
		if (keywordId != null && !keywordId.equals(equalCheck.keywordId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllStores", query = "select myStore from Store myStore"),
		@NamedQuery(name = "findStoreByPrimaryKey", query = "select myStore from Store myStore where myStore.storeId = ?1") })
@Table(schema = "ecom", name = "store")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "Store")
@XmlRootElement(namespace = "ecommerce/com/ecom/domain")
public class Store implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "store_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer storeId;
	/**
	 */

	@Column(name = "internal_name", length = 64)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String internalName;
	/**
	 */

	@Column(name = "store_url", length = 128)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String storeUrl;
	/**
	 */

	@Column(name = "admin_email", length = 128)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String adminEmail;
	/**
	 */

	@Column(name = "max_products")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer maxProducts;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;
	/**
	 */

	@Column(name = "website_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer websiteId;
	/**
	 */

	@Column(name = "group_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer groupId;

	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductMedia> productMedias;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.Role> roles;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.Designer> designers;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.RoleDesc> roleDescs;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductCustomField> productCustomFields;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.FeatureDesc> featureDescs;
	/**
	 */
	@OneToMany(mappedBy = "storeId", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.Product> products;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductCustomFieldVal> productCustomFieldVals;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.Keyword> keywords;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.DesignerDesc> designerDescs;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductDesc> productDescs;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductKeyword> productKeywords;
	/**
	 */
	@OneToMany(mappedBy = "store", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.AdminUserStore> adminUserStores;

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setInternalName(String internalName) {
		this.internalName = internalName;
	}

	/**
	 */
	public String getInternalName() {
		return this.internalName;
	}

	/**
	 */
	public void setStoreUrl(String storeUrl) {
		this.storeUrl = storeUrl;
	}

	/**
	 */
	public String getStoreUrl() {
		return this.storeUrl;
	}

	/**
	 */
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	/**
	 */
	public String getAdminEmail() {
		return this.adminEmail;
	}

	/**
	 */
	public void setMaxProducts(Integer maxProducts) {
		this.maxProducts = maxProducts;
	}

	/**
	 */
	public Integer getMaxProducts() {
		return this.maxProducts;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public void setWebsiteId(Integer websiteId) {
		this.websiteId = websiteId;
	}

	/**
	 */
	public Integer getWebsiteId() {
		return this.websiteId;
	}

	/**
	 */
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	/**
	 */
	public Integer getGroupId() {
		return this.groupId;
	}

	/**
	 */
	public void setProductMedias(Set<ProductMedia> productMedias) {
		this.productMedias = productMedias;
	}

	/**
	 */
	public Set<ProductMedia> getProductMedias() {
		if (productMedias == null) {
			productMedias = new java.util.LinkedHashSet<com.ecom.domain.ProductMedia>();
		}
		return productMedias;
	}

	/**
	 */
	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	/**
	 */
	public Set<Role> getRoles() {
		if (roles == null) {
			roles = new java.util.LinkedHashSet<com.ecom.domain.Role>();
		}
		return roles;
	}

	/**
	 */
	public void setDesigners(Set<Designer> designers) {
		this.designers = designers;
	}

	/**
	 */
	public Set<Designer> getDesigners() {
		if (designers == null) {
			designers = new java.util.LinkedHashSet<com.ecom.domain.Designer>();
		}
		return designers;
	}

	/**
	 */
	public void setRoleDescs(Set<RoleDesc> roleDescs) {
		this.roleDescs = roleDescs;
	}

	/**
	 */
	public Set<RoleDesc> getRoleDescs() {
		if (roleDescs == null) {
			roleDescs = new java.util.LinkedHashSet<com.ecom.domain.RoleDesc>();
		}
		return roleDescs;
	}

	/**
	 */
	public void setProductCustomFields(Set<ProductCustomField> productCustomFields) {
		this.productCustomFields = productCustomFields;
	}

	/**
	 */
	public Set<ProductCustomField> getProductCustomFields() {
		if (productCustomFields == null) {
			productCustomFields = new java.util.LinkedHashSet<com.ecom.domain.ProductCustomField>();
		}
		return productCustomFields;
	}

	/**
	 */
	public void setFeatureDescs(Set<FeatureDesc> featureDescs) {
		this.featureDescs = featureDescs;
	}

	/**
	 */
	public Set<FeatureDesc> getFeatureDescs() {
		if (featureDescs == null) {
			featureDescs = new java.util.LinkedHashSet<com.ecom.domain.FeatureDesc>();
		}
		return featureDescs;
	}

	/**
	 */
	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	/**
	 */
	public Set<Product> getProducts() {
		if (products == null) {
			products = new java.util.LinkedHashSet<com.ecom.domain.Product>();
		}
		return products;
	}

	/**
	 */
	public void setProductCustomFieldVals(Set<ProductCustomFieldVal> productCustomFieldVals) {
		this.productCustomFieldVals = productCustomFieldVals;
	}

	/**
	 */
	public Set<ProductCustomFieldVal> getProductCustomFieldVals() {
		if (productCustomFieldVals == null) {
			productCustomFieldVals = new java.util.LinkedHashSet<com.ecom.domain.ProductCustomFieldVal>();
		}
		return productCustomFieldVals;
	}

	/**
	 */
	public void setKeywords(Set<Keyword> keywords) {
		this.keywords = keywords;
	}

	/**
	 */
	public Set<Keyword> getKeywords() {
		if (keywords == null) {
			keywords = new java.util.LinkedHashSet<com.ecom.domain.Keyword>();
		}
		return keywords;
	}

	/**
	 */
	public void setDesignerDescs(Set<DesignerDesc> designerDescs) {
		this.designerDescs = designerDescs;
	}

	/**
	 */
	public Set<DesignerDesc> getDesignerDescs() {
		if (designerDescs == null) {
			designerDescs = new java.util.LinkedHashSet<com.ecom.domain.DesignerDesc>();
		}
		return designerDescs;
	}

	/**
	 */
	public void setProductDescs(Set<ProductDesc> productDescs) {
		this.productDescs = productDescs;
	}

	/**
	 */
	public Set<ProductDesc> getProductDescs() {
		if (productDescs == null) {
			productDescs = new java.util.LinkedHashSet<com.ecom.domain.ProductDesc>();
		}
		return productDescs;
	}

	/**
	 */
	public void setProductKeywords(Set<ProductKeyword> productKeywords) {
		this.productKeywords = productKeywords;
	}

	/**
	 */
	public Set<ProductKeyword> getProductKeywords() {
		if (productKeywords == null) {
			productKeywords = new java.util.LinkedHashSet<com.ecom.domain.ProductKeyword>();
		}
		return productKeywords;
	}

	/**
	 */
	public void setAdminUserStores(Set<AdminUserStore> adminUserStores) {
		this.adminUserStores = adminUserStores;
	}

	/**
	 */
	public Set<AdminUserStore> getAdminUserStores() {
		if (adminUserStores == null) {
			adminUserStores = new java.util.LinkedHashSet<com.ecom.domain.AdminUserStore>();
		}
		return adminUserStores;
	}

	/**
	 */
	public Store() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Store that) {
		setStoreId(that.getStoreId());
		setInternalName(that.getInternalName());
		setStoreUrl(that.getStoreUrl());
		setAdminEmail(that.getAdminEmail());
		setMaxProducts(that.getMaxProducts());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
		setWebsiteId(that.getWebsiteId());
		setGroupId(that.getGroupId());
		setProductMedias(new java.util.LinkedHashSet<com.ecom.domain.ProductMedia>(that.getProductMedias()));
		setRoles(new java.util.LinkedHashSet<com.ecom.domain.Role>(that.getRoles()));
		setDesigners(new java.util.LinkedHashSet<com.ecom.domain.Designer>(that.getDesigners()));
		setRoleDescs(new java.util.LinkedHashSet<com.ecom.domain.RoleDesc>(that.getRoleDescs()));
		setProductCustomFields(new java.util.LinkedHashSet<com.ecom.domain.ProductCustomField>(that.getProductCustomFields()));
		setFeatureDescs(new java.util.LinkedHashSet<com.ecom.domain.FeatureDesc>(that.getFeatureDescs()));
		setProducts(new java.util.LinkedHashSet<com.ecom.domain.Product>(that.getProducts()));
		setProductCustomFieldVals(new java.util.LinkedHashSet<com.ecom.domain.ProductCustomFieldVal>(that.getProductCustomFieldVals()));
		setKeywords(new java.util.LinkedHashSet<com.ecom.domain.Keyword>(that.getKeywords()));
		setDesignerDescs(new java.util.LinkedHashSet<com.ecom.domain.DesignerDesc>(that.getDesignerDescs()));
		setProductDescs(new java.util.LinkedHashSet<com.ecom.domain.ProductDesc>(that.getProductDescs()));
		setProductKeywords(new java.util.LinkedHashSet<com.ecom.domain.ProductKeyword>(that.getProductKeywords()));
		setAdminUserStores(new java.util.LinkedHashSet<com.ecom.domain.AdminUserStore>(that.getAdminUserStores()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("storeId=[").append(storeId).append("] ");
		buffer.append("internalName=[").append(internalName).append("] ");
		buffer.append("storeUrl=[").append(storeUrl).append("] ");
		buffer.append("adminEmail=[").append(adminEmail).append("] ");
		buffer.append("maxProducts=[").append(maxProducts).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");
		buffer.append("websiteId=[").append(websiteId).append("] ");
		buffer.append("groupId=[").append(groupId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((storeId == null) ? 0 : storeId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Store))
			return false;
		Store equalCheck = (Store) obj;
		if ((storeId == null && equalCheck.storeId != null) || (storeId != null && equalCheck.storeId == null))
			return false;
		if (storeId != null && !storeId.equals(equalCheck.storeId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.ProductMediaPK.class)
@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProductMedias", query = "select myProductMedia from ProductMedia myProductMedia"),
		@NamedQuery(name = "findProductMediaByPrimaryKey", query = "select myProductMedia from ProductMedia myProductMedia where myProductMedia.prodId = ?1 and myProductMedia.langId = ?2 and myProductMedia.mediaId = ?3") })
@Table(schema = "ecom", name = "product_media")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "ProductMedia")
public class ProductMedia implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer prodId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "media_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer mediaId;
	/**
	 */

	@Column(name = "sort_order")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sortOrder;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "prod_id", referencedColumnName = "prod_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Product product;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id") })
	@XmlTransient
	Store store;

	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setMediaId(Integer mediaId) {
		this.mediaId = mediaId;
	}

	/**
	 */
	public Integer getMediaId() {
		return this.mediaId;
	}

	/**
	 */
	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 */
	public Integer getSortOrder() {
		return this.sortOrder;
	}

	/**
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}

	/**
	 */
	public ProductMedia() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProductMedia that) {
		setProdId(that.getProdId());
		setLangId(that.getLangId());
		setMediaId(that.getMediaId());
		setSortOrder(that.getSortOrder());
		setProduct(that.getProduct());
		setStore(that.getStore());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("prodId=[").append(prodId).append("] ");
		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("mediaId=[").append(mediaId).append("] ");
		buffer.append("sortOrder=[").append(sortOrder).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		result = (int) (prime * result + ((mediaId == null) ? 0 : mediaId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProductMedia))
			return false;
		ProductMedia equalCheck = (ProductMedia) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		if ((mediaId == null && equalCheck.mediaId != null) || (mediaId != null && equalCheck.mediaId == null))
			return false;
		if (mediaId != null && !mediaId.equals(equalCheck.mediaId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@Table(schema = "ecom", name = "feature")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "Feature")
@XmlRootElement(namespace = "ecommerce/com/ecom/domain")
public class Feature implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "feature_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer featureId;
	/**
	 */

	@Column(name = "internal_name", length = 32)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String internalName;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;

	/**
	 */
	@OneToMany(mappedBy = "feature", fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.FeatureRole> featureRoles;
	/**
	 */
	@OneToMany(mappedBy = "feature", fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.FeatureDesc> featureDescs;

	/**
	 */
	public void setFeatureId(Integer featureId) {
		this.featureId = featureId;
	}

	/**
	 */
	public Integer getFeatureId() {
		return this.featureId;
	}

	/**
	 */
	public void setInternalName(String internalName) {
		this.internalName = internalName;
	}

	/**
	 */
	public String getInternalName() {
		return this.internalName;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public void setFeatureRoles(Set<FeatureRole> featureRoles) {
		this.featureRoles = featureRoles;
	}

	/**
	 */
	public Set<FeatureRole> getFeatureRoles() {
		if (featureRoles == null) {
			featureRoles = new java.util.LinkedHashSet<com.ecom.domain.FeatureRole>();
		}
		return featureRoles;
	}

	/**
	 */
	public void setFeatureDescs(Set<FeatureDesc> featureDescs) {
		this.featureDescs = featureDescs;
	}

	/**
	 */
	public Set<FeatureDesc> getFeatureDescs() {
		if (featureDescs == null) {
			featureDescs = new java.util.LinkedHashSet<com.ecom.domain.FeatureDesc>();
		}
		return featureDescs;
	}

	/**
	 */
	public Feature() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Feature that) {
		setFeatureId(that.getFeatureId());
		setInternalName(that.getInternalName());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
		setFeatureRoles(new java.util.LinkedHashSet<com.ecom.domain.FeatureRole>(that.getFeatureRoles()));
		setFeatureDescs(new java.util.LinkedHashSet<com.ecom.domain.FeatureDesc>(that.getFeatureDescs()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("featureId=[").append(featureId).append("] ");
		buffer.append("internalName=[").append(internalName).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((featureId == null) ? 0 : featureId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Feature))
			return false;
		Feature equalCheck = (Feature) obj;
		if ((featureId == null && equalCheck.featureId != null) || (featureId != null && equalCheck.featureId == null))
			return false;
		if (featureId != null && !featureId.equals(equalCheck.featureId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class CategoryDescPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public CategoryDescPK() {
	}

	/**
	 */

	@Column(name = "category_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer categoryId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer langId;

	/**
	 */
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	/**
	 */
	public Integer getCategoryId() {
		return this.categoryId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((categoryId == null) ? 0 : categoryId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CategoryDescPK))
			return false;
		CategoryDescPK equalCheck = (CategoryDescPK) obj;
		if ((categoryId == null && equalCheck.categoryId != null) || (categoryId != null && equalCheck.categoryId == null))
			return false;
		if (categoryId != null && !categoryId.equals(equalCheck.categoryId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("CategoryDescPK");
		sb.append(" categoryId: ").append(getCategoryId());
		sb.append(" langId: ").append(getLangId());
		return sb.toString();
	}
}

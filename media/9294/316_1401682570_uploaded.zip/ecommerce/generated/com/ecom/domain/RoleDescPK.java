package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class RoleDescPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public RoleDescPK() {
	}

	/**
	 */

	@Column(name = "role_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer roleId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer langId;

	/**
	 */
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	/**
	 */
	public Integer getRoleId() {
		return this.roleId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((roleId == null) ? 0 : roleId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof RoleDescPK))
			return false;
		RoleDescPK equalCheck = (RoleDescPK) obj;
		if ((roleId == null && equalCheck.roleId != null) || (roleId != null && equalCheck.roleId == null))
			return false;
		if (roleId != null && !roleId.equals(equalCheck.roleId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("RoleDescPK");
		sb.append(" roleId: ").append(getRoleId());
		sb.append(" langId: ").append(getLangId());
		return sb.toString();
	}
}

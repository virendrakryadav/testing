package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class KeywordDescPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public KeywordDescPK() {
	}

	/**
	 */

	@Column(name = "keyword_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer keywordId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer langId;

	/**
	 */
	public void setKeywordId(Integer keywordId) {
		this.keywordId = keywordId;
	}

	/**
	 */
	public Integer getKeywordId() {
		return this.keywordId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((keywordId == null) ? 0 : keywordId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof KeywordDescPK))
			return false;
		KeywordDescPK equalCheck = (KeywordDescPK) obj;
		if ((keywordId == null && equalCheck.keywordId != null) || (keywordId != null && equalCheck.keywordId == null))
			return false;
		if (keywordId != null && !keywordId.equals(equalCheck.keywordId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("KeywordDescPK");
		sb.append(" keywordId: ").append(getKeywordId());
		sb.append(" langId: ").append(getLangId());
		return sb.toString();
	}
}

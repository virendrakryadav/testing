package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class ProductMediaPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public ProductMediaPK() {
	}

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer prodId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer langId;
	/**
	 */

	@Column(name = "media_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer mediaId;

	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setMediaId(Integer mediaId) {
		this.mediaId = mediaId;
	}

	/**
	 */
	public Integer getMediaId() {
		return this.mediaId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		result = (int) (prime * result + ((mediaId == null) ? 0 : mediaId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProductMediaPK))
			return false;
		ProductMediaPK equalCheck = (ProductMediaPK) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		if ((mediaId == null && equalCheck.mediaId != null) || (mediaId != null && equalCheck.mediaId == null))
			return false;
		if (mediaId != null && !mediaId.equals(equalCheck.mediaId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("ProductMediaPK");
		sb.append(" prodId: ").append(getProdId());
		sb.append(" langId: ").append(getLangId());
		sb.append(" mediaId: ").append(getMediaId());
		return sb.toString();
	}
}

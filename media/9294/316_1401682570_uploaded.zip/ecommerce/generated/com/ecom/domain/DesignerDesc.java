package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.DesignerDescPK.class)
@Entity
@NamedQueries({
		@NamedQuery(name = "findAllDesignerDescs", query = "select myDesignerDesc from DesignerDesc myDesignerDesc"),
		@NamedQuery(name = "findDesignerDescByDescription", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.description = ?1"),
		@NamedQuery(name = "findDesignerDescByDescriptionContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.description like ?1"),
		@NamedQuery(name = "findDesignerDescByDesignerId", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.designerId = ?1"),
		@NamedQuery(name = "findDesignerDescByImageLocation", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.imageLocation = ?1"),
		@NamedQuery(name = "findDesignerDescByImageLocationContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.imageLocation like ?1"),
		@NamedQuery(name = "findDesignerDescByLangId", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.langId = ?1"),
		@NamedQuery(name = "findDesignerDescByMetaDesc", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.metaDesc = ?1"),
		@NamedQuery(name = "findDesignerDescByMetaDescContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.metaDesc like ?1"),
		@NamedQuery(name = "findDesignerDescByMetaKeywords", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.metaKeywords = ?1"),
		@NamedQuery(name = "findDesignerDescByMetaKeywordsContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.metaKeywords like ?1"),
		@NamedQuery(name = "findDesignerDescByMetaTagsTitle", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.metaTagsTitle = ?1"),
		@NamedQuery(name = "findDesignerDescByMetaTagsTitleContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.metaTagsTitle like ?1"),
		@NamedQuery(name = "findDesignerDescByName", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.name = ?1"),
		@NamedQuery(name = "findDesignerDescByNameContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.name like ?1"),
		@NamedQuery(name = "findDesignerDescByPrimaryKey", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.designerId = ?1 and myDesignerDesc.langId = ?2"),
		@NamedQuery(name = "findDesignerDescByProfile", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.profile = ?1"),
		@NamedQuery(name = "findDesignerDescByProfileContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.profile like ?1"),
		@NamedQuery(name = "findDesignerDescByStoreId", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.storeId = ?1"),
		@NamedQuery(name = "findDesignerDescByUrl", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.url = ?1"),
		@NamedQuery(name = "findDesignerDescByUrlContaining", query = "select myDesignerDesc from DesignerDesc myDesignerDesc where myDesignerDesc.url like ?1") })
@Table(schema = "ecom", name = "designer_desc")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "DesignerDesc")
public class DesignerDesc implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "designer_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer designerId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "name", length = 32, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;
	/**
	 */

	@Column(name = "description", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String description;
	/**
	 */

	@Column(name = "profile", length = 2000)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String profile;
	/**
	 */

	@Column(name = "url", length = 64)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String url;
	/**
	 */

	@Column(name = "image_location", length = 64)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String imageLocation;
	/**
	 */

	@Column(name = "meta_tags_title", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String metaTagsTitle;
	/**
	 */

	@Column(name = "meta_keywords", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String metaKeywords;
	/**
	 */

	@Column(name = "meta_desc", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String metaDesc;
	/**
	 */

	@Column(name = "store_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id",insertable = false, updatable = false) })
	@XmlTransient
	Store store;
	
	/**
	 */
	public void setDesignerId(Integer designerId) {
		this.designerId = designerId;
	}

	/**
	 */
	public Integer getDesignerId() {
		return this.designerId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 */
	public void setProfile(String profile) {
		this.profile = profile;
	}

	/**
	 */
	public String getProfile() {
		return this.profile;
	}

	/**
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 */
	public String getUrl() {
		return this.url;
	}

	/**
	 */
	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	/**
	 */
	public String getImageLocation() {
		return this.imageLocation;
	}

	/**
	 */
	public void setMetaTagsTitle(String metaTagsTitle) {
		this.metaTagsTitle = metaTagsTitle;
	}

	/**
	 */
	public String getMetaTagsTitle() {
		return this.metaTagsTitle;
	}

	/**
	 */
	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}

	/**
	 */
	public String getMetaKeywords() {
		return this.metaKeywords;
	}

	/**
	 */
	public void setMetaDesc(String metaDesc) {
		this.metaDesc = metaDesc;
	}

	/**
	 */
	public String getMetaDesc() {
		return this.metaDesc;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public DesignerDesc() {
	}

	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}
	
	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(DesignerDesc that) {
		setDesignerId(that.getDesignerId());
		setLangId(that.getLangId());
		setName(that.getName());
		setDescription(that.getDescription());
		setProfile(that.getProfile());
		setUrl(that.getUrl());
		setImageLocation(that.getImageLocation());
		setMetaTagsTitle(that.getMetaTagsTitle());
		setMetaKeywords(that.getMetaKeywords());
		setMetaDesc(that.getMetaDesc());
		setStoreId(that.getStoreId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("designerId=[").append(designerId).append("] ");
		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("name=[").append(name).append("] ");
		buffer.append("description=[").append(description).append("] ");
		buffer.append("profile=[").append(profile).append("] ");
		buffer.append("url=[").append(url).append("] ");
		buffer.append("imageLocation=[").append(imageLocation).append("] ");
		buffer.append("metaTagsTitle=[").append(metaTagsTitle).append("] ");
		buffer.append("metaKeywords=[").append(metaKeywords).append("] ");
		buffer.append("metaDesc=[").append(metaDesc).append("] ");
		buffer.append("storeId=[").append(storeId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((designerId == null) ? 0 : designerId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof DesignerDesc))
			return false;
		DesignerDesc equalCheck = (DesignerDesc) obj;
		if ((designerId == null && equalCheck.designerId != null) || (designerId != null && equalCheck.designerId == null))
			return false;
		if (designerId != null && !designerId.equals(equalCheck.designerId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}
}

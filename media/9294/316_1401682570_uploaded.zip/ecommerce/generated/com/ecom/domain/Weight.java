package com.ecom.domain;

public class Weight implements java.io.Serializable{
	
	private String weightId;
	private String weightDesc;
	
	public Weight(String weightId,String weightDesc){
		this.weightId = weightId;
		this.weightDesc = weightDesc;
	}

	public String getWeightId(){
		return this.weightId;
	}
	
	public String getWeightDesc(){
		return this.weightDesc;
	}
}

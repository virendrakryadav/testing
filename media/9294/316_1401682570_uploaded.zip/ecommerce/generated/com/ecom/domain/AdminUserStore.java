package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.AdminUserStorePK.class)
@Entity
@NamedQueries({
		@NamedQuery(name = "findAdminUserStoreByAdminUserId", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.adminUserId = ?1"),
		@NamedQuery(name = "findAdminUserStoreByDateAdded", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.dateAdded = ?1"),
		@NamedQuery(name = "findAdminUserStoreByDateAddedAfter", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.dateAdded > ?1"),
		@NamedQuery(name = "findAdminUserStoreByDateAddedBefore", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.dateAdded < ?1"),
		@NamedQuery(name = "findAdminUserStoreByDateModified", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.dateModified = ?1"),
		@NamedQuery(name = "findAdminUserStoreByDateModifiedAfter", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.dateModified > ?1"),
		@NamedQuery(name = "findAdminUserStoreByDateModifiedBefore", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.dateModified < ?1"),
		@NamedQuery(name = "findAdminUserStoreByIsDefault", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.isDefault = ?1"),
		@NamedQuery(name = "findAdminUserStoreByPrimaryKey", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.adminUserId = ?1 and myAdminUserStore.storeId = ?2"),
		@NamedQuery(name = "findAdminUserStoreByStatusId", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.statusId = ?1"),
		@NamedQuery(name = "findAdminUserStoreByStoreId", query = "select myAdminUserStore from AdminUserStore myAdminUserStore where myAdminUserStore.storeId = ?1"),
		@NamedQuery(name = "findAllAdminUserStores", query = "select myAdminUserStore from AdminUserStore myAdminUserStore") })
@Table(schema = "ecom", name = "admin_user_store")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "AdminUserStore")
public class AdminUserStore implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "admin_user_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer adminUserId;
	/**
	 */

	@Column(name = "store_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer storeId;
	/**
	 */

	@Column(name = "is_default")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isDefault;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;

	@Column(name = "name")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "admin_user_id", referencedColumnName = "user_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	AdminUser adminUser;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Store store;

	/**
	 */
	public void setAdminUserId(Integer adminUserId) {
		this.adminUserId = adminUserId;
	}

	/**
	 */
	public Integer getAdminUserId() {
		return this.adminUserId;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	/**
	 */
	public Boolean getIsDefault() {
		return this.isDefault;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public void setAdminUser(AdminUser adminUser) {
		this.adminUser = adminUser;
	}

	/**
	 */
	public AdminUser getAdminUser() {
		return adminUser;
	}
	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}

	/**
	 */
	public AdminUserStore() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(AdminUserStore that) {
		setAdminUserId(that.getAdminUserId());
		setStoreId(that.getStoreId());
		setIsDefault(that.getIsDefault());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("adminUserId=[").append(adminUserId).append("] ");
		buffer.append("storeId=[").append(storeId).append("] ");
		buffer.append("isDefault=[").append(isDefault).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((adminUserId == null) ? 0 : adminUserId.hashCode()));
		result = (int) (prime * result + ((storeId == null) ? 0 : storeId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof AdminUserStore))
			return false;
		AdminUserStore equalCheck = (AdminUserStore) obj;
		if ((adminUserId == null && equalCheck.adminUserId != null) || (adminUserId != null && equalCheck.adminUserId == null))
			return false;
		if (adminUserId != null && !adminUserId.equals(equalCheck.adminUserId))
			return false;
		if ((storeId == null && equalCheck.storeId != null) || (storeId != null && equalCheck.storeId == null))
			return false;
		if (storeId != null && !storeId.equals(equalCheck.storeId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class ProductKeywordPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public ProductKeywordPK() {
	}

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer prodId;
	/**
	 */

	@Column(name = "keyword_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer keywordId;

	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setKeywordId(Integer keywordId) {
		this.keywordId = keywordId;
	}

	/**
	 */
	public Integer getKeywordId() {
		return this.keywordId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		result = (int) (prime * result + ((keywordId == null) ? 0 : keywordId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProductKeywordPK))
			return false;
		ProductKeywordPK equalCheck = (ProductKeywordPK) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		if ((keywordId == null && equalCheck.keywordId != null) || (keywordId != null && equalCheck.keywordId == null))
			return false;
		if (keywordId != null && !keywordId.equals(equalCheck.keywordId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("ProductKeywordPK");
		sb.append(" prodId: ").append(getProdId());
		sb.append(" keywordId: ").append(getKeywordId());
		return sb.toString();
	}
}

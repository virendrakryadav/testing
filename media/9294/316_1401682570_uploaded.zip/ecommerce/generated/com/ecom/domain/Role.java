package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllRoles", query = "select myRole from Role myRole"),
		@NamedQuery(name = "findRoleByPrimaryKey", query = "select myRole from Role myRole where myRole.roleId = ?1") })
@Table(schema = "ecom", name = "role")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "Role")
@XmlRootElement(namespace = "ecommerce/com/ecom/domain")
public class Role implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "role_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer roleId;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;

	/**
	 */

	@Column(name = "store_id", insertable=false,updatable=false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id") })
	@XmlTransient
	Store store;
	/**
	 */
	@OneToMany(mappedBy = "role", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.FeatureRole> featureRoles;
	/**
	 */
	@OneToMany(mappedBy = "role", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.RoleDesc> roleDescs;
	/**
	 */
	@OneToMany(mappedBy = "role", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.AdminUser> adminUsers;

	/**
	 */
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	/**
	 */
	public Integer getRoleId() {
		return this.roleId;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}

	/**
	 */
	public void setFeatureRoles(Set<FeatureRole> featureRoles) {
		this.featureRoles = featureRoles;
	}

	/**
	 */
	public Set<FeatureRole> getFeatureRoles() {
		if (featureRoles == null) {
			featureRoles = new java.util.LinkedHashSet<com.ecom.domain.FeatureRole>();
		}
		return featureRoles;
	}

	/**
	 */
	public void setRoleDescs(Set<RoleDesc> roleDescs) {
		this.roleDescs = roleDescs;
	}

	/**
	 */
	public Set<RoleDesc> getRoleDescs() {
		if (roleDescs == null) {
			roleDescs = new java.util.LinkedHashSet<com.ecom.domain.RoleDesc>();
		}
		return roleDescs;
	}

	/**
	 */
	public void setAdminUsers(Set<AdminUser> adminUsers) {
		this.adminUsers = adminUsers;
	}

	/**
	 */
	public Set<AdminUser> getAdminUsers() {
		if (adminUsers == null) {
			adminUsers = new java.util.LinkedHashSet<com.ecom.domain.AdminUser>();
		}
		return adminUsers;
	}

	/**
	 */
	public Role() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Role that) {
		setRoleId(that.getRoleId());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
		setStore(that.getStore());
		setFeatureRoles(new java.util.LinkedHashSet<com.ecom.domain.FeatureRole>(that.getFeatureRoles()));
		setRoleDescs(new java.util.LinkedHashSet<com.ecom.domain.RoleDesc>(that.getRoleDescs()));
		setAdminUsers(new java.util.LinkedHashSet<com.ecom.domain.AdminUser>(that.getAdminUsers()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("roleId=[").append(roleId).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((roleId == null) ? 0 : roleId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Role))
			return false;
		Role equalCheck = (Role) obj;
		if ((roleId == null && equalCheck.roleId != null) || (roleId != null && equalCheck.roleId == null))
			return false;
		if (roleId != null && !roleId.equals(equalCheck.roleId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class StoreDescPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public StoreDescPK() {
	}

	/**
	 */

	@Column(name = "store_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer storeId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	public Integer langId;

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((storeId == null) ? 0 : storeId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof StoreDescPK))
			return false;
		StoreDescPK equalCheck = (StoreDescPK) obj;
		if ((storeId == null && equalCheck.storeId != null) || (storeId != null && equalCheck.storeId == null))
			return false;
		if (storeId != null && !storeId.equals(equalCheck.storeId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("StoreDescPK");
		sb.append(" storeId: ").append(getStoreId());
		sb.append(" langId: ").append(getLangId());
		return sb.toString();
	}
}

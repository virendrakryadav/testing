package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Set;

import javax.persistence.Id;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.FeatureDescPK.class)
@Entity
@Table(schema = "ecom", name = "feature_desc")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "FeatureDesc")
public class FeatureDesc implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "feature_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer featureId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "description", length = 32)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String description;

	/**
	 */

	@Column(name = "store_id", insertable=false, updatable=false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "feature_id", referencedColumnName = "feature_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Feature feature;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id") })
	@XmlTransient
	Store store;

	/**
	 */
	public void setFeatureId(Integer featureId) {
		this.featureId = featureId;
	}

	/**
	 */
	public Integer getFeatureId() {
		return this.featureId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setFeature(Feature feature) {
		this.feature = feature;
	}

	/**
	 */
	public Feature getFeature() {
		return feature;
	}

	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}

	/**
	 */
	public FeatureDesc() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(FeatureDesc that) {
		setFeatureId(that.getFeatureId());
		setLangId(that.getLangId());
		setDescription(that.getDescription());
		setFeature(that.getFeature());
		setStore(that.getStore());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("featureId=[").append(featureId).append("] ");
		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("description=[").append(description).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((featureId == null) ? 0 : featureId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof FeatureDesc))
			return false;
		FeatureDesc equalCheck = (FeatureDesc) obj;
		if ((featureId == null && equalCheck.featureId != null) || (featureId != null && equalCheck.featureId == null))
			return false;
		if (featureId != null && !featureId.equals(equalCheck.featureId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.math.BigDecimal;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProducts", query = "select myProduct from Product myProduct"),
		@NamedQuery(name = "findProductByComputedPrice", query = "select myProduct from Product myProduct where myProduct.computedPrice = ?1"),
		@NamedQuery(name = "findProductByCustom", query = "select myProduct from Product myProduct where myProduct.custom = ?1"),
		@NamedQuery(name = "findProductByDateAdded", query = "select myProduct from Product myProduct where myProduct.dateAdded = ?1"),
		@NamedQuery(name = "findProductByDateAddedAfter", query = "select myProduct from Product myProduct where myProduct.dateAdded > ?1"),
		@NamedQuery(name = "findProductByDateAddedBefore", query = "select myProduct from Product myProduct where myProduct.dateAdded < ?1"),
		@NamedQuery(name = "findProductByDateModified", query = "select myProduct from Product myProduct where myProduct.dateModified = ?1"),
		@NamedQuery(name = "findProductByDateModifiedAfter", query = "select myProduct from Product myProduct where myProduct.dateModified > ?1"),
		@NamedQuery(name = "findProductByDateModifiedBefore", query = "select myProduct from Product myProduct where myProduct.dateModified < ?1"),
		@NamedQuery(name = "findProductByDuty", query = "select myProduct from Product myProduct where myProduct.duty = ?1"),
		@NamedQuery(name = "findProductByDesignerId", query = "select myProduct from Product myProduct where myProduct.designerId = ?1"),
		@NamedQuery(name = "findProductByEnteredPrice", query = "select myProduct from Product myProduct where myProduct.enteredPrice = ?1"),
		@NamedQuery(name = "findProductByInternalName", query = "select myProduct from Product myProduct where myProduct.internalName = ?1"),
		@NamedQuery(name = "findProductByInternalNameContaining", query = "select myProduct from Product myProduct where myProduct.internalName like ?1"),
		@NamedQuery(name = "findProductByMargin", query = "select myProduct from Product myProduct where myProduct.margin = ?1"),
		@NamedQuery(name = "findProductByMasterCatId", query = "select myProduct from Product myProduct where myProduct.masterCatId = ?1"),
		@NamedQuery(name = "findProductByOrderUnits", query = "select myProduct from Product myProduct where myProduct.orderUnits = ?1"),
		@NamedQuery(name = "findProductByOrdered", query = "select myProduct from Product myProduct where myProduct.ordered = ?1"),
		@NamedQuery(name = "findProductByPrimaryKey", query = "select myProduct from Product myProduct where myProduct.prodId = ?1"),
		@NamedQuery(name = "findProductByProdId", query = "select myProduct from Product myProduct where myProduct.prodId = ?1"),
		@NamedQuery(name = "findProductByProductCost", query = "select myProduct from Product myProduct where myProduct.productCost = ?1"),
		@NamedQuery(name = "findProductBySortOrder", query = "select myProduct from Product myProduct where myProduct.sortOrder = ?1"),
		@NamedQuery(name = "findProductByStatusId", query = "select myProduct from Product myProduct where myProduct.statusId = ?1"),
		@NamedQuery(name = "findProductByStoreId", query = "select myProduct from Product myProduct where myProduct.storeId = ?1"),
		@NamedQuery(name = "findProductByTaxClassId", query = "select myProduct from Product myProduct where myProduct.taxClassId = ?1"),
		@NamedQuery(name = "findProductByUseEnteredPrice", query = "select myProduct from Product myProduct where myProduct.useEnteredPrice = ?1") })
@Table(schema = "ecom", name = "product")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "Product")
@XmlRootElement(namespace = "ecommerce/com/ecom/domain")
public class Product implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@SequenceGenerator(name="Product_Prod_Id_Gen", sequenceName="ecom.product_prod_id_seq")
	@Id @GeneratedValue(generator="Product_Prod_Id_Gen")
	@XmlElement
	Integer prodId;
	/**
	 */

	@Column(name = "internal_name", length = 32)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String internalName;
	/**
	 */

	@Column(name = "master_cat_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer masterCatId;
	/**
	 */

	@Column(name = "tax_class_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer taxClassId;
	/**
	 */

	@Column(name = "ordered")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer ordered;
	/**
	 */

	@Column(name = "order_units")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer orderUnits;
	/**
	 */

	@Column(name = "product_cost", scale = 2, precision = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal productCost;
	/**
	 */

	@Column(name = "margin", scale = 2, precision = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal margin;
	/**
	 */

	@Column(name = "custom", scale = 2, precision = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal custom;
	/**
	 */

	@Column(name = "duty", scale = 2, precision = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal duty;
	/**
	 */

	@Column(name = "computed_price", scale = 2, precision = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal computedPrice;
	/**
	 */

	@Column(name = "use_entered_price")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean useEnteredPrice;
	/**
	 */

	@Column(name = "entered_price", scale = 2, precision = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal enteredPrice;
	/**
	 */

	@Column(name = "sort_order")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sortOrder;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;

	@Column(name = "designer_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer designerId;

	/**
	 */

	@Column(name = "store_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;
	

	/**
	 */
	@OneToMany(mappedBy = "product", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductCustomFieldVal> productCustomFieldVals;
	/**
	 */
	@OneToMany(mappedBy = "product", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductMedia> productMedias;
	/**
	 */
	@OneToMany(mappedBy = "product", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductDesc> productDescs;
	/**
	 */
	@OneToMany(mappedBy = "product", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductKeyword> productKeywords;
	/**
	 */
	@OneToMany(mappedBy = "product", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductCustomField> productCustomFields;
	
	/*
	
	private String  publicName;
	
	private String description;

	private String[] keywordId;
	
	private String[] keywordDesc;
	
	private String[] selectedKeywords;
	
	public void setPublicName(String publicName){
		this.publicName = publicName;
	}
	
	public String getPublicName(){
		return this.publicName;
	}
	
	public void setDescription(String description){
		this.description = description;
	}
	
	public String getDescription(){
		return this.description;
	}	

	public String[] getKeywordId(){
		return this.keywordId;
	}
	
	public void setKeywordId(String[] keywordId){
		this.keywordId = keywordId;
	}
	
	public String[] getKeywordDesc(){
		return this.keywordDesc;
	}
	
	public void setKeywordDesc(String[] keywordDesc){
		this.keywordDesc = keywordDesc;
	}
	
	public void setSelectedKeywords(String[] selectedKeywords ){
		this.selectedKeywords = selectedKeywords;
	}
	
	public String[] getSelectedKeywords(){
		return this.selectedKeywords;
	}
	*/
	
	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setInternalName(String internalName) {
		this.internalName = internalName;
	}

	/**
	 */
	public String getInternalName() {
		return this.internalName;
	}

	/**
	 */
	public void setMasterCatId(Integer masterCatId) {
		this.masterCatId = masterCatId;
	}

	/**
	 */
	public Integer getMasterCatId() {
		return this.masterCatId;
	}

	/**
	 */
	public void setTaxClassId(Integer taxClassId) {
		this.taxClassId = taxClassId;
	}

	/**
	 */
	public Integer getTaxClassId() {
		return this.taxClassId;
	}

	/**
	 */
	public void setOrdered(Integer ordered) {
		this.ordered = ordered;
	}

	/**
	 */
	public Integer getOrdered() {
		return this.ordered;
	}

	/**
	 */
	public void setOrderUnits(Integer orderUnits) {
		this.orderUnits = orderUnits;
	}

	/**
	 */
	public Integer getOrderUnits() {
		return this.orderUnits;
	}

	/**
	 */
	public void setProductCost(BigDecimal productCost) {
		this.productCost = productCost;
	}

	/**
	 */
	public BigDecimal getProductCost() {
		return this.productCost;
	}

	/**
	 */
	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}

	/**
	 */
	public BigDecimal getMargin() {
		return this.margin;
	}

	/**
	 */
	public void setCustom(BigDecimal custom) {
		this.custom = custom;
	}

	/**
	 */
	public BigDecimal getCustom() {
		return this.custom;
	}

	/**
	 */
	public void setDuty(BigDecimal duty) {
		this.duty = duty;
	}

	/**
	 */
	public BigDecimal getDuty() {
		return this.duty;
	}

	/**
	 */
	public void setComputedPrice(BigDecimal computedPrice) {
		this.computedPrice = computedPrice;
	}

	/**
	 */
	public BigDecimal getComputedPrice() {
		return this.computedPrice;
	}

	/**
	 */
	public void setUseEnteredPrice(Boolean useEnteredPrice) {
		this.useEnteredPrice = useEnteredPrice;
	}

	/**
	 */
	public Boolean getUseEnteredPrice() {
		return this.useEnteredPrice;
	}

	/**
	 */
	public void setEnteredPrice(BigDecimal enteredPrice) {
		this.enteredPrice = enteredPrice;
	}

	/**
	 */
	public BigDecimal getEnteredPrice() {
		return this.enteredPrice;
	}

	/**
	 */
	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 */
	public Integer getSortOrder() {
		return this.sortOrder;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public void setDesignerId(Integer designerId) {
		this.designerId = designerId;
	}

	/**
	 */
	public Integer getDesignerId() {
		return this.designerId;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setProductCustomFieldVals(Set<ProductCustomFieldVal> productCustomFieldVals) {
		this.productCustomFieldVals = productCustomFieldVals;
	}

	/**
	 */
	public Set<ProductCustomFieldVal> getProductCustomFieldVals() {
		if (productCustomFieldVals == null) {
			productCustomFieldVals = new java.util.LinkedHashSet<com.ecom.domain.ProductCustomFieldVal>();
		}
		return productCustomFieldVals;
	}

	/**
	 */
	public void setProductMedias(Set<ProductMedia> productMedias) {
		this.productMedias = productMedias;
	}

	/**
	 */
	public Set<ProductMedia> getProductMedias() {
		if (productMedias == null) {
			productMedias = new java.util.LinkedHashSet<com.ecom.domain.ProductMedia>();
		}
		return productMedias;
	}

	/**
	 */
	public void setProductDescs(Set<ProductDesc> productDescs) {
		this.productDescs = productDescs;
	}

	/**
	 */
	public Set<ProductDesc> getProductDescs() {
		if (productDescs == null) {
			productDescs = new java.util.LinkedHashSet<com.ecom.domain.ProductDesc>();
		}
		return productDescs;
	}

	/**
	 */
	public void setProductKeywords(Set<ProductKeyword> productKeywords) {
		this.productKeywords = productKeywords;
	}

	/**
	 */
	public Set<ProductKeyword> getProductKeywords() {
		if (productKeywords == null) {
			productKeywords = new java.util.LinkedHashSet<com.ecom.domain.ProductKeyword>();
		}
		return productKeywords;
	}

	/**
	 */
	public void setProductCustomFields(Set<ProductCustomField> productCustomFields) {
		this.productCustomFields = productCustomFields;
	}

	/**
	 */
	public Set<ProductCustomField> getProductCustomFields() {
		if (productCustomFields == null) {
			productCustomFields = new java.util.LinkedHashSet<com.ecom.domain.ProductCustomField>();
		}
		return productCustomFields;
	}

	/**
	 */
	public Product() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Product that) {
		setProdId(that.getProdId());
		setInternalName(that.getInternalName());
		setMasterCatId(that.getMasterCatId());
		setTaxClassId(that.getTaxClassId());
		setOrdered(that.getOrdered());
		setOrderUnits(that.getOrderUnits());
		setProductCost(that.getProductCost());
		setMargin(that.getMargin());
		setCustom(that.getCustom());
		setDuty(that.getDuty());
		setComputedPrice(that.getComputedPrice());
		setUseEnteredPrice(that.getUseEnteredPrice());
		setEnteredPrice(that.getEnteredPrice());
		setSortOrder(that.getSortOrder());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
		setDesignerId(that.getDesignerId());
		setStoreId(that.getStoreId());
		setProductCustomFieldVals(new java.util.LinkedHashSet<com.ecom.domain.ProductCustomFieldVal>(that.getProductCustomFieldVals()));
		setProductMedias(new java.util.LinkedHashSet<com.ecom.domain.ProductMedia>(that.getProductMedias()));
		setProductDescs(new java.util.LinkedHashSet<com.ecom.domain.ProductDesc>(that.getProductDescs()));
		setProductKeywords(new java.util.LinkedHashSet<com.ecom.domain.ProductKeyword>(that.getProductKeywords()));
		setProductCustomFields(new java.util.LinkedHashSet<com.ecom.domain.ProductCustomField>(that.getProductCustomFields()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("prodId=[").append(prodId).append("] ");
		buffer.append("internalName=[").append(internalName).append("] ");
		buffer.append("masterCatId=[").append(masterCatId).append("] ");
		buffer.append("taxClassId=[").append(taxClassId).append("] ");
		buffer.append("ordered=[").append(ordered).append("] ");
		buffer.append("orderUnits=[").append(orderUnits).append("] ");
		buffer.append("productCost=[").append(productCost).append("] ");
		buffer.append("margin=[").append(margin).append("] ");
		buffer.append("custom=[").append(custom).append("] ");
		buffer.append("duty=[").append(duty).append("] ");
		buffer.append("computedPrice=[").append(computedPrice).append("] ");
		buffer.append("useEnteredPrice=[").append(useEnteredPrice).append("] ");
		buffer.append("enteredPrice=[").append(enteredPrice).append("] ");
		buffer.append("sortOrder=[").append(sortOrder).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");
		/*
		buffer.append("publicName=[").append(publicName).append("] ");
		buffer.append("description=[").append(description).append("] ");
		buffer.append("keywordId=[").append(keywordId).append("] ");
		buffer.append("keywordDesc=[").append(keywordDesc).append("] ");
		buffer.append("selectedKeywords=[").append(selectedKeywords).append("] ");
		*/
		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Product))
			return false;
		Product equalCheck = (Product) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAdminUserByDateAdded", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.dateAdded = ?1"),
		@NamedQuery(name = "findAdminUserByDateAddedAfter", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.dateAdded > ?1"),
		@NamedQuery(name = "findAdminUserByDateAddedBefore", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.dateAdded < ?1"),
		@NamedQuery(name = "findAdminUserByEmail", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.email = ?1"),
		@NamedQuery(name = "findAdminUserByEmailContaining", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.email like ?1"),
		@NamedQuery(name = "findAdminUserByLangId", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.langId = ?1"),
		@NamedQuery(name = "findAdminUserByLastLoginDate", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.lastLoginDate = ?1"),
		@NamedQuery(name = "findAdminUserByLastLoginDateAfter", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.lastLoginDate > ?1"),
		@NamedQuery(name = "findAdminUserByLastLoginDateBefore", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.lastLoginDate < ?1"),
		@NamedQuery(name = "findAdminUserByName", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.name = ?1"),
		@NamedQuery(name = "findAdminUserByNameContaining", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.name like ?1"),
		@NamedQuery(name = "findAdminUserByPassword", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.password = ?1"),
		@NamedQuery(name = "findAdminUserByPasswordContaining", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.password like ?1"),
		@NamedQuery(name = "findAdminUserByPrimaryKey", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.userId = ?1"),
		@NamedQuery(name = "findAdminUserByStatusId", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.statusId = ?1"),
		@NamedQuery(name = "findAdminUserByUserId", query = "select myAdminUser from AdminUser myAdminUser where myAdminUser.userId = ?1"),
		@NamedQuery(name = "findAllAdminUsers", query = "select myAdminUser from AdminUser myAdminUser") })
@Table(schema = "ecom", name = "admin_user")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "AdminUser")
@XmlRootElement(namespace = "ecommerce/com/ecom/domain")
public class AdminUser implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "user_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@SequenceGenerator(name="Admin_User_ID_Gen", sequenceName="ecom.admin_user_user_id_seq")
	@Id @GeneratedValue(generator="Admin_User_ID_Gen")
  	@XmlElement
	Integer userId;
	/**
	 */

	@Column(name = "name", length = 40, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;
	/**
	 */

	@Column(name = "password", length = 40)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String password;
	/**
	 */

	@Column(name = "email", length = 128)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String email;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "last_login_date")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar lastLoginDate;
	/**
	 */

	@Column(name = "lang_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "role_id", referencedColumnName = "role_id") })
	@XmlTransient
	Role role;
	/**
	 */
	@OneToMany(mappedBy = "adminUser", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.AdminUserStore> adminUserStores;

	/**
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 */
	public Integer getUserId() {
		return this.userId;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setLastLoginDate(Calendar lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	/**
	 */
	public Calendar getLastLoginDate() {
		return this.lastLoginDate;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 */
	public Role getRole() {
		return role;
	}

	/**
	 */
	public void setAdminUserStores(Set<AdminUserStore> adminUserStores) {
		this.adminUserStores = adminUserStores;
	}

	/**
	 */
	public Set<AdminUserStore> getAdminUserStores() {
		if (adminUserStores == null) {
			adminUserStores = new java.util.LinkedHashSet<com.ecom.domain.AdminUserStore>();
		}
		return adminUserStores;
	}

	/**
	 */
	public AdminUser() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(AdminUser that) {
		setUserId(that.getUserId());
		setName(that.getName());
		setPassword(that.getPassword());
		setEmail(that.getEmail());
		setDateAdded(that.getDateAdded());
		setLastLoginDate(that.getLastLoginDate());
		setLangId(that.getLangId());
		setStatusId(that.getStatusId());
		setRole(that.getRole());
		setAdminUserStores(new java.util.LinkedHashSet<com.ecom.domain.AdminUserStore>(that.getAdminUserStores()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("userId=[").append(userId).append("] ");
		buffer.append("name=[").append(name).append("] ");
		buffer.append("password=[").append(password).append("] ");
		buffer.append("email=[").append(email).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("lastLoginDate=[").append(lastLoginDate).append("] ");
		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((userId == null) ? 0 : userId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof AdminUser))
			return false;
		AdminUser equalCheck = (AdminUser) obj;
		if ((userId == null && equalCheck.userId != null) || (userId != null && equalCheck.userId == null))
			return false;
		if (userId != null && !userId.equals(equalCheck.userId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.CategoryDescPK.class)
@Entity
@NamedQueries({
		@NamedQuery(name = "findAllCategoryDescs", query = "select myCategoryDesc from CategoryDesc myCategoryDesc"),
		@NamedQuery(name = "findCategoryDescByCategoryId", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.categoryId = ?1"),
		@NamedQuery(name = "findCategoryDescByDescription", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.description = ?1"),
		@NamedQuery(name = "findCategoryDescByDescriptionContaining", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.description like ?1"),
		@NamedQuery(name = "findCategoryDescByImageLocation", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.imageLocation = ?1"),
		@NamedQuery(name = "findCategoryDescByImageLocationContaining", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.imageLocation like ?1"),
		@NamedQuery(name = "findCategoryDescByLangId", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.langId = ?1"),
		@NamedQuery(name = "findCategoryDescByMetaDesc", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.metaDesc = ?1"),
		@NamedQuery(name = "findCategoryDescByMetaDescContaining", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.metaDesc like ?1"),
		@NamedQuery(name = "findCategoryDescByMetaKeywords", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.metaKeywords = ?1"),
		@NamedQuery(name = "findCategoryDescByMetaKeywordsContaining", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.metaKeywords like ?1"),
		@NamedQuery(name = "findCategoryDescByMetaTagsTitle", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.metaTagsTitle = ?1"),
		@NamedQuery(name = "findCategoryDescByMetaTagsTitleContaining", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.metaTagsTitle like ?1"),
		@NamedQuery(name = "findCategoryDescByName", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.name = ?1"),
		@NamedQuery(name = "findCategoryDescByNameContaining", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.name like ?1"),
		@NamedQuery(name = "findCategoryDescByPrimaryKey", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.categoryId = ?1 and myCategoryDesc.langId = ?2"),
		@NamedQuery(name = "findCategoryDescByStoreId", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.storeId = ?1"),
		@NamedQuery(name = "findCategoryDescByTags", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.tags = ?1"),
		@NamedQuery(name = "findCategoryDescByTagsContaining", query = "select myCategoryDesc from CategoryDesc myCategoryDesc where myCategoryDesc.tags like ?1") })
@Table(schema = "ecom", name = "category_desc")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "CategoryDesc")
public class CategoryDesc implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "category_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer categoryId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "name", length = 32, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;
	/**
	 */

	@Column(name = "description", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String description;
	/**
	 */

	@Column(name = "store_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;
	/**
	 */

	@Column(name = "tags")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String tags;
	/**
	 */

	@Column(name = "meta_tags_title", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String metaTagsTitle;
	/**
	 */

	@Column(name = "meta_keywords", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String metaKeywords;
	/**
	 */

	@Column(name = "meta_desc", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String metaDesc;
	/**
	 */

	@Column(name = "image_location", length = 64)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String imageLocation;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "category_id", referencedColumnName = "category_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Category category;

	/**
	 */
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	/**
	 */
	public Integer getCategoryId() {
		return this.categoryId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setTags(String tags) {
		this.tags = tags;
	}

	/**
	 */
	public String getTags() {
		return this.tags;
	}

	/**
	 */
	public void setMetaTagsTitle(String metaTagsTitle) {
		this.metaTagsTitle = metaTagsTitle;
	}

	/**
	 */
	public String getMetaTagsTitle() {
		return this.metaTagsTitle;
	}

	/**
	 */
	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}

	/**
	 */
	public String getMetaKeywords() {
		return this.metaKeywords;
	}

	/**
	 */
	public void setMetaDesc(String metaDesc) {
		this.metaDesc = metaDesc;
	}

	/**
	 */
	public String getMetaDesc() {
		return this.metaDesc;
	}

	/**
	 */
	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	/**
	 */
	public String getImageLocation() {
		return this.imageLocation;
	}

	/**
	 */
	public void setCategory(Category category) {
		this.category = category;
	}

	/**
	 */
	public Category getCategory() {
		return category;
	}

	/**
	 */
	public CategoryDesc() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(CategoryDesc that) {
		setCategoryId(that.getCategoryId());
		setLangId(that.getLangId());
		setName(that.getName());
		setDescription(that.getDescription());
		setStoreId(that.getStoreId());
		setTags(that.getTags());
		setMetaTagsTitle(that.getMetaTagsTitle());
		setMetaKeywords(that.getMetaKeywords());
		setMetaDesc(that.getMetaDesc());
		setImageLocation(that.getImageLocation());
		setCategory(that.getCategory());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("categoryId=[").append(categoryId).append("] ");
		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("name=[").append(name).append("] ");
		buffer.append("description=[").append(description).append("] ");
		buffer.append("storeId=[").append(storeId).append("] ");
		buffer.append("tags=[").append(tags).append("] ");
		buffer.append("metaTagsTitle=[").append(metaTagsTitle).append("] ");
		buffer.append("metaKeywords=[").append(metaKeywords).append("] ");
		buffer.append("metaDesc=[").append(metaDesc).append("] ");
		buffer.append("imageLocation=[").append(imageLocation).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((categoryId == null) ? 0 : categoryId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CategoryDesc))
			return false;
		CategoryDesc equalCheck = (CategoryDesc) obj;
		if ((categoryId == null && equalCheck.categoryId != null) || (categoryId != null && equalCheck.categoryId == null))
			return false;
		if (categoryId != null && !categoryId.equals(equalCheck.categoryId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}
}

package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.ProductDescPK.class)
@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProductDescs", query = "select myProductDesc from ProductDesc myProductDesc"),
		@NamedQuery(name = "findProductDescByDescription", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.description = ?1"),
		@NamedQuery(name = "findProductDescByDescriptionContaining", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.description like ?1"),
		@NamedQuery(name = "findProductDescByLangId", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.langId = ?1"),
		@NamedQuery(name = "findProductDescByPrimaryKey", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.prodId = ?1 and myProductDesc.langId = ?2"),
		@NamedQuery(name = "findProductDescByProdId", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.prodId = ?1"),
		@NamedQuery(name = "findProductDescByPublicName", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.publicName = ?1"),
		@NamedQuery(name = "findProductDescByPublicNameContaining", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.publicName like ?1"),
		@NamedQuery(name = "findProductDescByStoreId", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.storeId = ?1"),
		@NamedQuery(name = "findProductDescBySummary", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.summary = ?1"),
		@NamedQuery(name = "findProductDescBySummaryContaining", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.summary like ?1"),
		@NamedQuery(name = "findProductDescByUrl", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.url = ?1"),
		@NamedQuery(name = "findProductDescByUrlContaining", query = "select myProductDesc from ProductDesc myProductDesc where myProductDesc.url like ?1") })
@Table(schema = "ecom", name = "product_desc")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "ProductDesc")
public class ProductDesc implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer prodId;
	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "public_name", length = 64, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String publicName;
	/**
	 */

	@Column(name = "summary", length = 2000)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String summary;
	/**
	 */

	@Column(name = "description", length = 256)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String description;
	/**
	 */

	@Column(name = "url", length = 128)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String url;
	/**
	 */

	@Column(name = "store_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;
	
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "prod_id", referencedColumnName = "prod_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Product product;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id", insertable = false, updatable = false) })
	@XmlTransient
	Store store;

	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setPublicName(String publicName) {
		this.publicName = publicName;
	}

	/**
	 */
	public String getPublicName() {
		return this.publicName;
	}

	/**
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 */
	public String getSummary() {
		return this.summary;
	}

	/**
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 */
	public String getUrl() {
		return this.url;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}
	
	/**
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}

	/**
	 */
	public ProductDesc() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProductDesc that) {
		setProdId(that.getProdId());
		setLangId(that.getLangId());
		setPublicName(that.getPublicName());
		setSummary(that.getSummary());
		setDescription(that.getDescription());
		setUrl(that.getUrl());
		setStoreId(that.getStoreId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("prodId=[").append(prodId).append("] ");
		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("publicName=[").append(publicName).append("] ");
		buffer.append("summary=[").append(summary).append("] ");
		buffer.append("description=[").append(description).append("] ");
		buffer.append("url=[").append(url).append("] ");
		buffer.append("storeId=[").append(storeId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProductDesc))
			return false;
		ProductDesc equalCheck = (ProductDesc) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}
}

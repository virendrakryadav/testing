package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllLanguages", query = "select myLanguage from Language myLanguage"),
		@NamedQuery(name = "findLanguageByCode", query = "select myLanguage from Language myLanguage where myLanguage.code = ?1"),
		@NamedQuery(name = "findLanguageByCodeContaining", query = "select myLanguage from Language myLanguage where myLanguage.code like ?1"),
		@NamedQuery(name = "findLanguageByDateAdded", query = "select myLanguage from Language myLanguage where myLanguage.dateAdded = ?1"),
		@NamedQuery(name = "findLanguageByDateAddedAfter", query = "select myLanguage from Language myLanguage where myLanguage.dateAdded > ?1"),
		@NamedQuery(name = "findLanguageByDateAddedBefore", query = "select myLanguage from Language myLanguage where myLanguage.dateAdded < ?1"),
		@NamedQuery(name = "findLanguageByDateModified", query = "select myLanguage from Language myLanguage where myLanguage.dateModified = ?1"),
		@NamedQuery(name = "findLanguageByDateModifiedAfter", query = "select myLanguage from Language myLanguage where myLanguage.dateModified > ?1"),
		@NamedQuery(name = "findLanguageByDateModifiedBefore", query = "select myLanguage from Language myLanguage where myLanguage.dateModified < ?1"),
		@NamedQuery(name = "findLanguageByDirectory", query = "select myLanguage from Language myLanguage where myLanguage.directory = ?1"),
		@NamedQuery(name = "findLanguageByDirectoryContaining", query = "select myLanguage from Language myLanguage where myLanguage.directory like ?1"),
		@NamedQuery(name = "findLanguageByImageLocation", query = "select myLanguage from Language myLanguage where myLanguage.imageLocation = ?1"),
		@NamedQuery(name = "findLanguageByImageLocationContaining", query = "select myLanguage from Language myLanguage where myLanguage.imageLocation like ?1"),
		@NamedQuery(name = "findLanguageByLangId", query = "select myLanguage from Language myLanguage where myLanguage.langId = ?1"),
		@NamedQuery(name = "findLanguageByLocale", query = "select myLanguage from Language myLanguage where myLanguage.locale = ?1"),
		@NamedQuery(name = "findLanguageByLocaleContaining", query = "select myLanguage from Language myLanguage where myLanguage.locale like ?1"),
		@NamedQuery(name = "findLanguageByName", query = "select myLanguage from Language myLanguage where myLanguage.name = ?1"),
		@NamedQuery(name = "findLanguageByNameContaining", query = "select myLanguage from Language myLanguage where myLanguage.name like ?1"),
		@NamedQuery(name = "findLanguageByPrimaryKey", query = "select myLanguage from Language myLanguage where myLanguage.langId = ?1"),
		@NamedQuery(name = "findLanguageBySortOrder", query = "select myLanguage from Language myLanguage where myLanguage.sortOrder = ?1"),
		@NamedQuery(name = "findLanguageByStatusId", query = "select myLanguage from Language myLanguage where myLanguage.statusId = ?1") })
@Table(schema = "ecom", name = "language")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "Language")
public class Language implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "lang_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer langId;
	/**
	 */

	@Column(name = "name", length = 32, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;
	/**
	 */

	@Column(name = "code", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String code;
	/**
	 */

	@Column(name = "image_location", length = 64)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String imageLocation;
	/**
	 */

	@Column(name = "directory", length = 32)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String directory;
	/**
	 */

	@Column(name = "sort_order")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sortOrder;
	/**
	 */

	@Column(name = "locale", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String locale;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;

	/**
	 */
	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	/**
	 */
	public Integer getLangId() {
		return this.langId;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 */
	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	/**
	 */
	public String getImageLocation() {
		return this.imageLocation;
	}

	/**
	 */
	public void setDirectory(String directory) {
		this.directory = directory;
	}

	/**
	 */
	public String getDirectory() {
		return this.directory;
	}

	/**
	 */
	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 */
	public Integer getSortOrder() {
		return this.sortOrder;
	}

	/**
	 */
	public void setLocale(String locale) {
		this.locale = locale;
	}

	/**
	 */
	public String getLocale() {
		return this.locale;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public Language() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Language that) {
		setLangId(that.getLangId());
		setName(that.getName());
		setCode(that.getCode());
		setImageLocation(that.getImageLocation());
		setDirectory(that.getDirectory());
		setSortOrder(that.getSortOrder());
		setLocale(that.getLocale());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("langId=[").append(langId).append("] ");
		buffer.append("name=[").append(name).append("] ");
		buffer.append("code=[").append(code).append("] ");
		buffer.append("imageLocation=[").append(imageLocation).append("] ");
		buffer.append("directory=[").append(directory).append("] ");
		buffer.append("sortOrder=[").append(sortOrder).append("] ");
		buffer.append("locale=[").append(locale).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((langId == null) ? 0 : langId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Language))
			return false;
		Language equalCheck = (Language) obj;
		if ((langId == null && equalCheck.langId != null) || (langId != null && equalCheck.langId == null))
			return false;
		if (langId != null && !langId.equals(equalCheck.langId))
			return false;
		return true;
	}
}

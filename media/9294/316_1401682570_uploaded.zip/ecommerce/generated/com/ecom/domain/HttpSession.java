package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import javax.persistence.Id;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.HttpSessionPK.class)
@Entity
@Table(schema = "ecom", name = "http_session")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "HttpSession")
public class HttpSession implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "session_id", length = 256, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String sessionId;
	/**
	 */

	@Column(name = "website_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer websiteId;
	/**
	 */

	@Column(name = "session_expires")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sessionExpires;
	/**
	 */

	@Column(name = "session_data")
	@Basic(fetch = FetchType.EAGER)
	@Lob
	@XmlElement
	byte[] sessionData;

	/**
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	/**
	 */
	public String getSessionId() {
		return this.sessionId;
	}

	/**
	 */
	public void setWebsiteId(Integer websiteId) {
		this.websiteId = websiteId;
	}

	/**
	 */
	public Integer getWebsiteId() {
		return this.websiteId;
	}

	/**
	 */
	public void setSessionExpires(Integer sessionExpires) {
		this.sessionExpires = sessionExpires;
	}

	/**
	 */
	public Integer getSessionExpires() {
		return this.sessionExpires;
	}

	/**
	 */
	public void setSessionData(byte[] sessionData) {
		this.sessionData = sessionData;
	}

	/**
	 */
	public byte[] getSessionData() {
		return this.sessionData;
	}

	/**
	 */
	public HttpSession() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(HttpSession that) {
		setSessionId(that.getSessionId());
		setWebsiteId(that.getWebsiteId());
		setSessionExpires(that.getSessionExpires());
		setSessionData(that.getSessionData());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("sessionId=[").append(sessionId).append("] ");
		buffer.append("websiteId=[").append(websiteId).append("] ");
		buffer.append("sessionExpires=[").append(sessionExpires).append("] ");
		buffer.append("sessionData=[").append(sessionData).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((sessionId == null) ? 0 : sessionId.hashCode()));
		result = (int) (prime * result + ((websiteId == null) ? 0 : websiteId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof HttpSession))
			return false;
		HttpSession equalCheck = (HttpSession) obj;
		if ((sessionId == null && equalCheck.sessionId != null) || (sessionId != null && equalCheck.sessionId == null))
			return false;
		if (sessionId != null && !sessionId.equals(equalCheck.sessionId))
			return false;
		if ((websiteId == null && equalCheck.websiteId != null) || (websiteId != null && equalCheck.websiteId == null))
			return false;
		if (websiteId != null && !websiteId.equals(equalCheck.websiteId))
			return false;
		return true;
	}
}

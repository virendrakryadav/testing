package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllKeywords", query = "select myKeyword from Keyword myKeyword"),
		@NamedQuery(name = "findKeywordByDateAdded", query = "select myKeyword from Keyword myKeyword where myKeyword.dateAdded = ?1"),
		@NamedQuery(name = "findKeywordByDateAddedAfter", query = "select myKeyword from Keyword myKeyword where myKeyword.dateAdded > ?1"),
		@NamedQuery(name = "findKeywordByDateAddedBefore", query = "select myKeyword from Keyword myKeyword where myKeyword.dateAdded < ?1"),
		@NamedQuery(name = "findKeywordByDateModified", query = "select myKeyword from Keyword myKeyword where myKeyword.dateModified = ?1"),
		@NamedQuery(name = "findKeywordByDateModifiedAfter", query = "select myKeyword from Keyword myKeyword where myKeyword.dateModified > ?1"),
		@NamedQuery(name = "findKeywordByDateModifiedBefore", query = "select myKeyword from Keyword myKeyword where myKeyword.dateModified < ?1"),
		@NamedQuery(name = "findKeywordByKeywordId", query = "select myKeyword from Keyword myKeyword where myKeyword.keywordId = ?1"),
		@NamedQuery(name = "findKeywordByPrimaryKey", query = "select myKeyword from Keyword myKeyword where myKeyword.keywordId = ?1"),
		@NamedQuery(name = "findKeywordByStatusId", query = "select myKeyword from Keyword myKeyword where myKeyword.statusId = ?1"),
		@NamedQuery(name = "findKeywordByStoreId", query = "select myKeyword from Keyword myKeyword where myKeyword.storeId = ?1") })
@Table(schema = "ecom", name = "keyword")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "Keyword")
public class Keyword implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "keyword_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer keywordId;
	/**
	 */

	@Column(name = "store_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;
	
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id",insertable = false, updatable = false) })
	@XmlTransient
	Store store;
	/**
	 */
	@OneToMany(mappedBy = "keyword", fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.ProductKeyword> productKeywords;

	/**
	 */
	public void setKeywordId(Integer keywordId) {
		this.keywordId = keywordId;
	}

	/**
	 */
	public Integer getKeywordId() {
		return this.keywordId;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}
	
	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}

	/**
	 */
	public void setProductKeywords(Set<ProductKeyword> productKeywords) {
		this.productKeywords = productKeywords;
	}

	/**
	 */
	public Set<ProductKeyword> getProductKeywords() {
		if (productKeywords == null) {
			productKeywords = new java.util.LinkedHashSet<com.ecom.domain.ProductKeyword>();
		}
		return productKeywords;
	}	

	/**
	 */
	public Keyword() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Keyword that) {
		setKeywordId(that.getKeywordId());
		setStoreId(that.getStoreId());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("keywordId=[").append(keywordId).append("] ");
		buffer.append("storeId=[").append(storeId).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((keywordId == null) ? 0 : keywordId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Keyword))
			return false;
		Keyword equalCheck = (Keyword) obj;
		if ((keywordId == null && equalCheck.keywordId != null) || (keywordId != null && equalCheck.keywordId == null))
			return false;
		if (keywordId != null && !keywordId.equals(equalCheck.keywordId))
			return false;
		return true;
	}
}

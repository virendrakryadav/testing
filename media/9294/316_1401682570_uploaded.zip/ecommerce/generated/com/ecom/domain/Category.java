package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllCategorys", query = "select myCategory from Category myCategory"),
		@NamedQuery(name = "findCategoryByCategoryId", query = "select myCategory from Category myCategory where myCategory.categoryId = ?1"),
		@NamedQuery(name = "findCategoryByDateAdded", query = "select myCategory from Category myCategory where myCategory.dateAdded = ?1"),
		@NamedQuery(name = "findCategoryByDateAddedAfter", query = "select myCategory from Category myCategory where myCategory.dateAdded > ?1"),
		@NamedQuery(name = "findCategoryByDateAddedBefore", query = "select myCategory from Category myCategory where myCategory.dateAdded < ?1"),
		@NamedQuery(name = "findCategoryByDateModified", query = "select myCategory from Category myCategory where myCategory.dateModified = ?1"),
		@NamedQuery(name = "findCategoryByDateModifiedAfter", query = "select myCategory from Category myCategory where myCategory.dateModified > ?1"),
		@NamedQuery(name = "findCategoryByDateModifiedBefore", query = "select myCategory from Category myCategory where myCategory.dateModified < ?1"),
		@NamedQuery(name = "findCategoryByPrimaryKey", query = "select myCategory from Category myCategory where myCategory.categoryId = ?1"),
		@NamedQuery(name = "findCategoryBySortOrder", query = "select myCategory from Category myCategory where myCategory.sortOrder = ?1"),
		@NamedQuery(name = "findCategoryByStatusId", query = "select myCategory from Category myCategory where myCategory.statusId = ?1"),
		@NamedQuery(name = "findCategoryByStoreId", query = "select myCategory from Category myCategory where myCategory.storeId = ?1") })
@Table(schema = "ecom", name = "category")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "Category")
@XmlRootElement(namespace = "sample/com/ecom/domain")
public class Category implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "category_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer categoryId;
	/**
	 */

	@Column(name = "store_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer storeId;
	/**
	 */

	@Column(name = "sort_order")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sortOrder;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_added")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateAdded;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "date_modified")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar dateModified;
	/**
	 */

	@Column(name = "status_id")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer statusId;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "parent_id", referencedColumnName = "category_id") })
	@XmlTransient
	Category category;
	/**
	 */
	@OneToMany(mappedBy = "category", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.CategoryDesc> categoryDescs;
	/**
	 */
	@OneToMany(mappedBy = "category", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.ecom.domain.Category> categories;

	/**
	 */
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	/**
	 */
	public Integer getCategoryId() {
		return this.categoryId;
	}

	/**
	 */
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	/**
	 */
	public Integer getStoreId() {
		return this.storeId;
	}

	/**
	 */
	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 */
	public Integer getSortOrder() {
		return this.sortOrder;
	}

	/**
	 */
	public void setDateAdded(Calendar dateAdded) {
		this.dateAdded = dateAdded;
	}

	/**
	 */
	public Calendar getDateAdded() {
		return this.dateAdded;
	}

	/**
	 */
	public void setDateModified(Calendar dateModified) {
		this.dateModified = dateModified;
	}

	/**
	 */
	public Calendar getDateModified() {
		return this.dateModified;
	}

	/**
	 */
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	/**
	 */
	public Integer getStatusId() {
		return this.statusId;
	}

	/**
	 */
	public void setCategory(Category category) {
		this.category = category;
	}

	/**
	 */
	public Category getCategory() {
		return category;
	}

	/**
	 */
	public void setCategoryDescs(Set<CategoryDesc> categoryDescs) {
		this.categoryDescs = categoryDescs;
	}

	/**
	 */
	public Set<CategoryDesc> getCategoryDescs() {
		if (categoryDescs == null) {
			categoryDescs = new java.util.LinkedHashSet<com.ecom.domain.CategoryDesc>();
		}
		return categoryDescs;
	}

	/**
	 */
	public void setCategories(Set<Category> categories) {
		this.categories = categories;
	}

	/**
	 */
	public Set<Category> getCategories() {
		if (categories == null) {
			categories = new java.util.LinkedHashSet<com.ecom.domain.Category>();
		}
		return categories;
	}

	/**
	 */
	public Category() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Category that) {
		setCategoryId(that.getCategoryId());
		setStoreId(that.getStoreId());
		setSortOrder(that.getSortOrder());
		setDateAdded(that.getDateAdded());
		setDateModified(that.getDateModified());
		setStatusId(that.getStatusId());
		setCategory(that.getCategory());
		setCategoryDescs(new java.util.LinkedHashSet<com.ecom.domain.CategoryDesc>(that.getCategoryDescs()));
		setCategories(new java.util.LinkedHashSet<com.ecom.domain.Category>(that.getCategories()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("categoryId=[").append(categoryId).append("] ");
		buffer.append("storeId=[").append(storeId).append("] ");
		buffer.append("sortOrder=[").append(sortOrder).append("] ");
		buffer.append("dateAdded=[").append(dateAdded).append("] ");
		buffer.append("dateModified=[").append(dateModified).append("] ");
		buffer.append("statusId=[").append(statusId).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((categoryId == null) ? 0 : categoryId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Category))
			return false;
		Category equalCheck = (Category) obj;
		if ((categoryId == null && equalCheck.categoryId != null) || (categoryId != null && equalCheck.categoryId == null))
			return false;
		if (categoryId != null && !categoryId.equals(equalCheck.categoryId))
			return false;
		return true;
	}
}

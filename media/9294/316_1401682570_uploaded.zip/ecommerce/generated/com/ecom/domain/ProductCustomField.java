package com.ecom.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */
@IdClass(com.ecom.domain.ProductCustomFieldPK.class)
@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProductCustomFields", query = "select myProductCustomField from ProductCustomField myProductCustomField"),
		@NamedQuery(name = "findProductCustomFieldByPrimaryKey", query = "select myProductCustomField from ProductCustomField myProductCustomField where myProductCustomField.prodId = ?1 and myProductCustomField.customFieldId = ?2") })
@Table(schema = "ecom", name = "product_custom_field")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "ecommerce/com/ecom/domain", name = "ProductCustomField")
public class ProductCustomField implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "prod_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer prodId;
	/**
	 */

	@Column(name = "custom_field_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer customFieldId;
	/**
	 */

	@Column(name = "sort_order")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sortOrder;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "prod_id", referencedColumnName = "prod_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Product product;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "store_id", referencedColumnName = "store_id") })
	@XmlTransient
	Store store;

	/**
	 */
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	/**
	 */
	public Integer getProdId() {
		return this.prodId;
	}

	/**
	 */
	public void setCustomFieldId(Integer customFieldId) {
		this.customFieldId = customFieldId;
	}

	/**
	 */
	public Integer getCustomFieldId() {
		return this.customFieldId;
	}

	/**
	 */
	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 */
	public Integer getSortOrder() {
		return this.sortOrder;
	}

	/**
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 */
	public void setStore(Store store) {
		this.store = store;
	}

	/**
	 */
	public Store getStore() {
		return store;
	}

	/**
	 */
	public ProductCustomField() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProductCustomField that) {
		setProdId(that.getProdId());
		setCustomFieldId(that.getCustomFieldId());
		setSortOrder(that.getSortOrder());
		setProduct(that.getProduct());
		setStore(that.getStore());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("prodId=[").append(prodId).append("] ");
		buffer.append("customFieldId=[").append(customFieldId).append("] ");
		buffer.append("sortOrder=[").append(sortOrder).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((prodId == null) ? 0 : prodId.hashCode()));
		result = (int) (prime * result + ((customFieldId == null) ? 0 : customFieldId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProductCustomField))
			return false;
		ProductCustomField equalCheck = (ProductCustomField) obj;
		if ((prodId == null && equalCheck.prodId != null) || (prodId != null && equalCheck.prodId == null))
			return false;
		if (prodId != null && !prodId.equals(equalCheck.prodId))
			return false;
		if ((customFieldId == null && equalCheck.customFieldId != null) || (customFieldId != null && equalCheck.customFieldId == null))
			return false;
		if (customFieldId != null && !customFieldId.equals(equalCheck.customFieldId))
			return false;
		return true;
	}
}

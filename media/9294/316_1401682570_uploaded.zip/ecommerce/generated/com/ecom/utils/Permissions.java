package com.ecom.utils;
import javax.persistence.Transient;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.ecom.domain.FeatureRole;
import com.ecom.service.FeatureRoleService;
import com.ecom.session.UserSessionInfo;

public class Permissions 
{
	public static final Integer FEATURE_CHANGE_STORE = new Integer(1);
	public static final Integer FEATURE_CHANGE_LANG = new Integer(2);
	public static final Integer FEATURE_VIEW_ADMIN_USER = new Integer(3);
	public static final Integer FEATURE_ADD_ADMIN_USER = new Integer(4);
	public static final Integer FEATURE_EDIT_ADMIN_USER = new Integer(5);
	public static final Integer FEATURE_DELETE_ADMIN_USER = new Integer(6);
	public static final Integer FEATURE_VIEW_PRODUCT = new Integer(7);
	public static final Integer FEATURE_ADD_PRODUCT = new Integer(8);
	public static final Integer FEATURE_EDIT_PRODUCT = new Integer(9);
	public static final Integer FEATURE_DELETE_PRODUCT = new Integer(10);

	private Integer roleId;
	/**
	 * The service being tested, injected by Spring.
	 *
	 */
	@Autowired
	protected FeatureRoleService service;

	public Permissions(Integer roleId)
	{
		this.roleId = roleId;
	}
	private boolean isAllowed(Integer featureId)
	{
		System.out.println("Permissions.isAllowed() featureId ["+featureId+"] roleId ["+roleId+"]");
		FeatureRole response = service.findFeatureRoleByPrimaryKey(featureId, roleId);
		System.out.println("Permissions.isAllowed() FeatureRole "+response);
		return (response != null);		
	}
	
	public static boolean isFeatureAllowed(HttpServletRequest request, Integer featureId)
	{
		HttpSession session = request.getSession(false);
		if (session == null)
			return false;
		
		UserSessionInfo adminUserSessionInfo = (UserSessionInfo)session.getAttribute(
													UserSessionInfo.USER_SESSION_INFO_KEY);
		if (adminUserSessionInfo == null)
		{   System.out.println("isFeatureAllowed() adminUserSessionInfo is null ");
			return false;
		}
		Permissions permissions = adminUserSessionInfo.permissions;
	    return 	permissions.isAllowed(featureId);
	}
}
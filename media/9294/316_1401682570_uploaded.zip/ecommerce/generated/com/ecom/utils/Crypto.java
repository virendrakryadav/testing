package com.ecom.utils;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class Crypto 
{
	private static final String AES_CRYPTO = "AES";
	private static final int BLOCK_SIZE = 128;

	//Note: This key can be stored in file and read 
	private static final String defaultAESKey = "4���1�L1�`�ć �";

	/*
	 * In case need to generate new key, use this function.
	 * 
	 * But, for ecom project, one key is generated and available in this class itself.
	 * 
	 */
	public static byte[] generateAesKey()
	{
	       // Get the KeyGenerator
		try{
	       KeyGenerator kgen = KeyGenerator.getInstance("AES");
	       kgen.init(128); // 192 and 256 bits may not be available

	       // Generate the secret key specs.
	       SecretKey skey = kgen.generateKey();
	       byte[] raw = skey.getEncoded();
	       return raw;
		}catch (Exception e)
		{
			return null;
		}
	}

	/*
	 * Returns the Encrypted string using AES symmetric cryptography with 128 block size.
	 * 
	 * In case of any exception, it returns null;
	 */
	public static String encrypt(String string, String aesKey) 
	{
		try
		{		    
		    if (aesKey == null)
		    	aesKey = defaultAESKey;	

		    byte[] raw = aesKey.getBytes();
		    
		    SecretKeySpec skeySpec = new SecretKeySpec(raw, AES_CRYPTO);

		    // Instantiate the cipher
		    Cipher cipher = Cipher.getInstance(AES_CRYPTO);
		    cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		    byte[] encrypted = cipher.doFinal(string.getBytes());
	
		    //return encrypted string
	        return new String(encrypted);
		}catch (Exception e)
		{
			return null;
		}
	}
	
	/*
	 * Returns the Decrypted string using AES symmetric cryptography with 128 block size.
	 * 
	 *  In case of any exception it return null;
	 */
	public static String decrypt(String encrypted, String aesKey) 
	{
		try
		{
		    if (aesKey == null)
		    	aesKey = defaultAESKey;	

		    byte[] raw = aesKey.getBytes();
		    SecretKeySpec skeySpec = new SecretKeySpec(raw, AES_CRYPTO);

		    // Instantiate the cipher
		    Cipher cipher = Cipher.getInstance(AES_CRYPTO);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec);
			byte[] original = cipher.doFinal(encrypted.getBytes());

			//return decrypted string
            return new String(original);
			
		}catch (Exception e)
		{
			return null;
		}
	}
}

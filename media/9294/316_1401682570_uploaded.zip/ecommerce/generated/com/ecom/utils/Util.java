package com.ecom.utils;

import java.util.ArrayList;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.ecom.domain.DesignerDesc;
import com.ecom.domain.Weight;
import com.ecom.dao.DesignerDescDAO;


public class Util {


	//@Autowired
	//private static DesignerDescDAO designerDescDAO;	
	
	public static ArrayList<Weight> getWeights(){
		String weights[] = {"1","2","3","4","5","6"};
	
		ArrayList <Weight>al = new ArrayList<Weight>();
		for(String weight:weights){
			Weight w = new Weight(weight,weight); // weight Id and weight will be same here
			al.add(w);
		}
		return al;
	}
	
	public static Set<DesignerDesc>  findAllDesignersDescForStore(Integer storeId){
		//return designerDescDAO.findAllDesignersDescForStore(storeId);
		return null;
	}
}

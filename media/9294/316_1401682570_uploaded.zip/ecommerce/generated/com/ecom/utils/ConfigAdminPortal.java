package com.ecom.utils;

import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;

public class ConfigAdminPortal {

	/*
	 * Returns AES Crypto key to be used for password encription and decription.
	 * 
	 * If null value is returned then Crypto util class uses default key.
	 */
	public static String getPWDEncriptionKey()
	{		
		return null;
	}
	
	public static String getHelpServerURL(HttpServletRequest request)
	{
		ResourceBundle bundle = Common.getResourceBundle(request, Common.RESOURCE_NAME_ADMIN_APP);
		
		String url =  bundle.getString(Common.KEY_HELP_SERVER_URL);
		if (url == null)
		{
			url = "http://127.0.0.1:8080/ecommerce/getHelpText"; //for testing
		}
		return url;
	}
}

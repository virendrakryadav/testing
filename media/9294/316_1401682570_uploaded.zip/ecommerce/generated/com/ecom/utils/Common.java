package com.ecom.utils;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ecom.domain.AdminUser;
import com.ecom.domain.Language;
import com.ecom.domain.StoreDesc;
import com.ecom.session.UserSessionInfo;

public class Common 
{
    //Resources bundles base path
	private static String BASE_PATH_ADMIN_RESOURCES = "/bundles/";

	//Resource File names
	public static final String RESOURCE_NAME_ADMIN_HELP = "admin-portal-help";
	public static final String RESOURCE_NAME_ADMIN_APP = "application-resources";
	
	//App Resource Keys
	public static final String KEY_HELP_SERVER_URL = "help.server.url";
	
	public static Permissions getPermissions(HttpServletRequest request)
	{
		UserSessionInfo usi = 
			(UserSessionInfo)request.getSession(false).getAttribute(UserSessionInfo.USER_SESSION_INFO_KEY);
		return usi.permissions;		
	}
	
	public static UserSessionInfo getUserSessionInfo(HttpServletRequest request)
	{
		UserSessionInfo usi = 
			(UserSessionInfo)request.getSession(false).getAttribute(UserSessionInfo.USER_SESSION_INFO_KEY);
		
		// Using for testing purpose
		if(usi == null){
			usi = new UserSessionInfo();
			AdminUser adminUser = new AdminUser();
			adminUser.setUserId(new Integer(1));
			//Permissions permissions;	
			Language currentLang = new Language();
			currentLang.setLangId(new Integer(1));
			StoreDesc currentStoreDesc = new StoreDesc();
			currentStoreDesc.setStoreId(new Integer(1));
			
			usi.adminUser = adminUser;
			usi.currentLang = currentLang;
			usi.currentStoreDesc = currentStoreDesc;
			
		}
		return usi;

	}

	public static Locale getUserLocale(HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
		Locale locale = null;
		if (session != null)
		{
			UserSessionInfo userSessionInfo = 
				(UserSessionInfo)session.getAttribute(UserSessionInfo.USER_SESSION_INFO_KEY);				
			if (userSessionInfo != null)
			{
				locale = new Locale(userSessionInfo.currentLang.getLocale());
				System.out.println("UserSessionInfo: lang name:"+userSessionInfo.currentLang.getName());
				System.out.println("UserSessionInfo: store id: "+userSessionInfo.currentStoreDesc.getStoreId());
				
			}else
			{
				System.out.println("UserSessionInfo is null.");
			}
		}else
		{
			System.out.println("HttpSession is null.");			
		}
		if (locale == null)
		{
			//get system Locale
			locale = Locale.getDefault();
		}
		return locale;
	}
	
	public static ResourceBundle getResourceBundle(
			HttpServletRequest request,
			String resourceFileName)
	{
		Locale locale = Common.getUserLocale(request);
		//Note: help feature us uses not very often, so reloading resource file
		//as when needed. But, can be cached.
		try{
			System.out.println("Path: "+BASE_PATH_ADMIN_RESOURCES+resourceFileName+"-"+locale.toString());
			return ResourceBundle.getBundle(BASE_PATH_ADMIN_RESOURCES+resourceFileName,locale);
		}catch (Exception e)
		{   //Return default resource  
			System.out.println("getResourceBundle EXCEPTION	: "+e.getMessage());
			return ResourceBundle.getBundle(BASE_PATH_ADMIN_RESOURCES+resourceFileName);
		}
	}
}

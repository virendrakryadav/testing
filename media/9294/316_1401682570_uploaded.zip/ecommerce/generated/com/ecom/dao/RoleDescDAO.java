package com.ecom.dao;

import com.ecom.domain.RoleDesc;

import java.util.Set;
import org.skyway.spring.util.dao.JpaDao;
import org.springframework.dao.DataAccessException;

/**
 * DAO to manage RoleDesc entities.
 * 
 */
public interface RoleDescDAO extends JpaDao<RoleDesc> {

	/**
	 * JPQL Query - findAllRoleDescs
	 *
	 */
	public Set<RoleDesc> findAllRoleDescs() throws DataAccessException;

	/**
	 * JPQL Query - findAllRoleDescs
	 *
	 */
	public Set<RoleDesc> findAllRoleDescs(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleDescByPrimaryKey
	 *
	 */
	public RoleDesc findRoleDescByPrimaryKey(Integer roleId, Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findRoleDescByPrimaryKey
	 *
	 */
	public RoleDesc findRoleDescByPrimaryKey(Integer roleId, Integer langId, int startResult, int maxRows) throws DataAccessException;

}
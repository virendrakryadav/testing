package com.ecom.dao;

import com.ecom.domain.DesignerDesc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage DesignerDesc entities.
 * 
 */
@Repository("DesignerDescDAO")
@Transactional
public class DesignerDescDAOImpl extends AbstractJpaDao<DesignerDesc> implements
		DesignerDescDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { DesignerDesc.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new DesignerDescDAOImpl
	 *
	 */
	public DesignerDescDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findDesignerDescByImageLocationContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByImageLocationContaining(String imageLocation) throws DataAccessException {

		return findDesignerDescByImageLocationContaining(imageLocation, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByImageLocationContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByImageLocationContaining(String imageLocation, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByImageLocationContaining", startResult, maxRows, imageLocation);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByStoreId
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByStoreId(Integer storeId) throws DataAccessException {

		return findDesignerDescByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByPrimaryKey
	 *
	 */
	@Transactional
	public DesignerDesc findDesignerDescByPrimaryKey(Integer designerId, Integer langId) throws DataAccessException {

		return findDesignerDescByPrimaryKey(designerId, langId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByPrimaryKey
	 *
	 */

	@Transactional
	public DesignerDesc findDesignerDescByPrimaryKey(Integer designerId, Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findDesignerDescByPrimaryKey", startResult, maxRows, designerId, langId);
			return (com.ecom.domain.DesignerDesc) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitleContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitleContaining(String metaTagsTitle) throws DataAccessException {

		return findDesignerDescByMetaTagsTitleContaining(metaTagsTitle, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitleContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitleContaining(String metaTagsTitle, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByMetaTagsTitleContaining", startResult, maxRows, metaTagsTitle);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByUrlContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByUrlContaining(String url) throws DataAccessException {

		return findDesignerDescByUrlContaining(url, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByUrlContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByUrlContaining(String url, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByUrlContaining", startResult, maxRows, url);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllDesignerDescs
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findAllDesignerDescs() throws DataAccessException {

		return findAllDesignerDescs(-1, -1);
	}

	/**
	 * JPQL Query - findAllDesignerDescs
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findAllDesignerDescs(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllDesignerDescs", startResult, maxRows);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByProfileContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByProfileContaining(String profile) throws DataAccessException {

		return findDesignerDescByProfileContaining(profile, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByProfileContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByProfileContaining(String profile, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByProfileContaining", startResult, maxRows, profile);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByDescriptionContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByDescriptionContaining(String description) throws DataAccessException {

		return findDesignerDescByDescriptionContaining(description, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByDescriptionContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByDescriptionContaining(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByDescriptionContaining", startResult, maxRows, description);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByDescription
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByDescription(String description) throws DataAccessException {

		return findDesignerDescByDescription(description, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByDescription
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByDescription(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByDescription", startResult, maxRows, description);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByMetaDesc
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaDesc(String metaDesc) throws DataAccessException {

		return findDesignerDescByMetaDesc(metaDesc, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByMetaDesc
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaDesc(String metaDesc, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByMetaDesc", startResult, maxRows, metaDesc);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByLangId
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByLangId(Integer langId) throws DataAccessException {

		return findDesignerDescByLangId(langId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByLangId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByLangId", startResult, maxRows, langId);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByImageLocation
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByImageLocation(String imageLocation) throws DataAccessException {

		return findDesignerDescByImageLocation(imageLocation, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByImageLocation
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByImageLocation(String imageLocation, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByImageLocation", startResult, maxRows, imageLocation);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByUrl
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByUrl(String url) throws DataAccessException {

		return findDesignerDescByUrl(url, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByUrl
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByUrl(String url, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByUrl", startResult, maxRows, url);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByNameContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByNameContaining(String name) throws DataAccessException {

		return findDesignerDescByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByMetaKeywords
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaKeywords(String metaKeywords) throws DataAccessException {

		return findDesignerDescByMetaKeywords(metaKeywords, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByMetaKeywords
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaKeywords(String metaKeywords, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByMetaKeywords", startResult, maxRows, metaKeywords);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByProfile
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByProfile(String profile) throws DataAccessException {

		return findDesignerDescByProfile(profile, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByProfile
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByProfile(String profile, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByProfile", startResult, maxRows, profile);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByName
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByName(String name) throws DataAccessException {

		return findDesignerDescByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByName", startResult, maxRows, name);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByDesignerId
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByDesignerId(Integer designerId) throws DataAccessException {

		return findDesignerDescByDesignerId(designerId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByDesignerId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByDesignerId(Integer designerId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByDesignerId", startResult, maxRows, designerId);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitle
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitle(String metaTagsTitle) throws DataAccessException {

		return findDesignerDescByMetaTagsTitle(metaTagsTitle, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitle
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitle(String metaTagsTitle, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByMetaTagsTitle", startResult, maxRows, metaTagsTitle);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByMetaDescContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaDescContaining(String metaDesc) throws DataAccessException {

		return findDesignerDescByMetaDescContaining(metaDesc, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByMetaDescContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaDescContaining(String metaDesc, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByMetaDescContaining", startResult, maxRows, metaDesc);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerDescByMetaKeywordsContaining
	 *
	 */
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaKeywordsContaining(String metaKeywords) throws DataAccessException {

		return findDesignerDescByMetaKeywordsContaining(metaKeywords, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerDescByMetaKeywordsContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<DesignerDesc> findDesignerDescByMetaKeywordsContaining(String metaKeywords, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerDescByMetaKeywordsContaining", startResult, maxRows, metaKeywords);
		return new LinkedHashSet<DesignerDesc>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(DesignerDesc entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.CategoryDesc;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage CategoryDesc entities.
 * 
 */
public interface CategoryDescDAO extends JpaDao<CategoryDesc> {

	/**
	 * JPQL Query - findCategoryDescByLangId
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByLangId(Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByLangId
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByPrimaryKey
	 *
	 */
	public CategoryDesc findCategoryDescByPrimaryKey(Integer categoryId, Integer langId_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByPrimaryKey
	 *
	 */
	public CategoryDesc findCategoryDescByPrimaryKey(Integer categoryId, Integer langId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitle
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitle(String metaTagsTitle) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitle
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitle(String metaTagsTitle, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByImageLocationContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByImageLocationContaining(String imageLocation) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByImageLocationContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByImageLocationContaining(String imageLocation, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaDescContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaDescContaining(String metaDesc) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaDescContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaDescContaining(String metaDesc, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByName
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByName(String name) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByName
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByName(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByDescriptionContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByDescriptionContaining(String description) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByDescriptionContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByDescriptionContaining(String description, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByImageLocation
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByImageLocation(String imageLocation_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByImageLocation
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByImageLocation(String imageLocation_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByNameContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByNameContaining(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByNameContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByNameContaining(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitleContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitleContaining(String metaTagsTitle_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitleContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitleContaining(String metaTagsTitle_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByTags
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByTags(String tags) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByTags
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByTags(String tags, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByStoreId
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByStoreId
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllCategoryDescs
	 *
	 */
	public Set<CategoryDesc> findAllCategoryDescs() throws DataAccessException;

	/**
	 * JPQL Query - findAllCategoryDescs
	 *
	 */
	public Set<CategoryDesc> findAllCategoryDescs(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByTagsContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByTagsContaining(String tags_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByTagsContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByTagsContaining(String tags_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByCategoryId
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByCategoryId(Integer categoryId_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByCategoryId
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByCategoryId(Integer categoryId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByDescription
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByDescription(String description_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByDescription
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByDescription(String description_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaKeywords
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaKeywords(String metaKeywords) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaKeywords
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaKeywords(String metaKeywords, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaDesc
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaDesc(String metaDesc_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaDesc
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaDesc(String metaDesc_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaKeywordsContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaKeywordsContaining(String metaKeywords_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryDescByMetaKeywordsContaining
	 *
	 */
	public Set<CategoryDesc> findCategoryDescByMetaKeywordsContaining(String metaKeywords_1, int startResult, int maxRows) throws DataAccessException;

}
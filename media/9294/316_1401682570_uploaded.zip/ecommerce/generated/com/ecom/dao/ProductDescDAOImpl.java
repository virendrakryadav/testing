package com.ecom.dao;

import com.ecom.domain.ProductDesc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage ProductDesc entities.
 * 
 */
@Repository("ProductDescDAO")
@Transactional
public class ProductDescDAOImpl extends AbstractJpaDao<ProductDesc> implements
		ProductDescDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { ProductDesc.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new ProductDescDAOImpl
	 *
	 */
	public ProductDescDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findProductDescByStoreId
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByStoreId(Integer storeId) throws DataAccessException {

		return findProductDescByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByLangId
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByLangId(Integer langId) throws DataAccessException {

		return findProductDescByLangId(langId, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByLangId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByLangId", startResult, maxRows, langId);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByDescription
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByDescription(String description) throws DataAccessException {

		return findProductDescByDescription(description, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByDescription
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByDescription(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByDescription", startResult, maxRows, description);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByPrimaryKey
	 *
	 */
	@Transactional
	public ProductDesc findProductDescByPrimaryKey(Integer prodId, Integer langId) throws DataAccessException {

		return findProductDescByPrimaryKey(prodId, langId, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByPrimaryKey
	 *
	 */

	@Transactional
	public ProductDesc findProductDescByPrimaryKey(Integer prodId, Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findProductDescByPrimaryKey", startResult, maxRows, prodId, langId);
			return (com.ecom.domain.ProductDesc) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findProductDescByProdId
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByProdId(Integer prodId) throws DataAccessException {

		return findProductDescByProdId(prodId, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByProdId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByProdId(Integer prodId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByProdId", startResult, maxRows, prodId);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByPublicNameContaining
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByPublicNameContaining(String publicName) throws DataAccessException {

		return findProductDescByPublicNameContaining(publicName, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByPublicNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByPublicNameContaining(String publicName, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByPublicNameContaining", startResult, maxRows, publicName);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllProductDescs
	 *
	 */
	@Transactional
	public Set<ProductDesc> findAllProductDescs() throws DataAccessException {

		return findAllProductDescs(-1, -1);
	}

	/**
	 * JPQL Query - findAllProductDescs
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findAllProductDescs(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllProductDescs", startResult, maxRows);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByPublicName
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByPublicName(String publicName) throws DataAccessException {

		return findProductDescByPublicName(publicName, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByPublicName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByPublicName(String publicName, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByPublicName", startResult, maxRows, publicName);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescBySummaryContaining
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescBySummaryContaining(String summary) throws DataAccessException {

		return findProductDescBySummaryContaining(summary, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescBySummaryContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescBySummaryContaining(String summary, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescBySummaryContaining", startResult, maxRows, summary);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescBySummary
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescBySummary(String summary) throws DataAccessException {

		return findProductDescBySummary(summary, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescBySummary
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescBySummary(String summary, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescBySummary", startResult, maxRows, summary);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByDescriptionContaining
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByDescriptionContaining(String description) throws DataAccessException {

		return findProductDescByDescriptionContaining(description, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByDescriptionContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByDescriptionContaining(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByDescriptionContaining", startResult, maxRows, description);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByUrl
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByUrl(String url) throws DataAccessException {

		return findProductDescByUrl(url, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByUrl
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByUrl(String url, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByUrl", startResult, maxRows, url);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductDescByUrlContaining
	 *
	 */
	@Transactional
	public Set<ProductDesc> findProductDescByUrlContaining(String url) throws DataAccessException {

		return findProductDescByUrlContaining(url, -1, -1);
	}

	/**
	 * JPQL Query - findProductDescByUrlContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductDesc> findProductDescByUrlContaining(String url, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductDescByUrlContaining", startResult, maxRows, url);
		return new LinkedHashSet<ProductDesc>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(ProductDesc entity) {
		return true;
	}
}

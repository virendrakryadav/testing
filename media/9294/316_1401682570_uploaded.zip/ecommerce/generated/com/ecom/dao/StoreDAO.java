package com.ecom.dao;

import com.ecom.domain.Store;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Store entities.
 * 
 */
public interface StoreDAO extends JpaDao<Store> {

	/**
	 * JPQL Query - findStoreByPrimaryKey
	 *
	 */
	public Store findStoreByPrimaryKey(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findStoreByPrimaryKey
	 *
	 */
	public Store findStoreByPrimaryKey(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllStores
	 *
	 */
	public Set<Store> findAllStores() throws DataAccessException;

	/**
	 * JPQL Query - findAllStores
	 *
	 */
	public Set<Store> findAllStores(int startResult, int maxRows) throws DataAccessException;

}
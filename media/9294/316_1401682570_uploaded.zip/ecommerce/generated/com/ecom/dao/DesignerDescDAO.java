package com.ecom.dao;

import com.ecom.domain.DesignerDesc;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage DesignerDesc entities.
 * 
 */
public interface DesignerDescDAO extends JpaDao<DesignerDesc> {

	/**
	 * JPQL Query - findDesignerDescByImageLocationContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByImageLocationContaining(String imageLocation) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByImageLocationContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByImageLocationContaining(String imageLocation, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByStoreId
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByStoreId
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByPrimaryKey
	 *
	 */
	public DesignerDesc findDesignerDescByPrimaryKey(Integer designerId, Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByPrimaryKey
	 *
	 */
	public DesignerDesc findDesignerDescByPrimaryKey(Integer designerId, Integer langId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitleContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitleContaining(String metaTagsTitle) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitleContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitleContaining(String metaTagsTitle, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByUrlContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByUrlContaining(String url) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByUrlContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByUrlContaining(String url, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllDesignerDescs
	 *
	 */
	public Set<DesignerDesc> findAllDesignerDescs() throws DataAccessException;

	/**
	 * JPQL Query - findAllDesignerDescs
	 *
	 */
	public Set<DesignerDesc> findAllDesignerDescs(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByProfileContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByProfileContaining(String profile) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByProfileContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByProfileContaining(String profile, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByDescriptionContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByDescriptionContaining(String description) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByDescriptionContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByDescriptionContaining(String description, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByDescription
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByDescription(String description_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByDescription
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByDescription(String description_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaDesc
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaDesc(String metaDesc) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaDesc
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaDesc(String metaDesc, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByLangId
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByLangId(Integer langId_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByLangId
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByLangId(Integer langId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByImageLocation
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByImageLocation(String imageLocation_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByImageLocation
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByImageLocation(String imageLocation_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByUrl
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByUrl(String url_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByUrl
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByUrl(String url_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByNameContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByNameContaining(String name) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByNameContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByNameContaining(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaKeywords
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaKeywords(String metaKeywords) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaKeywords
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaKeywords(String metaKeywords, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByProfile
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByProfile(String profile_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByProfile
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByProfile(String profile_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByName
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByName(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByName
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByName(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByDesignerId
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByDesignerId(Integer designerId_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByDesignerId
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByDesignerId(Integer designerId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitle
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitle(String metaTagsTitle_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaTagsTitle
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaTagsTitle(String metaTagsTitle_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaDescContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaDescContaining(String metaDesc_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaDescContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaDescContaining(String metaDesc_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaKeywordsContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaKeywordsContaining(String metaKeywords_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerDescByMetaKeywordsContaining
	 *
	 */
	public Set<DesignerDesc> findDesignerDescByMetaKeywordsContaining(String metaKeywords_1, int startResult, int maxRows) throws DataAccessException;

}
package com.ecom.dao;

import com.ecom.domain.Category;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Category entities.
 * 
 */
@Repository("CategoryDAO")
@Transactional
public class CategoryDAOImpl extends AbstractJpaDao<Category> implements
		CategoryDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Category.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new CategoryDAOImpl
	 *
	 */
	public CategoryDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findCategoryByDateModified
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findCategoryByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findCategoryByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */
	@Transactional
	public Category findCategoryByCategoryId(Integer categoryId) throws DataAccessException {

		return findCategoryByCategoryId(categoryId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */

	@Transactional
	public Category findCategoryByCategoryId(Integer categoryId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findCategoryByCategoryId", startResult, maxRows, categoryId);
			return (com.ecom.domain.Category) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findCategoryByDateAdded
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findCategoryByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByStatusId
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByStatusId(Integer statusId) throws DataAccessException {

		return findCategoryByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findCategoryByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */
	@Transactional
	public Category findCategoryByPrimaryKey(Integer categoryId) throws DataAccessException {

		return findCategoryByPrimaryKey(categoryId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */

	@Transactional
	public Category findCategoryByPrimaryKey(Integer categoryId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findCategoryByPrimaryKey", startResult, maxRows, categoryId);
			return (com.ecom.domain.Category) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findCategoryByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findCategoryByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findCategoryByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryBySortOrder
	 *
	 */
	@Transactional
	public Set<Category> findCategoryBySortOrder(Integer sortOrder) throws DataAccessException {

		return findCategoryBySortOrder(sortOrder, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryBySortOrder
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryBySortOrder", startResult, maxRows, sortOrder);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */
	@Transactional
	public Set<Category> findAllCategorys() throws DataAccessException {

		return findAllCategorys(-1, -1);
	}

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findAllCategorys(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllCategorys", startResult, maxRows);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByStoreId
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByStoreId(Integer storeId) throws DataAccessException {

		return findCategoryByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Category entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.Designer;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Designer entities.
 * 
 */
public interface DesignerDAO extends JpaDao<Designer> {

	/**
	 * JPQL Query - findDesignerByDateModifiedAfter
	 *
	 */
	public Set<Designer> findDesignerByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateModifiedAfter
	 *
	 */
	public Set<Designer> findDesignerByDateModifiedAfter(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateModified
	 *
	 */
	public Set<Designer> findDesignerByDateModified(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateModified
	 *
	 */
	public Set<Designer> findDesignerByDateModified(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateAddedAfter
	 *
	 */
	public Set<Designer> findDesignerByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateAddedAfter
	 *
	 */
	public Set<Designer> findDesignerByDateAddedAfter(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByStoreId
	 *
	 */
	public Set<Designer> findDesignerByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByStoreId
	 *
	 */
	public Set<Designer> findDesignerByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByPrimaryKey
	 *
	 */
	public Designer findDesignerByPrimaryKey(Integer designerId) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByPrimaryKey
	 *
	 */
	public Designer findDesignerByPrimaryKey(Integer designerId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllDesigners
	 *
	 */
	public Set<Designer> findAllDesigners() throws DataAccessException;

	/**
	 * JPQL Query - findAllDesigners
	 *
	 */
	public Set<Designer> findAllDesigners(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateAdded
	 *
	 */
	public Set<Designer> findDesignerByDateAdded(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateAdded
	 *
	 */
	public Set<Designer> findDesignerByDateAdded(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateModifiedBefore
	 *
	 */
	public Set<Designer> findDesignerByDateModifiedBefore(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateModifiedBefore
	 *
	 */
	public Set<Designer> findDesignerByDateModifiedBefore(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerBySortOrder
	 *
	 */
	public Set<Designer> findDesignerBySortOrder(Integer sortOrder) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerBySortOrder
	 *
	 */
	public Set<Designer> findDesignerBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByStatusId
	 *
	 */
	public Set<Designer> findDesignerByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByStatusId
	 *
	 */
	public Set<Designer> findDesignerByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDesignerId
	 *
	 */
	public Designer findDesignerByDesignerId(Integer designerId_1) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDesignerId
	 *
	 */
	public Designer findDesignerByDesignerId(Integer designerId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateAddedBefore
	 *
	 */
	public Set<Designer> findDesignerByDateAddedBefore(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findDesignerByDateAddedBefore
	 *
	 */
	public Set<Designer> findDesignerByDateAddedBefore(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

}
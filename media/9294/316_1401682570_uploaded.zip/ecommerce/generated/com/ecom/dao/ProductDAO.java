package com.ecom.dao;

import com.ecom.domain.Product;

import java.math.BigDecimal;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Product entities.
 * 
 */
public interface ProductDAO extends JpaDao<Product> {

	/**
	 * JPQL Query - findProductByMargin
	 *
	 */
	public Set<Product> findProductByMargin(java.math.BigDecimal margin) throws DataAccessException;

	/**
	 * JPQL Query - findProductByMargin
	 *
	 */
	public Set<Product> findProductByMargin(BigDecimal margin, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateAdded
	 *
	 */
	public Set<Product> findProductByDateAdded(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateAdded
	 *
	 */
	public Set<Product> findProductByDateAdded(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDuty
	 *
	 */
	public Set<Product> findProductByDuty(java.math.BigDecimal duty) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDuty
	 *
	 */
	public Set<Product> findProductByDuty(BigDecimal duty, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByInternalNameContaining
	 *
	 */
	public Set<Product> findProductByInternalNameContaining(String internalName) throws DataAccessException;

	/**
	 * JPQL Query - findProductByInternalNameContaining
	 *
	 */
	public Set<Product> findProductByInternalNameContaining(String internalName, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByMasterCatId
	 *
	 */
	public Set<Product> findProductByMasterCatId(Integer masterCatId) throws DataAccessException;

	/**
	 * JPQL Query - findProductByMasterCatId
	 *
	 */
	public Set<Product> findProductByMasterCatId(Integer masterCatId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateAddedBefore
	 *
	 */
	public Set<Product> findProductByDateAddedBefore(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateAddedBefore
	 *
	 */
	public Set<Product> findProductByDateAddedBefore(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByProductCost
	 *
	 */
	public Set<Product> findProductByProductCost(java.math.BigDecimal productCost) throws DataAccessException;

	/**
	 * JPQL Query - findProductByProductCost
	 *
	 */
	public Set<Product> findProductByProductCost(BigDecimal productCost, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllProducts
	 *
	 */
	public Set<Product> findAllProducts() throws DataAccessException;

	/**
	 * JPQL Query - findAllProducts
	 *
	 */
	public Set<Product> findAllProducts(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateModifiedBefore
	 *
	 */
	public Set<Product> findProductByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateModifiedBefore
	 *
	 */
	public Set<Product> findProductByDateModifiedBefore(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByOrdered
	 *
	 */
	public Set<Product> findProductByOrdered(Integer ordered) throws DataAccessException;

	/**
	 * JPQL Query - findProductByOrdered
	 *
	 */
	public Set<Product> findProductByOrdered(Integer ordered, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByComputedPrice
	 *
	 */
	public Set<Product> findProductByComputedPrice(java.math.BigDecimal computedPrice) throws DataAccessException;

	/**
	 * JPQL Query - findProductByComputedPrice
	 *
	 */
	public Set<Product> findProductByComputedPrice(BigDecimal computedPrice, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateModified
	 *
	 */
	public Set<Product> findProductByDateModified(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateModified
	 *
	 */
	public Set<Product> findProductByDateModified(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByProdId
	 *
	 */
	public Product findProductByProdId(Integer prodId) throws DataAccessException;

	/**
	 * JPQL Query - findProductByProdId
	 *
	 */
	public Product findProductByProdId(Integer prodId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByEnteredPrice
	 *
	 */
	public Set<Product> findProductByEnteredPrice(java.math.BigDecimal enteredPrice) throws DataAccessException;

	/**
	 * JPQL Query - findProductByEnteredPrice
	 *
	 */
	public Set<Product> findProductByEnteredPrice(BigDecimal enteredPrice, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByInternalName
	 *
	 */
	public Set<Product> findProductByInternalName(String internalName_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductByInternalName
	 *
	 */
	public Set<Product> findProductByInternalName(String internalName_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByUseEnteredPrice
	 *
	 */
	public Set<Product> findProductByUseEnteredPrice(Boolean useEnteredPrice) throws DataAccessException;

	/**
	 * JPQL Query - findProductByUseEnteredPrice
	 *
	 */
	public Set<Product> findProductByUseEnteredPrice(Boolean useEnteredPrice, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateAddedAfter
	 *
	 */
	public Set<Product> findProductByDateAddedAfter(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateAddedAfter
	 *
	 */
	public Set<Product> findProductByDateAddedAfter(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByOrderUnits
	 *
	 */
	public Set<Product> findProductByOrderUnits(Integer orderUnits) throws DataAccessException;

	/**
	 * JPQL Query - findProductByOrderUnits
	 *
	 */
	public Set<Product> findProductByOrderUnits(Integer orderUnits, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateModifiedAfter
	 *
	 */
	public Set<Product> findProductByDateModifiedAfter(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDateModifiedAfter
	 *
	 */
	public Set<Product> findProductByDateModifiedAfter(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByPrimaryKey
	 *
	 */
	public Product findProductByPrimaryKey(Integer prodId_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductByPrimaryKey
	 *
	 */
	public Product findProductByPrimaryKey(Integer prodId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByCustom
	 *
	 */
	public Set<Product> findProductByCustom(java.math.BigDecimal custom) throws DataAccessException;

	/**
	 * JPQL Query - findProductByCustom
	 *
	 */
	public Set<Product> findProductByCustom(BigDecimal custom, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductBySortOrder
	 *
	 */
	public Set<Product> findProductBySortOrder(Integer sortOrder) throws DataAccessException;

	/**
	 * JPQL Query - findProductBySortOrder
	 *
	 */
	public Set<Product> findProductBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByStatusId
	 *
	 */
	public Set<Product> findProductByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findProductByStatusId
	 *
	 */
	public Set<Product> findProductByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByTaxClassId
	 *
	 */
	public Set<Product> findProductByTaxClassId(Integer taxClassId) throws DataAccessException;

	/**
	 * JPQL Query - findProductByTaxClassId
	 *
	 */
	public Set<Product> findProductByTaxClassId(Integer taxClassId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDesignerId
	 *
	 */
	public Set<Product> findProductByDesignerId(Integer designerId) throws DataAccessException;

	/**
	 * JPQL Query - findProductByDesignerId
	 *
	 */
	public Set<Product> findProductByDesignerId(Integer designerId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductByStoreId
	 *
	 */
	public Set<Product> findProductByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findProductByStoreId
	 *
	 */
	public Set<Product> findProductByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

}
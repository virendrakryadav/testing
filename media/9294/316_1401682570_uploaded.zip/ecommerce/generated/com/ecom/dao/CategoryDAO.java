package com.ecom.dao;

import com.ecom.domain.Category;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Category entities.
 * 
 */
public interface CategoryDAO extends JpaDao<Category> {

	/**
	 * JPQL Query - findCategoryByDateModified
	 *
	 */
	public Set<Category> findCategoryByDateModified(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateModified
	 *
	 */
	public Set<Category> findCategoryByDateModified(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateModifiedBefore
	 *
	 */
	public Set<Category> findCategoryByDateModifiedBefore(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateModifiedBefore
	 *
	 */
	public Set<Category> findCategoryByDateModifiedBefore(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */
	public Category findCategoryByCategoryId(Integer categoryId) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */
	public Category findCategoryByCategoryId(Integer categoryId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateAdded
	 *
	 */
	public Set<Category> findCategoryByDateAdded(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateAdded
	 *
	 */
	public Set<Category> findCategoryByDateAdded(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByStatusId
	 *
	 */
	public Set<Category> findCategoryByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByStatusId
	 *
	 */
	public Set<Category> findCategoryByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateAddedBefore
	 *
	 */
	public Set<Category> findCategoryByDateAddedBefore(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateAddedBefore
	 *
	 */
	public Set<Category> findCategoryByDateAddedBefore(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */
	public Category findCategoryByPrimaryKey(Integer categoryId_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */
	public Category findCategoryByPrimaryKey(Integer categoryId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateAddedAfter
	 *
	 */
	public Set<Category> findCategoryByDateAddedAfter(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateAddedAfter
	 *
	 */
	public Set<Category> findCategoryByDateAddedAfter(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateModifiedAfter
	 *
	 */
	public Set<Category> findCategoryByDateModifiedAfter(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByDateModifiedAfter
	 *
	 */
	public Set<Category> findCategoryByDateModifiedAfter(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryBySortOrder
	 *
	 */
	public Set<Category> findCategoryBySortOrder(Integer sortOrder) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryBySortOrder
	 *
	 */
	public Set<Category> findCategoryBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */
	public Set<Category> findAllCategorys() throws DataAccessException;

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */
	public Set<Category> findAllCategorys(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByStoreId
	 *
	 */
	public Set<Category> findCategoryByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByStoreId
	 *
	 */
	public Set<Category> findCategoryByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

}
package com.ecom.dao;

import com.ecom.domain.ProductCustomFieldVal;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage ProductCustomFieldVal entities.
 * 
 */
public interface ProductCustomFieldValDAO extends JpaDao<ProductCustomFieldVal> {

	/**
	 * JPQL Query - findAllProductCustomFieldVals
	 *
	 */
	public Set<ProductCustomFieldVal> findAllProductCustomFieldVals() throws DataAccessException;

	/**
	 * JPQL Query - findAllProductCustomFieldVals
	 *
	 */
	public Set<ProductCustomFieldVal> findAllProductCustomFieldVals(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductCustomFieldValByPrimaryKey
	 *
	 */
	public ProductCustomFieldVal findProductCustomFieldValByPrimaryKey(Integer prodId, Integer langId, Integer customFieldId) throws DataAccessException;

	/**
	 * JPQL Query - findProductCustomFieldValByPrimaryKey
	 *
	 */
	public ProductCustomFieldVal findProductCustomFieldValByPrimaryKey(Integer prodId, Integer langId, Integer customFieldId, int startResult, int maxRows) throws DataAccessException;

}
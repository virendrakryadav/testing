package com.ecom.dao;

import com.ecom.domain.ProductCustomField;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage ProductCustomField entities.
 * 
 */
@Repository("ProductCustomFieldDAO")
@Transactional
public class ProductCustomFieldDAOImpl extends AbstractJpaDao<ProductCustomField>
		implements ProductCustomFieldDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { ProductCustomField.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new ProductCustomFieldDAOImpl
	 *
	 */
	public ProductCustomFieldDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findProductCustomFieldByPrimaryKey
	 *
	 */
	@Transactional
	public ProductCustomField findProductCustomFieldByPrimaryKey(Integer prodId, Integer customFieldId) throws DataAccessException {

		return findProductCustomFieldByPrimaryKey(prodId, customFieldId, -1, -1);
	}

	/**
	 * JPQL Query - findProductCustomFieldByPrimaryKey
	 *
	 */

	@Transactional
	public ProductCustomField findProductCustomFieldByPrimaryKey(Integer prodId, Integer customFieldId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findProductCustomFieldByPrimaryKey", startResult, maxRows, prodId, customFieldId);
			return (com.ecom.domain.ProductCustomField) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllProductCustomFields
	 *
	 */
	@Transactional
	public Set<ProductCustomField> findAllProductCustomFields() throws DataAccessException {

		return findAllProductCustomFields(-1, -1);
	}

	/**
	 * JPQL Query - findAllProductCustomFields
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductCustomField> findAllProductCustomFields(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllProductCustomFields", startResult, maxRows);
		return new LinkedHashSet<ProductCustomField>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(ProductCustomField entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.StoreDesc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage StoreDesc entities.
 * 
 */
@Repository("StoreDescDAO")
@Transactional
public class StoreDescDAOImpl extends AbstractJpaDao<StoreDesc> implements
		StoreDescDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { StoreDesc.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new StoreDescDAOImpl
	 *
	 */
	public StoreDescDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findStoreDescByCssFilename
	 *
	 */
	@Transactional
	public Set<StoreDesc> findStoreDescByCssFilename(String cssFilename) throws DataAccessException {

		return findStoreDescByCssFilename(cssFilename, -1, -1);
	}

	/**
	 * JPQL Query - findStoreDescByCssFilename
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<StoreDesc> findStoreDescByCssFilename(String cssFilename, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findStoreDescByCssFilename", startResult, maxRows, cssFilename);
		return new LinkedHashSet<StoreDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllStoreDescs
	 *
	 */
	@Transactional
	public Set<StoreDesc> findAllStoreDescs() throws DataAccessException {

		return findAllStoreDescs(-1, -1);
	}

	/**
	 * JPQL Query - findAllStoreDescs
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<StoreDesc> findAllStoreDescs(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllStoreDescs", startResult, maxRows);
		return new LinkedHashSet<StoreDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findStoreDescByLangId
	 *
	 */
	@Transactional
	public Set<StoreDesc> findStoreDescByLangId(Integer langId) throws DataAccessException {

		return findStoreDescByLangId(langId, -1, -1);
	}

	/**
	 * JPQL Query - findStoreDescByLangId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<StoreDesc> findStoreDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findStoreDescByLangId", startResult, maxRows, langId);
		return new LinkedHashSet<StoreDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findStoreDescByLogoFilenameContaining
	 *
	 */
	@Transactional
	public Set<StoreDesc> findStoreDescByLogoFilenameContaining(String logoFilename) throws DataAccessException {

		return findStoreDescByLogoFilenameContaining(logoFilename, -1, -1);
	}

	/**
	 * JPQL Query - findStoreDescByLogoFilenameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<StoreDesc> findStoreDescByLogoFilenameContaining(String logoFilename, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findStoreDescByLogoFilenameContaining", startResult, maxRows, logoFilename);
		return new LinkedHashSet<StoreDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findStoreDescByCssFilenameContaining
	 *
	 */
	@Transactional
	public Set<StoreDesc> findStoreDescByCssFilenameContaining(String cssFilename) throws DataAccessException {

		return findStoreDescByCssFilenameContaining(cssFilename, -1, -1);
	}

	/**
	 * JPQL Query - findStoreDescByCssFilenameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<StoreDesc> findStoreDescByCssFilenameContaining(String cssFilename, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findStoreDescByCssFilenameContaining", startResult, maxRows, cssFilename);
		return new LinkedHashSet<StoreDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findStoreDescByPrimaryKey
	 *
	 */
	@Transactional
	public StoreDesc findStoreDescByPrimaryKey(Integer storeId, Integer langId) throws DataAccessException {

		return findStoreDescByPrimaryKey(storeId, langId, -1, -1);
	}

	/**
	 * JPQL Query - findStoreDescByPrimaryKey
	 *
	 */

	@Transactional
	public StoreDesc findStoreDescByPrimaryKey(Integer storeId, Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findStoreDescByPrimaryKey", startResult, maxRows, storeId, langId);
			return (com.ecom.domain.StoreDesc) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findStoreDescByStoreId
	 *
	 */
	@Transactional
	public Set<StoreDesc> findStoreDescByStoreId(Integer storeId) throws DataAccessException {

		return findStoreDescByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findStoreDescByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<StoreDesc> findStoreDescByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findStoreDescByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<StoreDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findStoreDescByLogoFilename
	 *
	 */
	@Transactional
	public Set<StoreDesc> findStoreDescByLogoFilename(String logoFilename) throws DataAccessException {

		return findStoreDescByLogoFilename(logoFilename, -1, -1);
	}

	/**
	 * JPQL Query - findStoreDescByLogoFilename
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<StoreDesc> findStoreDescByLogoFilename(String logoFilename, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findStoreDescByLogoFilename", startResult, maxRows, logoFilename);
		return new LinkedHashSet<StoreDesc>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(StoreDesc entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.ProductMedia;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage ProductMedia entities.
 * 
 */
public interface ProductMediaDAO extends JpaDao<ProductMedia> {

	/**
	 * JPQL Query - findAllProductMedias
	 *
	 */
	public Set<ProductMedia> findAllProductMedias() throws DataAccessException;

	/**
	 * JPQL Query - findAllProductMedias
	 *
	 */
	public Set<ProductMedia> findAllProductMedias(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductMediaByPrimaryKey
	 *
	 */
	public ProductMedia findProductMediaByPrimaryKey(Integer prodId, Integer langId, Integer mediaId) throws DataAccessException;

	/**
	 * JPQL Query - findProductMediaByPrimaryKey
	 *
	 */
	public ProductMedia findProductMediaByPrimaryKey(Integer prodId, Integer langId, Integer mediaId, int startResult, int maxRows) throws DataAccessException;

}
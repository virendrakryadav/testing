package com.ecom.dao;

import com.ecom.domain.FeatureRole;

import java.util.Calendar;
import java.util.Set;
import org.skyway.spring.util.dao.JpaDao;
import org.springframework.dao.DataAccessException;

/**
 * DAO to manage FeatureRole entities.
 * 
 */
public interface FeatureRoleDAO extends JpaDao<FeatureRole> {

	/**
	 * JPQL Query - findFeatureRoleByPrimaryKey
	 *
	 */
	public FeatureRole findFeatureRoleByPrimaryKey(Integer featureId, Integer roleId) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByPrimaryKey
	 *
	 */
	public FeatureRole findFeatureRoleByPrimaryKey(Integer featureId, Integer roleId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByFeatureId
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByFeatureId(Integer featureId_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByFeatureId
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByFeatureId(Integer featureId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateAddedAfter
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateAddedAfter
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateAddedAfter(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedAfter
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedAfter
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateModifiedAfter(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateAddedBefore
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateAddedBefore(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateAddedBefore
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateAddedBefore(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByRoleId
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByRoleId(Integer roleId_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByRoleId
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByRoleId(Integer roleId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateAdded
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateAdded(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateAdded
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateAdded(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllFeatureRoles
	 *
	 */
	public Set<FeatureRole> findAllFeatureRoles() throws DataAccessException;

	/**
	 * JPQL Query - findAllFeatureRoles
	 *
	 */
	public Set<FeatureRole> findAllFeatureRoles(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateModified
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateModified(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateModified
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateModified(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedBefore
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateModifiedBefore(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedBefore
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByDateModifiedBefore(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByStatusId
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureRoleByStatusId
	 *
	 */
	public Set<FeatureRole> findFeatureRoleByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

}
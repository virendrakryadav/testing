package com.ecom.dao;

import com.ecom.domain.KeywordDesc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;
import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage KeywordDesc entities.
 * 
 */
@Repository("KeywordDescDAO")
@Transactional
public class KeywordDescDAOImpl extends AbstractJpaDao<KeywordDesc> implements
		KeywordDescDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { KeywordDesc.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new KeywordDescDAOImpl
	 *
	 */
	public KeywordDescDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findKeywordDescByPrimaryKey
	 *
	 */
	@Transactional
	public KeywordDesc findKeywordDescByPrimaryKey(Integer keywordId, Integer langId) throws DataAccessException {

		return findKeywordDescByPrimaryKey(keywordId, langId, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordDescByPrimaryKey
	 *
	 */

	@Transactional
	public KeywordDesc findKeywordDescByPrimaryKey(Integer keywordId, Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findKeywordDescByPrimaryKey", startResult, maxRows, keywordId, langId);
			return (com.ecom.domain.KeywordDesc) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllKeywordDescs
	 *
	 */
	@Transactional
	public Set<KeywordDesc> findAllKeywordDescs() throws DataAccessException {

		return findAllKeywordDescs(-1, -1);
	}

	/**
	 * JPQL Query - findAllKeywordDescs
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<KeywordDesc> findAllKeywordDescs(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllKeywordDescs", startResult, maxRows);
		return new LinkedHashSet<KeywordDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordDescByKeywordId
	 *
	 */
	@Transactional
	public Set<KeywordDesc> findKeywordDescByKeywordId(Integer keywordId) throws DataAccessException {

		return findKeywordDescByKeywordId(keywordId, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordDescByKeywordId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<KeywordDesc> findKeywordDescByKeywordId(Integer keywordId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordDescByKeywordId", startResult, maxRows, keywordId);
		return new LinkedHashSet<KeywordDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordDescByLangId
	 *
	 */
	@Transactional
	public Set<KeywordDesc> findKeywordDescByLangId(Integer langId) throws DataAccessException {

		return findKeywordDescByLangId(langId, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordDescByLangId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<KeywordDesc> findKeywordDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordDescByLangId", startResult, maxRows, langId);
		return new LinkedHashSet<KeywordDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordDescByDescription
	 *
	 */
	@Transactional
	public Set<KeywordDesc> findKeywordDescByDescription(String description) throws DataAccessException {

		return findKeywordDescByDescription(description, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordDescByDescription
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<KeywordDesc> findKeywordDescByDescription(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordDescByDescription", startResult, maxRows, description);
		return new LinkedHashSet<KeywordDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordDescByDescriptionContaining
	 *
	 */
	@Transactional
	public Set<KeywordDesc> findKeywordDescByDescriptionContaining(String description) throws DataAccessException {

		return findKeywordDescByDescriptionContaining(description, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordDescByDescriptionContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<KeywordDesc> findKeywordDescByDescriptionContaining(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordDescByDescriptionContaining", startResult, maxRows, description);
		return new LinkedHashSet<KeywordDesc>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(KeywordDesc entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.Role;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Role entities.
 * 
 */
@Repository("RoleDAO")
@Transactional
public class RoleDAOImpl extends AbstractJpaDao<Role> implements RoleDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Role.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new RoleDAOImpl
	 *
	 */
	public RoleDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findRoleByStoreId
	 *
	 */
	@Transactional
	public Set<Role> findRoleByStoreId(Integer storeId) throws DataAccessException {

		return findRoleByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByRoleId
	 *
	 */
	@Transactional
	public Role findRoleByRoleId(Integer roleId) throws DataAccessException {

		return findRoleByRoleId(roleId, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByRoleId
	 *
	 */

	@Transactional
	public Role findRoleByRoleId(Integer roleId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findRoleByRoleId", startResult, maxRows, roleId);
			return (com.ecom.domain.Role) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllRoles
	 *
	 */
	@Transactional
	public Set<Role> findAllRoles() throws DataAccessException {

		return findAllRoles(-1, -1);
	}

	/**
	 * JPQL Query - findAllRoles
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findAllRoles(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllRoles", startResult, maxRows);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<Role> findRoleByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findRoleByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<Role> findRoleByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findRoleByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByPrimaryKey
	 *
	 */
	@Transactional
	public Role findRoleByPrimaryKey(Integer roleId) throws DataAccessException {

		return findRoleByPrimaryKey(roleId, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByPrimaryKey
	 *
	 */

	@Transactional
	public Role findRoleByPrimaryKey(Integer roleId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findRoleByPrimaryKey", startResult, maxRows, roleId);
			return (com.ecom.domain.Role) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findRoleByStatusId
	 *
	 */
	@Transactional
	public Set<Role> findRoleByStatusId(Integer statusId) throws DataAccessException {

		return findRoleByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<Role> findRoleByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findRoleByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByDateAdded
	 *
	 */
	@Transactional
	public Set<Role> findRoleByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findRoleByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByDateModified
	 *
	 */
	@Transactional
	public Set<Role> findRoleByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findRoleByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<Role> findRoleByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findRoleByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findRoleByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Role> findRoleByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRoleByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<Role>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Role entity) {
		return true;
	}
}

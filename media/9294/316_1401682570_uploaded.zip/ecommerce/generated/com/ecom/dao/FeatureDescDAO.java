package com.ecom.dao;

import com.ecom.domain.FeatureDesc;

import java.util.Set;
import org.skyway.spring.util.dao.JpaDao;
import org.springframework.dao.DataAccessException;

/**
 * DAO to manage FeatureDesc entities.
 * 
 */
public interface FeatureDescDAO extends JpaDao<FeatureDesc> {

	/**
	 * JPQL Query - findAllFeatureDescs
	 *
	 */
	public Set<FeatureDesc> findAllFeatureDescs() throws DataAccessException;

	/**
	 * JPQL Query - findAllFeatureDescs
	 *
	 */
	public Set<FeatureDesc> findAllFeatureDescs(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureDescByPrimaryKey
	 *
	 */
	public FeatureDesc findFeatureDescByPrimaryKey(Integer featureId, Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureDescByPrimaryKey
	 *
	 */
	public FeatureDesc findFeatureDescByPrimaryKey(Integer featureId, Integer langId, int startResult, int maxRows) throws DataAccessException;

}
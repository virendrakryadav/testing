package com.ecom.dao;

import com.ecom.domain.ProductDesc;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage ProductDesc entities.
 * 
 */
public interface ProductDescDAO extends JpaDao<ProductDesc> {

	/**
	 * JPQL Query - findProductDescByStoreId
	 *
	 */
	public Set<ProductDesc> findProductDescByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByStoreId
	 *
	 */
	public Set<ProductDesc> findProductDescByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByLangId
	 *
	 */
	public Set<ProductDesc> findProductDescByLangId(Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByLangId
	 *
	 */
	public Set<ProductDesc> findProductDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByDescription
	 *
	 */
	public Set<ProductDesc> findProductDescByDescription(String description) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByDescription
	 *
	 */
	public Set<ProductDesc> findProductDescByDescription(String description, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByPrimaryKey
	 *
	 */
	public ProductDesc findProductDescByPrimaryKey(Integer prodId, Integer langId_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByPrimaryKey
	 *
	 */
	public ProductDesc findProductDescByPrimaryKey(Integer prodId, Integer langId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByProdId
	 *
	 */
	public Set<ProductDesc> findProductDescByProdId(Integer prodId_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByProdId
	 *
	 */
	public Set<ProductDesc> findProductDescByProdId(Integer prodId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByPublicNameContaining
	 *
	 */
	public Set<ProductDesc> findProductDescByPublicNameContaining(String publicName) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByPublicNameContaining
	 *
	 */
	public Set<ProductDesc> findProductDescByPublicNameContaining(String publicName, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllProductDescs
	 *
	 */
	public Set<ProductDesc> findAllProductDescs() throws DataAccessException;

	/**
	 * JPQL Query - findAllProductDescs
	 *
	 */
	public Set<ProductDesc> findAllProductDescs(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByPublicName
	 *
	 */
	public Set<ProductDesc> findProductDescByPublicName(String publicName_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByPublicName
	 *
	 */
	public Set<ProductDesc> findProductDescByPublicName(String publicName_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescBySummaryContaining
	 *
	 */
	public Set<ProductDesc> findProductDescBySummaryContaining(String summary) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescBySummaryContaining
	 *
	 */
	public Set<ProductDesc> findProductDescBySummaryContaining(String summary, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescBySummary
	 *
	 */
	public Set<ProductDesc> findProductDescBySummary(String summary_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescBySummary
	 *
	 */
	public Set<ProductDesc> findProductDescBySummary(String summary_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByDescriptionContaining
	 *
	 */
	public Set<ProductDesc> findProductDescByDescriptionContaining(String description_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByDescriptionContaining
	 *
	 */
	public Set<ProductDesc> findProductDescByDescriptionContaining(String description_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByUrl
	 *
	 */
	public Set<ProductDesc> findProductDescByUrl(String url) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByUrl
	 *
	 */
	public Set<ProductDesc> findProductDescByUrl(String url, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByUrlContaining
	 *
	 */
	public Set<ProductDesc> findProductDescByUrlContaining(String url_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductDescByUrlContaining
	 *
	 */
	public Set<ProductDesc> findProductDescByUrlContaining(String url_1, int startResult, int maxRows) throws DataAccessException;

}
package com.ecom.dao;

import com.ecom.domain.RoleDesc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;
import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage RoleDesc entities.
 * 
 */
@Repository("RoleDescDAO")
@Transactional
public class RoleDescDAOImpl extends AbstractJpaDao<RoleDesc> implements
		RoleDescDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { RoleDesc.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new RoleDescDAOImpl
	 *
	 */
	public RoleDescDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAllRoleDescs
	 *
	 */
	@Transactional
	public Set<RoleDesc> findAllRoleDescs() throws DataAccessException {

		return findAllRoleDescs(-1, -1);
	}

	/**
	 * JPQL Query - findAllRoleDescs
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<RoleDesc> findAllRoleDescs(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllRoleDescs", startResult, maxRows);
		return new LinkedHashSet<RoleDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findRoleDescByPrimaryKey
	 *
	 */
	@Transactional
	public RoleDesc findRoleDescByPrimaryKey(Integer roleId, Integer langId) throws DataAccessException {

		return findRoleDescByPrimaryKey(roleId, langId, -1, -1);
	}

	/**
	 * JPQL Query - findRoleDescByPrimaryKey
	 *
	 */

	@Transactional
	public RoleDesc findRoleDescByPrimaryKey(Integer roleId, Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findRoleDescByPrimaryKey", startResult, maxRows, roleId, langId);
			return (com.ecom.domain.RoleDesc) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(RoleDesc entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.Keyword;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Keyword entities.
 * 
 */
public interface KeywordDAO extends JpaDao<Keyword> {

	/**
	 * JPQL Query - findAllKeywords
	 *
	 */
	public Set<Keyword> findAllKeywords() throws DataAccessException;

	/**
	 * JPQL Query - findAllKeywords
	 *
	 */
	public Set<Keyword> findAllKeywords(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateAddedBefore
	 *
	 */
	public Set<Keyword> findKeywordByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateAddedBefore
	 *
	 */
	public Set<Keyword> findKeywordByDateAddedBefore(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByKeywordId
	 *
	 */
	public Keyword findKeywordByKeywordId(Integer keywordId) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByKeywordId
	 *
	 */
	public Keyword findKeywordByKeywordId(Integer keywordId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateModifiedAfter
	 *
	 */
	public Set<Keyword> findKeywordByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateModifiedAfter
	 *
	 */
	public Set<Keyword> findKeywordByDateModifiedAfter(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByStatusId
	 *
	 */
	public Set<Keyword> findKeywordByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByStatusId
	 *
	 */
	public Set<Keyword> findKeywordByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateAdded
	 *
	 */
	public Set<Keyword> findKeywordByDateAdded(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateAdded
	 *
	 */
	public Set<Keyword> findKeywordByDateAdded(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByPrimaryKey
	 *
	 */
	public Keyword findKeywordByPrimaryKey(Integer keywordId_1) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByPrimaryKey
	 *
	 */
	public Keyword findKeywordByPrimaryKey(Integer keywordId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateModifiedBefore
	 *
	 */
	public Set<Keyword> findKeywordByDateModifiedBefore(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateModifiedBefore
	 *
	 */
	public Set<Keyword> findKeywordByDateModifiedBefore(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateModified
	 *
	 */
	public Set<Keyword> findKeywordByDateModified(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateModified
	 *
	 */
	public Set<Keyword> findKeywordByDateModified(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByStoreId
	 *
	 */
	public Set<Keyword> findKeywordByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByStoreId
	 *
	 */
	public Set<Keyword> findKeywordByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateAddedAfter
	 *
	 */
	public Set<Keyword> findKeywordByDateAddedAfter(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordByDateAddedAfter
	 *
	 */
	public Set<Keyword> findKeywordByDateAddedAfter(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

}
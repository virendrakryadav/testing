package com.ecom.dao;

import com.ecom.domain.Designer;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Designer entities.
 * 
 */
@Repository("DesignerDAO")
@Transactional
public class DesignerDAOImpl extends AbstractJpaDao<Designer> implements
		DesignerDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Designer.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new DesignerDAOImpl
	 *
	 */
	public DesignerDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findDesignerByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findDesignerByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByDateModified
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findDesignerByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findDesignerByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByStoreId
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByStoreId(Integer storeId) throws DataAccessException {

		return findDesignerByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByPrimaryKey
	 *
	 */
	@Transactional
	public Designer findDesignerByPrimaryKey(Integer designerId) throws DataAccessException {

		return findDesignerByPrimaryKey(designerId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByPrimaryKey
	 *
	 */

	@Transactional
	public Designer findDesignerByPrimaryKey(Integer designerId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findDesignerByPrimaryKey", startResult, maxRows, designerId);
			return (com.ecom.domain.Designer) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllDesigners
	 *
	 */
	@Transactional
	public Set<Designer> findAllDesigners() throws DataAccessException {

		return findAllDesigners(-1, -1);
	}

	/**
	 * JPQL Query - findAllDesigners
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findAllDesigners(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllDesigners", startResult, maxRows);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByDateAdded
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findDesignerByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findDesignerByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerBySortOrder
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerBySortOrder(Integer sortOrder) throws DataAccessException {

		return findDesignerBySortOrder(sortOrder, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerBySortOrder
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerBySortOrder", startResult, maxRows, sortOrder);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByStatusId
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByStatusId(Integer statusId) throws DataAccessException {

		return findDesignerByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * JPQL Query - findDesignerByDesignerId
	 *
	 */
	@Transactional
	public Designer findDesignerByDesignerId(Integer designerId) throws DataAccessException {

		return findDesignerByDesignerId(designerId, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByDesignerId
	 *
	 */

	@Transactional
	public Designer findDesignerByDesignerId(Integer designerId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findDesignerByDesignerId", startResult, maxRows, designerId);
			return (com.ecom.domain.Designer) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findDesignerByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<Designer> findDesignerByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findDesignerByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findDesignerByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Designer> findDesignerByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findDesignerByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Designer>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Designer entity) {
		return true;
	}
}

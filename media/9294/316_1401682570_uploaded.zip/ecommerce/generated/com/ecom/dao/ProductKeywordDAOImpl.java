package com.ecom.dao;

import com.ecom.domain.ProductKeyword;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage ProductKeyword entities.
 * 
 */
@Repository("ProductKeywordDAO")
@Transactional
public class ProductKeywordDAOImpl extends AbstractJpaDao<ProductKeyword>
		implements ProductKeywordDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { ProductKeyword.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new ProductKeywordDAOImpl
	 *
	 */
	public ProductKeywordDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findProductKeywordByPrimaryKey
	 *
	 */
	@Transactional
	public ProductKeyword findProductKeywordByPrimaryKey(Integer prodId, Integer keywordId) throws DataAccessException {

		return findProductKeywordByPrimaryKey(prodId, keywordId, -1, -1);
	}

	/**
	 * JPQL Query - findProductKeywordByPrimaryKey
	 *
	 */

	@Transactional
	public ProductKeyword findProductKeywordByPrimaryKey(Integer prodId, Integer keywordId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findProductKeywordByPrimaryKey", startResult, maxRows, prodId, keywordId);
			return (com.ecom.domain.ProductKeyword) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findProductKeywordByProdId
	 *
	 */
	@Transactional
	public Set<ProductKeyword> findProductKeywordByProdId(Integer prodId) throws DataAccessException {

		return findProductKeywordByProdId(prodId, -1, -1);
	}

	/**
	 * JPQL Query - findProductKeywordByProdId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductKeyword> findProductKeywordByProdId(Integer prodId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductKeywordByProdId", startResult, maxRows, prodId);
		return new LinkedHashSet<ProductKeyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductKeywordByKeywordId
	 *
	 */
	@Transactional
	public Set<ProductKeyword> findProductKeywordByKeywordId(Integer keywordId) throws DataAccessException {

		return findProductKeywordByKeywordId(keywordId, -1, -1);
	}

	/**
	 * JPQL Query - findProductKeywordByKeywordId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductKeyword> findProductKeywordByKeywordId(Integer keywordId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductKeywordByKeywordId", startResult, maxRows, keywordId);
		return new LinkedHashSet<ProductKeyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductKeywordByStoreId
	 *
	 */
	@Transactional
	public Set<ProductKeyword> findProductKeywordByStoreId(Integer storeId) throws DataAccessException {

		return findProductKeywordByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findProductKeywordByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductKeyword> findProductKeywordByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductKeywordByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<ProductKeyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductKeywordByKeywordWeight
	 *
	 */
	@Transactional
	public Set<ProductKeyword> findProductKeywordByKeywordWeight(Integer keywordWeight) throws DataAccessException {

		return findProductKeywordByKeywordWeight(keywordWeight, -1, -1);
	}

	/**
	 * JPQL Query - findProductKeywordByKeywordWeight
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductKeyword> findProductKeywordByKeywordWeight(Integer keywordWeight, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductKeywordByKeywordWeight", startResult, maxRows, keywordWeight);
		return new LinkedHashSet<ProductKeyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllProductKeywords
	 *
	 */
	@Transactional
	public Set<ProductKeyword> findAllProductKeywords() throws DataAccessException {

		return findAllProductKeywords(-1, -1);
	}

	/**
	 * JPQL Query - findAllProductKeywords
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductKeyword> findAllProductKeywords(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllProductKeywords", startResult, maxRows);
		return new LinkedHashSet<ProductKeyword>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(ProductKeyword entity) {
		return true;
	}
}

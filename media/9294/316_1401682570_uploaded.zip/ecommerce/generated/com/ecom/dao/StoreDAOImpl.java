package com.ecom.dao;

import com.ecom.domain.Store;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Store entities.
 * 
 */
@Repository("StoreDAO")
@Transactional
public class StoreDAOImpl extends AbstractJpaDao<Store> implements StoreDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Store.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new StoreDAOImpl
	 *
	 */
	public StoreDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findStoreByPrimaryKey
	 *
	 */
	@Transactional
	public Store findStoreByPrimaryKey(Integer storeId) throws DataAccessException {

		return findStoreByPrimaryKey(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findStoreByPrimaryKey
	 *
	 */

	@Transactional
	public Store findStoreByPrimaryKey(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findStoreByPrimaryKey", startResult, maxRows, storeId);
			return (com.ecom.domain.Store) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllStores
	 *
	 */
	@Transactional
	public Set<Store> findAllStores() throws DataAccessException {

		return findAllStores(-1, -1);
	}

	/**
	 * JPQL Query - findAllStores
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Store> findAllStores(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllStores", startResult, maxRows);
		return new LinkedHashSet<Store>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Store entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.ProductKeyword;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage ProductKeyword entities.
 * 
 */
public interface ProductKeywordDAO extends JpaDao<ProductKeyword> {

	/**
	 * JPQL Query - findProductKeywordByPrimaryKey
	 *
	 */
	public ProductKeyword findProductKeywordByPrimaryKey(Integer prodId, Integer keywordId) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByPrimaryKey
	 *
	 */
	public ProductKeyword findProductKeywordByPrimaryKey(Integer prodId, Integer keywordId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByProdId
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByProdId(Integer prodId_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByProdId
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByProdId(Integer prodId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByKeywordId
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByKeywordId(Integer keywordId_1) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByKeywordId
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByKeywordId(Integer keywordId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByStoreId
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByStoreId
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByKeywordWeight
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByKeywordWeight(Integer keywordWeight) throws DataAccessException;

	/**
	 * JPQL Query - findProductKeywordByKeywordWeight
	 *
	 */
	public Set<ProductKeyword> findProductKeywordByKeywordWeight(Integer keywordWeight, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllProductKeywords
	 *
	 */
	public Set<ProductKeyword> findAllProductKeywords() throws DataAccessException;

	/**
	 * JPQL Query - findAllProductKeywords
	 *
	 */
	public Set<ProductKeyword> findAllProductKeywords(int startResult, int maxRows) throws DataAccessException;

}
package com.ecom.dao;

import com.ecom.domain.Role;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Role entities.
 * 
 */
public interface RoleDAO extends JpaDao<Role> {

	/**
	 * JPQL Query - findRoleByStoreId
	 *
	 */
	public Set<Role> findRoleByStoreId(Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByStoreId
	 *
	 */
	public Set<Role> findRoleByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByRoleId
	 *
	 */
	public Role findRoleByRoleId(Integer roleId) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByRoleId
	 *
	 */
	public Role findRoleByRoleId(Integer roleId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllRoles
	 *
	 */
	public Set<Role> findAllRoles() throws DataAccessException;

	/**
	 * JPQL Query - findAllRoles
	 *
	 */
	public Set<Role> findAllRoles(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateModifiedBefore
	 *
	 */
	public Set<Role> findRoleByDateModifiedBefore(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateModifiedBefore
	 *
	 */
	public Set<Role> findRoleByDateModifiedBefore(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateAddedAfter
	 *
	 */
	public Set<Role> findRoleByDateAddedAfter(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateAddedAfter
	 *
	 */
	public Set<Role> findRoleByDateAddedAfter(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByPrimaryKey
	 *
	 */
	public Role findRoleByPrimaryKey(Integer roleId) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByPrimaryKey
	 *
	 */
	public Role findRoleByPrimaryKey(Integer roleId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByStatusId
	 *
	 */
	public Set<Role> findRoleByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByStatusId
	 *
	 */
	public Set<Role> findRoleByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateAddedBefore
	 *
	 */
	public Set<Role> findRoleByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateAddedBefore
	 *
	 */
	public Set<Role> findRoleByDateAddedBefore(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateAdded
	 *
	 */
	public Set<Role> findRoleByDateAdded(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateAdded
	 *
	 */
	public Set<Role> findRoleByDateAdded(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateModified
	 *
	 */
	public Set<Role> findRoleByDateModified(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateModified
	 *
	 */
	public Set<Role> findRoleByDateModified(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateModifiedAfter
	 *
	 */
	public Set<Role> findRoleByDateModifiedAfter(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findRoleByDateModifiedAfter
	 *
	 */
	public Set<Role> findRoleByDateModifiedAfter(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

}
package com.ecom.dao;

import com.ecom.domain.Keyword;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Keyword entities.
 * 
 */
@Repository("KeywordDAO")
@Transactional
public class KeywordDAOImpl extends AbstractJpaDao<Keyword> implements
		KeywordDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Keyword.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new KeywordDAOImpl
	 *
	 */
	public KeywordDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAllKeywords
	 *
	 */
	@Transactional
	public Set<Keyword> findAllKeywords() throws DataAccessException {

		return findAllKeywords(-1, -1);
	}

	/**
	 * JPQL Query - findAllKeywords
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findAllKeywords(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllKeywords", startResult, maxRows);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findKeywordByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByKeywordId
	 *
	 */
	@Transactional
	public Keyword findKeywordByKeywordId(Integer keywordId) throws DataAccessException {

		return findKeywordByKeywordId(keywordId, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByKeywordId
	 *
	 */

	@Transactional
	public Keyword findKeywordByKeywordId(Integer keywordId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findKeywordByKeywordId", startResult, maxRows, keywordId);
			return (com.ecom.domain.Keyword) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findKeywordByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findKeywordByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByStatusId
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByStatusId(Integer statusId) throws DataAccessException {

		return findKeywordByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByDateAdded
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findKeywordByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByPrimaryKey
	 *
	 */
	@Transactional
	public Keyword findKeywordByPrimaryKey(Integer keywordId) throws DataAccessException {

		return findKeywordByPrimaryKey(keywordId, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByPrimaryKey
	 *
	 */

	@Transactional
	public Keyword findKeywordByPrimaryKey(Integer keywordId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findKeywordByPrimaryKey", startResult, maxRows, keywordId);
			return (com.ecom.domain.Keyword) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findKeywordByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findKeywordByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByDateModified
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findKeywordByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByStoreId
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByStoreId(Integer storeId) throws DataAccessException {

		return findKeywordByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * JPQL Query - findKeywordByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<Keyword> findKeywordByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findKeywordByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findKeywordByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Keyword> findKeywordByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findKeywordByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Keyword>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Keyword entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.AdminUser;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage AdminUser entities.
 * 
 */
@Repository("AdminUserDAO")
@Transactional
public class AdminUserDAOImpl extends AbstractJpaDao<AdminUser> implements
		AdminUserDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { AdminUser.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new AdminUserDAOImpl
	 *
	 */
	public AdminUserDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAdminUserByLastLoginDate
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByLastLoginDate(java.util.Calendar lastLoginDate) throws DataAccessException {

		return findAdminUserByLastLoginDate(lastLoginDate, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByLastLoginDate
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByLastLoginDate(java.util.Calendar lastLoginDate, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByLastLoginDate", startResult, maxRows, lastLoginDate);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findAdminUserByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByStatusId
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByStatusId(Integer statusId) throws DataAccessException {

		return findAdminUserByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllAdminUsers
	 *
	 */
	@Transactional
	public Set<AdminUser> findAllAdminUsers() throws DataAccessException {

		return findAllAdminUsers(-1, -1);
	}

	/**
	 * JPQL Query - findAllAdminUsers
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAllAdminUsers(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllAdminUsers", startResult, maxRows);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByName
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByName(String name) throws DataAccessException {

		return findAdminUserByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByName", startResult, maxRows, name);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByLastLoginDateAfter
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByLastLoginDateAfter(java.util.Calendar lastLoginDate) throws DataAccessException {

		return findAdminUserByLastLoginDateAfter(lastLoginDate, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByLastLoginDateAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByLastLoginDateAfter(java.util.Calendar lastLoginDate, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByLastLoginDateAfter", startResult, maxRows, lastLoginDate);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByPasswordContaining
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByPasswordContaining(String password) throws DataAccessException {

		return findAdminUserByPasswordContaining(password, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByPasswordContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByPasswordContaining(String password, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByPasswordContaining", startResult, maxRows, password);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByUserId
	 *
	 */
	@Transactional
	public AdminUser findAdminUserByUserId(Integer userId) throws DataAccessException {

		return findAdminUserByUserId(userId, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByUserId
	 *
	 */

	@Transactional
	public AdminUser findAdminUserByUserId(Integer userId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findAdminUserByUserId", startResult, maxRows, userId);
			return (com.ecom.domain.AdminUser) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAdminUserByEmailContaining
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByEmailContaining(String email) throws DataAccessException {

		return findAdminUserByEmailContaining(email, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByEmailContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByEmailContaining(String email, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByEmailContaining", startResult, maxRows, email);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByNameContaining
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByNameContaining(String name) throws DataAccessException {

		return findAdminUserByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByPassword
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByPassword(String password) throws DataAccessException {

		return findAdminUserByPassword(password, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByPassword
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByPassword(String password, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByPassword", startResult, maxRows, password);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByLastLoginDateBefore
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByLastLoginDateBefore(java.util.Calendar lastLoginDate) throws DataAccessException {

		return findAdminUserByLastLoginDateBefore(lastLoginDate, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByLastLoginDateBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByLastLoginDateBefore(java.util.Calendar lastLoginDate, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByLastLoginDateBefore", startResult, maxRows, lastLoginDate);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findAdminUserByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByPrimaryKey
	 *
	 */
	@Transactional
	public AdminUser findAdminUserByPrimaryKey(Integer userId) throws DataAccessException {

		return findAdminUserByPrimaryKey(userId, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByPrimaryKey
	 *
	 */

	@Transactional
	public AdminUser findAdminUserByPrimaryKey(Integer userId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findAdminUserByPrimaryKey", startResult, maxRows, userId);
			return (com.ecom.domain.AdminUser) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAdminUserByEmail
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByEmail(String email) throws DataAccessException {

		return findAdminUserByEmail(email, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByEmail
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByEmail(String email, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByEmail", startResult, maxRows, email);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByLangId
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByLangId(Integer langId) throws DataAccessException {

		return findAdminUserByLangId(langId, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByLangId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByLangId", startResult, maxRows, langId);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdminUserByDateAdded
	 *
	 */
	@Transactional
	public Set<AdminUser> findAdminUserByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findAdminUserByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findAdminUserByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<AdminUser> findAdminUserByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdminUserByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<AdminUser>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(AdminUser entity) {
		return true;
	}
}

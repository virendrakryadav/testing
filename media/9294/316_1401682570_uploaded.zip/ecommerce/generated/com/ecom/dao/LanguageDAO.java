package com.ecom.dao;

import com.ecom.domain.Language;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Language entities.
 * 
 */
public interface LanguageDAO extends JpaDao<Language> {

	/**
	 * JPQL Query - findLanguageByImageLocationContaining
	 *
	 */
	public Set<Language> findLanguageByImageLocationContaining(String imageLocation) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByImageLocationContaining
	 *
	 */
	public Set<Language> findLanguageByImageLocationContaining(String imageLocation, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByCodeContaining
	 *
	 */
	public Set<Language> findLanguageByCodeContaining(String code) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByCodeContaining
	 *
	 */
	public Set<Language> findLanguageByCodeContaining(String code, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDirectory
	 *
	 */
	public Set<Language> findLanguageByDirectory(String directory) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDirectory
	 *
	 */
	public Set<Language> findLanguageByDirectory(String directory, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllLanguages
	 *
	 */
	public Set<Language> findAllLanguages() throws DataAccessException;

	/**
	 * JPQL Query - findAllLanguages
	 *
	 */
	public Set<Language> findAllLanguages(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateAdded
	 *
	 */
	public Set<Language> findLanguageByDateAdded(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateAdded
	 *
	 */
	public Set<Language> findLanguageByDateAdded(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageBySortOrder
	 *
	 */
	public Set<Language> findLanguageBySortOrder(Integer sortOrder) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageBySortOrder
	 *
	 */
	public Set<Language> findLanguageBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByLocaleContaining
	 *
	 */
	public Set<Language> findLanguageByLocaleContaining(String locale) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByLocaleContaining
	 *
	 */
	public Set<Language> findLanguageByLocaleContaining(String locale, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByLangId
	 *
	 */
	public Language findLanguageByLangId(Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByLangId
	 *
	 */
	public Language findLanguageByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByImageLocation
	 *
	 */
	public Set<Language> findLanguageByImageLocation(String imageLocation_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByImageLocation
	 *
	 */
	public Set<Language> findLanguageByImageLocation(String imageLocation_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByName
	 *
	 */
	public Set<Language> findLanguageByName(String name) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByName
	 *
	 */
	public Set<Language> findLanguageByName(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDirectoryContaining
	 *
	 */
	public Set<Language> findLanguageByDirectoryContaining(String directory_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDirectoryContaining
	 *
	 */
	public Set<Language> findLanguageByDirectoryContaining(String directory_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateModified
	 *
	 */
	public Set<Language> findLanguageByDateModified(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateModified
	 *
	 */
	public Set<Language> findLanguageByDateModified(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateModifiedBefore
	 *
	 */
	public Set<Language> findLanguageByDateModifiedBefore(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateModifiedBefore
	 *
	 */
	public Set<Language> findLanguageByDateModifiedBefore(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByStatusId
	 *
	 */
	public Set<Language> findLanguageByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByStatusId
	 *
	 */
	public Set<Language> findLanguageByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByNameContaining
	 *
	 */
	public Set<Language> findLanguageByNameContaining(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByNameContaining
	 *
	 */
	public Set<Language> findLanguageByNameContaining(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByPrimaryKey
	 *
	 */
	public Language findLanguageByPrimaryKey(Integer langId_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByPrimaryKey
	 *
	 */
	public Language findLanguageByPrimaryKey(Integer langId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByCode
	 *
	 */
	public Set<Language> findLanguageByCode(String code_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByCode
	 *
	 */
	public Set<Language> findLanguageByCode(String code_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateModifiedAfter
	 *
	 */
	public Set<Language> findLanguageByDateModifiedAfter(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateModifiedAfter
	 *
	 */
	public Set<Language> findLanguageByDateModifiedAfter(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateAddedBefore
	 *
	 */
	public Set<Language> findLanguageByDateAddedBefore(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateAddedBefore
	 *
	 */
	public Set<Language> findLanguageByDateAddedBefore(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByLocale
	 *
	 */
	public Set<Language> findLanguageByLocale(String locale_1) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByLocale
	 *
	 */
	public Set<Language> findLanguageByLocale(String locale_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateAddedAfter
	 *
	 */
	public Set<Language> findLanguageByDateAddedAfter(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findLanguageByDateAddedAfter
	 *
	 */
	public Set<Language> findLanguageByDateAddedAfter(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

}
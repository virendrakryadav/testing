package com.ecom.dao;

import com.ecom.domain.Feature;

import java.util.Calendar;
import java.util.Set;
import org.skyway.spring.util.dao.JpaDao;
import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Feature entities.
 * 
 */
public interface FeatureDAO extends JpaDao<Feature> {

	/**
	 * JPQL Query - findAllFeatures
	 *
	 */
	public Set<Feature> findAllFeatures() throws DataAccessException;

	/**
	 * JPQL Query - findAllFeatures
	 *
	 */
	public Set<Feature> findAllFeatures(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateAddedBefore
	 *
	 */
	public Set<Feature> findFeatureByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateAddedBefore
	 *
	 */
	public Set<Feature> findFeatureByDateAddedBefore(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByPrimaryKey
	 *
	 */
	public Feature findFeatureByPrimaryKey(Integer featureId) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByPrimaryKey
	 *
	 */
	public Feature findFeatureByPrimaryKey(Integer featureId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByFeatureId
	 *
	 */
	public Feature findFeatureByFeatureId(Integer featureId_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByFeatureId
	 *
	 */
	public Feature findFeatureByFeatureId(Integer featureId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateModified
	 *
	 */
	public Set<Feature> findFeatureByDateModified(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateModified
	 *
	 */
	public Set<Feature> findFeatureByDateModified(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateModifiedAfter
	 *
	 */
	public Set<Feature> findFeatureByDateModifiedAfter(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateModifiedAfter
	 *
	 */
	public Set<Feature> findFeatureByDateModifiedAfter(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByStatusId
	 *
	 */
	public Set<Feature> findFeatureByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByStatusId
	 *
	 */
	public Set<Feature> findFeatureByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateAddedAfter
	 *
	 */
	public Set<Feature> findFeatureByDateAddedAfter(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateAddedAfter
	 *
	 */
	public Set<Feature> findFeatureByDateAddedAfter(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByInternalNameContaining
	 *
	 */
	public Set<Feature> findFeatureByInternalNameContaining(String internalName) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByInternalNameContaining
	 *
	 */
	public Set<Feature> findFeatureByInternalNameContaining(String internalName, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByInternalName
	 *
	 */
	public Set<Feature> findFeatureByInternalName(String internalName_1) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByInternalName
	 *
	 */
	public Set<Feature> findFeatureByInternalName(String internalName_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateModifiedBefore
	 *
	 */
	public Set<Feature> findFeatureByDateModifiedBefore(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateModifiedBefore
	 *
	 */
	public Set<Feature> findFeatureByDateModifiedBefore(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateAdded
	 *
	 */
	public Set<Feature> findFeatureByDateAdded(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findFeatureByDateAdded
	 *
	 */
	public Set<Feature> findFeatureByDateAdded(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

}
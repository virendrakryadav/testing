package com.ecom.dao;

import com.ecom.domain.KeywordDesc;

import java.util.Set;
import org.skyway.spring.util.dao.JpaDao;
import org.springframework.dao.DataAccessException;

/**
 * DAO to manage KeywordDesc entities.
 * 
 */
public interface KeywordDescDAO extends JpaDao<KeywordDesc> {

	/**
	 * JPQL Query - findKeywordDescByPrimaryKey
	 *
	 */
	public KeywordDesc findKeywordDescByPrimaryKey(Integer keywordId, Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByPrimaryKey
	 *
	 */
	public KeywordDesc findKeywordDescByPrimaryKey(Integer keywordId, Integer langId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllKeywordDescs
	 *
	 */
	public Set<KeywordDesc> findAllKeywordDescs() throws DataAccessException;

	/**
	 * JPQL Query - findAllKeywordDescs
	 *
	 */
	public Set<KeywordDesc> findAllKeywordDescs(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByKeywordId
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByKeywordId(Integer keywordId_1) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByKeywordId
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByKeywordId(Integer keywordId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByLangId
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByLangId(Integer langId_1) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByLangId
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByLangId(Integer langId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByDescription
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByDescription(String description) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByDescription
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByDescription(String description, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByDescriptionContaining
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByDescriptionContaining(String description_1) throws DataAccessException;

	/**
	 * JPQL Query - findKeywordDescByDescriptionContaining
	 *
	 */
	public Set<KeywordDesc> findKeywordDescByDescriptionContaining(String description_1, int startResult, int maxRows) throws DataAccessException;

}
package com.ecom.dao;

import com.ecom.domain.AdminUserStore;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage AdminUserStore entities.
 * 
 */
public interface AdminUserStoreDAO extends JpaDao<AdminUserStore> {

	/**
	 * JPQL Query - findAdminUserStoreByAdminUserId
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByAdminUserId(Integer adminUserId) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByAdminUserId
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByAdminUserId(Integer adminUserId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByIsDefault
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByIsDefault(Boolean isDefault) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByIsDefault
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByIsDefault(Boolean isDefault, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByStatusId
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByStatusId
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateModified
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateModified(java.util.Calendar dateModified) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateModified
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateModified(Calendar dateModified, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateModifiedAfter
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateModifiedAfter(java.util.Calendar dateModified_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateModifiedAfter
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateModifiedAfter(Calendar dateModified_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllAdminUserStores
	 *
	 */
	public Set<AdminUserStore> findAllAdminUserStores() throws DataAccessException;

	/**
	 * JPQL Query - findAllAdminUserStores
	 *
	 */
	public Set<AdminUserStore> findAllAdminUserStores(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByPrimaryKey
	 *
	 */
	public AdminUserStore findAdminUserStoreByPrimaryKey(Integer adminUserId_1, Integer storeId) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByPrimaryKey
	 *
	 */
	public AdminUserStore findAdminUserStoreByPrimaryKey(Integer adminUserId_1, Integer storeId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateAddedBefore
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateAddedBefore
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateAddedBefore(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateModifiedBefore
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateModifiedBefore(java.util.Calendar dateModified_2) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateModifiedBefore
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateModifiedBefore(Calendar dateModified_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByStoreId
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByStoreId(Integer storeId_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByStoreId
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByStoreId(Integer storeId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateAddedAfter
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateAddedAfter(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateAddedAfter
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateAddedAfter(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateAdded
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateAdded(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserStoreByDateAdded
	 *
	 */
	public Set<AdminUserStore> findAdminUserStoreByDateAdded(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

}
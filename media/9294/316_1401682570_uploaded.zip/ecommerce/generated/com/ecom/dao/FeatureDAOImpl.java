package com.ecom.dao;

import com.ecom.domain.Feature;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;
import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Feature entities.
 * 
 */
@Repository("FeatureDAO")
@Transactional
public class FeatureDAOImpl extends AbstractJpaDao<Feature> implements
		FeatureDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Feature.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new FeatureDAOImpl
	 *
	 */
	public FeatureDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAllFeatures
	 *
	 */
	@Transactional
	public Set<Feature> findAllFeatures() throws DataAccessException {

		return findAllFeatures(-1, -1);
	}

	/**
	 * JPQL Query - findAllFeatures
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findAllFeatures(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllFeatures", startResult, maxRows);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findFeatureByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByPrimaryKey
	 *
	 */
	@Transactional
	public Feature findFeatureByPrimaryKey(Integer featureId) throws DataAccessException {

		return findFeatureByPrimaryKey(featureId, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByPrimaryKey
	 *
	 */

	@Transactional
	public Feature findFeatureByPrimaryKey(Integer featureId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findFeatureByPrimaryKey", startResult, maxRows, featureId);
			return (com.ecom.domain.Feature) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findFeatureByFeatureId
	 *
	 */
	@Transactional
	public Feature findFeatureByFeatureId(Integer featureId) throws DataAccessException {

		return findFeatureByFeatureId(featureId, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByFeatureId
	 *
	 */

	@Transactional
	public Feature findFeatureByFeatureId(Integer featureId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findFeatureByFeatureId", startResult, maxRows, featureId);
			return (com.ecom.domain.Feature) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findFeatureByDateModified
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findFeatureByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findFeatureByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByStatusId
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByStatusId(Integer statusId) throws DataAccessException {

		return findFeatureByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findFeatureByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByInternalNameContaining
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByInternalNameContaining(String internalName) throws DataAccessException {

		return findFeatureByInternalNameContaining(internalName, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByInternalNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByInternalNameContaining(String internalName, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByInternalNameContaining", startResult, maxRows, internalName);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByInternalName
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByInternalName(String internalName) throws DataAccessException {

		return findFeatureByInternalName(internalName, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByInternalName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByInternalName(String internalName, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByInternalName", startResult, maxRows, internalName);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findFeatureByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureByDateAdded
	 *
	 */
	@Transactional
	public Set<Feature> findFeatureByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findFeatureByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Feature> findFeatureByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Feature>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Feature entity) {
		return true;
	}
}

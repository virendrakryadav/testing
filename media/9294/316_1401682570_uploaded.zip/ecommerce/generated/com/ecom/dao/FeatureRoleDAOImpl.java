package com.ecom.dao;

import com.ecom.domain.FeatureRole;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;
import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage FeatureRole entities.
 * 
 */
@Repository("FeatureRoleDAO")
@Transactional
public class FeatureRoleDAOImpl extends AbstractJpaDao<FeatureRole> implements
		FeatureRoleDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { FeatureRole.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new FeatureRoleDAOImpl
	 *
	 */
	public FeatureRoleDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findFeatureRoleByPrimaryKey
	 *
	 */
	@Transactional
	public FeatureRole findFeatureRoleByPrimaryKey(Integer featureId, Integer roleId) throws DataAccessException {

		return findFeatureRoleByPrimaryKey(featureId, roleId, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByPrimaryKey
	 *
	 */

	@Transactional
	public FeatureRole findFeatureRoleByPrimaryKey(Integer featureId, Integer roleId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findFeatureRoleByPrimaryKey", startResult, maxRows, featureId, roleId);
			return (com.ecom.domain.FeatureRole) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findFeatureRoleByFeatureId
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByFeatureId(Integer featureId) throws DataAccessException {

		return findFeatureRoleByFeatureId(featureId, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByFeatureId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByFeatureId(Integer featureId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByFeatureId", startResult, maxRows, featureId);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findFeatureRoleByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findFeatureRoleByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findFeatureRoleByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByRoleId
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByRoleId(Integer roleId) throws DataAccessException {

		return findFeatureRoleByRoleId(roleId, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByRoleId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByRoleId(Integer roleId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByRoleId", startResult, maxRows, roleId);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByDateAdded
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findFeatureRoleByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllFeatureRoles
	 *
	 */
	@Transactional
	public Set<FeatureRole> findAllFeatureRoles() throws DataAccessException {

		return findAllFeatureRoles(-1, -1);
	}

	/**
	 * JPQL Query - findAllFeatureRoles
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findAllFeatureRoles(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllFeatureRoles", startResult, maxRows);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByDateModified
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findFeatureRoleByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findFeatureRoleByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * JPQL Query - findFeatureRoleByStatusId
	 *
	 */
	@Transactional
	public Set<FeatureRole> findFeatureRoleByStatusId(Integer statusId) throws DataAccessException {

		return findFeatureRoleByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findFeatureRoleByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FeatureRole> findFeatureRoleByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findFeatureRoleByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<FeatureRole>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(FeatureRole entity) {
		return true;
	}
}

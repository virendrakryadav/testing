package com.ecom.dao;

import com.ecom.domain.AdminUser;

import java.util.Calendar;
import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage AdminUser entities.
 * 
 */
public interface AdminUserDAO extends JpaDao<AdminUser> {

	/**
	 * JPQL Query - findAdminUserByLastLoginDate
	 *
	 */
	public Set<AdminUser> findAdminUserByLastLoginDate(java.util.Calendar lastLoginDate) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByLastLoginDate
	 *
	 */
	public Set<AdminUser> findAdminUserByLastLoginDate(Calendar lastLoginDate, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByDateAddedAfter
	 *
	 */
	public Set<AdminUser> findAdminUserByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByDateAddedAfter
	 *
	 */
	public Set<AdminUser> findAdminUserByDateAddedAfter(Calendar dateAdded, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByStatusId
	 *
	 */
	public Set<AdminUser> findAdminUserByStatusId(Integer statusId) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByStatusId
	 *
	 */
	public Set<AdminUser> findAdminUserByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllAdminUsers
	 *
	 */
	public Set<AdminUser> findAllAdminUsers() throws DataAccessException;

	/**
	 * JPQL Query - findAllAdminUsers
	 *
	 */
	public Set<AdminUser> findAllAdminUsers(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByName
	 *
	 */
	public Set<AdminUser> findAdminUserByName(String name) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByName
	 *
	 */
	public Set<AdminUser> findAdminUserByName(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByLastLoginDateAfter
	 *
	 */
	public Set<AdminUser> findAdminUserByLastLoginDateAfter(java.util.Calendar lastLoginDate_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByLastLoginDateAfter
	 *
	 */
	public Set<AdminUser> findAdminUserByLastLoginDateAfter(Calendar lastLoginDate_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByPasswordContaining
	 *
	 */
	public Set<AdminUser> findAdminUserByPasswordContaining(String password) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByPasswordContaining
	 *
	 */
	public Set<AdminUser> findAdminUserByPasswordContaining(String password, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByUserId
	 *
	 */
	public AdminUser findAdminUserByUserId(Integer userId) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByUserId
	 *
	 */
	public AdminUser findAdminUserByUserId(Integer userId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByEmailContaining
	 *
	 */
	public Set<AdminUser> findAdminUserByEmailContaining(String email) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByEmailContaining
	 *
	 */
	public Set<AdminUser> findAdminUserByEmailContaining(String email, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByNameContaining
	 *
	 */
	public Set<AdminUser> findAdminUserByNameContaining(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByNameContaining
	 *
	 */
	public Set<AdminUser> findAdminUserByNameContaining(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByPassword
	 *
	 */
	public Set<AdminUser> findAdminUserByPassword(String password_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByPassword
	 *
	 */
	public Set<AdminUser> findAdminUserByPassword(String password_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByLastLoginDateBefore
	 *
	 */
	public Set<AdminUser> findAdminUserByLastLoginDateBefore(java.util.Calendar lastLoginDate_2) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByLastLoginDateBefore
	 *
	 */
	public Set<AdminUser> findAdminUserByLastLoginDateBefore(Calendar lastLoginDate_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByDateAddedBefore
	 *
	 */
	public Set<AdminUser> findAdminUserByDateAddedBefore(java.util.Calendar dateAdded_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByDateAddedBefore
	 *
	 */
	public Set<AdminUser> findAdminUserByDateAddedBefore(Calendar dateAdded_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByPrimaryKey
	 *
	 */
	public AdminUser findAdminUserByPrimaryKey(Integer userId_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByPrimaryKey
	 *
	 */
	public AdminUser findAdminUserByPrimaryKey(Integer userId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByEmail
	 *
	 */
	public Set<AdminUser> findAdminUserByEmail(String email_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByEmail
	 *
	 */
	public Set<AdminUser> findAdminUserByEmail(String email_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByLangId
	 *
	 */
	public Set<AdminUser> findAdminUserByLangId(Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByLangId
	 *
	 */
	public Set<AdminUser> findAdminUserByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByDateAdded
	 *
	 */
	public Set<AdminUser> findAdminUserByDateAdded(java.util.Calendar dateAdded_2) throws DataAccessException;

	/**
	 * JPQL Query - findAdminUserByDateAdded
	 *
	 */
	public Set<AdminUser> findAdminUserByDateAdded(Calendar dateAdded_2, int startResult, int maxRows) throws DataAccessException;

}
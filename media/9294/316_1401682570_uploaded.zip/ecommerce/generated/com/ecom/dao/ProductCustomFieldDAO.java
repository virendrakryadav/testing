package com.ecom.dao;

import com.ecom.domain.ProductCustomField;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage ProductCustomField entities.
 * 
 */
public interface ProductCustomFieldDAO extends JpaDao<ProductCustomField> {

	/**
	 * JPQL Query - findProductCustomFieldByPrimaryKey
	 *
	 */
	public ProductCustomField findProductCustomFieldByPrimaryKey(Integer prodId, Integer customFieldId) throws DataAccessException;

	/**
	 * JPQL Query - findProductCustomFieldByPrimaryKey
	 *
	 */
	public ProductCustomField findProductCustomFieldByPrimaryKey(Integer prodId, Integer customFieldId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllProductCustomFields
	 *
	 */
	public Set<ProductCustomField> findAllProductCustomFields() throws DataAccessException;

	/**
	 * JPQL Query - findAllProductCustomFields
	 *
	 */
	public Set<ProductCustomField> findAllProductCustomFields(int startResult, int maxRows) throws DataAccessException;

}
package com.ecom.dao;

import com.ecom.domain.StoreDesc;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage StoreDesc entities.
 * 
 */
public interface StoreDescDAO extends JpaDao<StoreDesc> {

	/**
	 * JPQL Query - findStoreDescByCssFilename
	 *
	 */
	public Set<StoreDesc> findStoreDescByCssFilename(String cssFilename) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByCssFilename
	 *
	 */
	public Set<StoreDesc> findStoreDescByCssFilename(String cssFilename, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllStoreDescs
	 *
	 */
	public Set<StoreDesc> findAllStoreDescs() throws DataAccessException;

	/**
	 * JPQL Query - findAllStoreDescs
	 *
	 */
	public Set<StoreDesc> findAllStoreDescs(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByLangId
	 *
	 */
	public Set<StoreDesc> findStoreDescByLangId(Integer langId) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByLangId
	 *
	 */
	public Set<StoreDesc> findStoreDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByLogoFilenameContaining
	 *
	 */
	public Set<StoreDesc> findStoreDescByLogoFilenameContaining(String logoFilename) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByLogoFilenameContaining
	 *
	 */
	public Set<StoreDesc> findStoreDescByLogoFilenameContaining(String logoFilename, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByCssFilenameContaining
	 *
	 */
	public Set<StoreDesc> findStoreDescByCssFilenameContaining(String cssFilename_1) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByCssFilenameContaining
	 *
	 */
	public Set<StoreDesc> findStoreDescByCssFilenameContaining(String cssFilename_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByPrimaryKey
	 *
	 */
	public StoreDesc findStoreDescByPrimaryKey(Integer storeId, Integer langId_1) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByPrimaryKey
	 *
	 */
	public StoreDesc findStoreDescByPrimaryKey(Integer storeId, Integer langId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByStoreId
	 *
	 */
	public Set<StoreDesc> findStoreDescByStoreId(Integer storeId_1) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByStoreId
	 *
	 */
	public Set<StoreDesc> findStoreDescByStoreId(Integer storeId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByLogoFilename
	 *
	 */
	public Set<StoreDesc> findStoreDescByLogoFilename(String logoFilename_1) throws DataAccessException;

	/**
	 * JPQL Query - findStoreDescByLogoFilename
	 *
	 */
	public Set<StoreDesc> findStoreDescByLogoFilename(String logoFilename_1, int startResult, int maxRows) throws DataAccessException;

}
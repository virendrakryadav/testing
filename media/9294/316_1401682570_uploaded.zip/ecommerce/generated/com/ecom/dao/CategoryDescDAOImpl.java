package com.ecom.dao;

import com.ecom.domain.CategoryDesc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage CategoryDesc entities.
 * 
 */
@Repository("CategoryDescDAO")
@Transactional
public class CategoryDescDAOImpl extends AbstractJpaDao<CategoryDesc> implements
		CategoryDescDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { CategoryDesc.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new CategoryDescDAOImpl
	 *
	 */
	public CategoryDescDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findCategoryDescByLangId
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByLangId(Integer langId) throws DataAccessException {

		return findCategoryDescByLangId(langId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByLangId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByLangId", startResult, maxRows, langId);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByPrimaryKey
	 *
	 */
	@Transactional
	public CategoryDesc findCategoryDescByPrimaryKey(Integer categoryId, Integer langId) throws DataAccessException {

		return findCategoryDescByPrimaryKey(categoryId, langId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByPrimaryKey
	 *
	 */

	@Transactional
	public CategoryDesc findCategoryDescByPrimaryKey(Integer categoryId, Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findCategoryDescByPrimaryKey", startResult, maxRows, categoryId, langId);
			return (com.ecom.domain.CategoryDesc) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitle
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitle(String metaTagsTitle) throws DataAccessException {

		return findCategoryDescByMetaTagsTitle(metaTagsTitle, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitle
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitle(String metaTagsTitle, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByMetaTagsTitle", startResult, maxRows, metaTagsTitle);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByImageLocationContaining
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByImageLocationContaining(String imageLocation) throws DataAccessException {

		return findCategoryDescByImageLocationContaining(imageLocation, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByImageLocationContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByImageLocationContaining(String imageLocation, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByImageLocationContaining", startResult, maxRows, imageLocation);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByMetaDescContaining
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaDescContaining(String metaDesc) throws DataAccessException {

		return findCategoryDescByMetaDescContaining(metaDesc, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByMetaDescContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaDescContaining(String metaDesc, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByMetaDescContaining", startResult, maxRows, metaDesc);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByName
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByName(String name) throws DataAccessException {

		return findCategoryDescByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByName", startResult, maxRows, name);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByDescriptionContaining
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByDescriptionContaining(String description) throws DataAccessException {

		return findCategoryDescByDescriptionContaining(description, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByDescriptionContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByDescriptionContaining(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByDescriptionContaining", startResult, maxRows, description);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByImageLocation
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByImageLocation(String imageLocation) throws DataAccessException {

		return findCategoryDescByImageLocation(imageLocation, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByImageLocation
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByImageLocation(String imageLocation, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByImageLocation", startResult, maxRows, imageLocation);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByNameContaining
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByNameContaining(String name) throws DataAccessException {

		return findCategoryDescByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitleContaining
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitleContaining(String metaTagsTitle) throws DataAccessException {

		return findCategoryDescByMetaTagsTitleContaining(metaTagsTitle, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByMetaTagsTitleContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaTagsTitleContaining(String metaTagsTitle, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByMetaTagsTitleContaining", startResult, maxRows, metaTagsTitle);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByTags
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByTags(String tags) throws DataAccessException {

		return findCategoryDescByTags(tags, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByTags
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByTags(String tags, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByTags", startResult, maxRows, tags);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByStoreId
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByStoreId(Integer storeId) throws DataAccessException {

		return findCategoryDescByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllCategoryDescs
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findAllCategoryDescs() throws DataAccessException {

		return findAllCategoryDescs(-1, -1);
	}

	/**
	 * JPQL Query - findAllCategoryDescs
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findAllCategoryDescs(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllCategoryDescs", startResult, maxRows);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByTagsContaining
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByTagsContaining(String tags) throws DataAccessException {

		return findCategoryDescByTagsContaining(tags, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByTagsContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByTagsContaining(String tags, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByTagsContaining", startResult, maxRows, tags);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByCategoryId
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByCategoryId(Integer categoryId) throws DataAccessException {

		return findCategoryDescByCategoryId(categoryId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByCategoryId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByCategoryId(Integer categoryId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByCategoryId", startResult, maxRows, categoryId);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByDescription
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByDescription(String description) throws DataAccessException {

		return findCategoryDescByDescription(description, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByDescription
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByDescription(String description, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByDescription", startResult, maxRows, description);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByMetaKeywords
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaKeywords(String metaKeywords) throws DataAccessException {

		return findCategoryDescByMetaKeywords(metaKeywords, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByMetaKeywords
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaKeywords(String metaKeywords, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByMetaKeywords", startResult, maxRows, metaKeywords);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByMetaDesc
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaDesc(String metaDesc) throws DataAccessException {

		return findCategoryDescByMetaDesc(metaDesc, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByMetaDesc
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaDesc(String metaDesc, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByMetaDesc", startResult, maxRows, metaDesc);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryDescByMetaKeywordsContaining
	 *
	 */
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaKeywordsContaining(String metaKeywords) throws DataAccessException {

		return findCategoryDescByMetaKeywordsContaining(metaKeywords, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryDescByMetaKeywordsContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<CategoryDesc> findCategoryDescByMetaKeywordsContaining(String metaKeywords, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryDescByMetaKeywordsContaining", startResult, maxRows, metaKeywords);
		return new LinkedHashSet<CategoryDesc>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(CategoryDesc entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.Language;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Language entities.
 * 
 */
@Repository("LanguageDAO")
@Transactional
public class LanguageDAOImpl extends AbstractJpaDao<Language> implements
		LanguageDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Language.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new LanguageDAOImpl
	 *
	 */
	public LanguageDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findLanguageByImageLocationContaining
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByImageLocationContaining(String imageLocation) throws DataAccessException {

		return findLanguageByImageLocationContaining(imageLocation, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByImageLocationContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByImageLocationContaining(String imageLocation, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByImageLocationContaining", startResult, maxRows, imageLocation);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByCodeContaining
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByCodeContaining(String code) throws DataAccessException {

		return findLanguageByCodeContaining(code, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByCodeContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByCodeContaining(String code, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByCodeContaining", startResult, maxRows, code);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDirectory
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDirectory(String directory) throws DataAccessException {

		return findLanguageByDirectory(directory, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDirectory
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDirectory(String directory, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDirectory", startResult, maxRows, directory);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllLanguages
	 *
	 */
	@Transactional
	public Set<Language> findAllLanguages() throws DataAccessException {

		return findAllLanguages(-1, -1);
	}

	/**
	 * JPQL Query - findAllLanguages
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findAllLanguages(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllLanguages", startResult, maxRows);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDateAdded
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findLanguageByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageBySortOrder
	 *
	 */
	@Transactional
	public Set<Language> findLanguageBySortOrder(Integer sortOrder) throws DataAccessException {

		return findLanguageBySortOrder(sortOrder, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageBySortOrder
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageBySortOrder", startResult, maxRows, sortOrder);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByLocaleContaining
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByLocaleContaining(String locale) throws DataAccessException {

		return findLanguageByLocaleContaining(locale, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByLocaleContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByLocaleContaining(String locale, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByLocaleContaining", startResult, maxRows, locale);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByLangId
	 *
	 */
	@Transactional
	public Language findLanguageByLangId(Integer langId) throws DataAccessException {

		return findLanguageByLangId(langId, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByLangId
	 *
	 */

	@Transactional
	public Language findLanguageByLangId(Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findLanguageByLangId", startResult, maxRows, langId);
			return (com.ecom.domain.Language) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findLanguageByImageLocation
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByImageLocation(String imageLocation) throws DataAccessException {

		return findLanguageByImageLocation(imageLocation, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByImageLocation
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByImageLocation(String imageLocation, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByImageLocation", startResult, maxRows, imageLocation);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByName
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByName(String name) throws DataAccessException {

		return findLanguageByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByName", startResult, maxRows, name);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDirectoryContaining
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDirectoryContaining(String directory) throws DataAccessException {

		return findLanguageByDirectoryContaining(directory, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDirectoryContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDirectoryContaining(String directory, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDirectoryContaining", startResult, maxRows, directory);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDateModified
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findLanguageByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findLanguageByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByStatusId
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByStatusId(Integer statusId) throws DataAccessException {

		return findLanguageByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByNameContaining
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByNameContaining(String name) throws DataAccessException {

		return findLanguageByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByPrimaryKey
	 *
	 */
	@Transactional
	public Language findLanguageByPrimaryKey(Integer langId) throws DataAccessException {

		return findLanguageByPrimaryKey(langId, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByPrimaryKey
	 *
	 */

	@Transactional
	public Language findLanguageByPrimaryKey(Integer langId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findLanguageByPrimaryKey", startResult, maxRows, langId);
			return (com.ecom.domain.Language) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findLanguageByCode
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByCode(String code) throws DataAccessException {

		return findLanguageByCode(code, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByCode
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByCode(String code, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByCode", startResult, maxRows, code);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findLanguageByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findLanguageByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByLocale
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByLocale(String locale) throws DataAccessException {

		return findLanguageByLocale(locale, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByLocale
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByLocale(String locale, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByLocale", startResult, maxRows, locale);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * JPQL Query - findLanguageByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<Language> findLanguageByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findLanguageByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findLanguageByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Language> findLanguageByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findLanguageByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Language>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Language entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.Product;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Product entities.
 * 
 */
@Repository("ProductDAO")
@Transactional
public class ProductDAOImpl extends AbstractJpaDao<Product> implements
		ProductDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Product.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new ProductDAOImpl
	 *
	 */
	public ProductDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findProductByMargin
	 *
	 */
	@Transactional
	public Set<Product> findProductByMargin(java.math.BigDecimal margin) throws DataAccessException {

		return findProductByMargin(margin, -1, -1);
	}

	/**
	 * JPQL Query - findProductByMargin
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByMargin(java.math.BigDecimal margin, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByMargin", startResult, maxRows, margin);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByDateAdded
	 *
	 */
	@Transactional
	public Set<Product> findProductByDateAdded(java.util.Calendar dateAdded) throws DataAccessException {

		return findProductByDateAdded(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDateAdded
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDateAdded(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDateAdded", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByDuty
	 *
	 */
	@Transactional
	public Set<Product> findProductByDuty(java.math.BigDecimal duty) throws DataAccessException {

		return findProductByDuty(duty, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDuty
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDuty(java.math.BigDecimal duty, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDuty", startResult, maxRows, duty);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByInternalNameContaining
	 *
	 */
	@Transactional
	public Set<Product> findProductByInternalNameContaining(String internalName) throws DataAccessException {

		return findProductByInternalNameContaining(internalName, -1, -1);
	}

	/**
	 * JPQL Query - findProductByInternalNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByInternalNameContaining(String internalName, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByInternalNameContaining", startResult, maxRows, internalName);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByMasterCatId
	 *
	 */
	@Transactional
	public Set<Product> findProductByMasterCatId(Integer masterCatId) throws DataAccessException {

		return findProductByMasterCatId(masterCatId, -1, -1);
	}

	/**
	 * JPQL Query - findProductByMasterCatId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByMasterCatId(Integer masterCatId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByMasterCatId", startResult, maxRows, masterCatId);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByDateAddedBefore
	 *
	 */
	@Transactional
	public Set<Product> findProductByDateAddedBefore(java.util.Calendar dateAdded) throws DataAccessException {

		return findProductByDateAddedBefore(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDateAddedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDateAddedBefore(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDateAddedBefore", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByProductCost
	 *
	 */
	@Transactional
	public Set<Product> findProductByProductCost(java.math.BigDecimal productCost) throws DataAccessException {

		return findProductByProductCost(productCost, -1, -1);
	}

	/**
	 * JPQL Query - findProductByProductCost
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByProductCost(java.math.BigDecimal productCost, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByProductCost", startResult, maxRows, productCost);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllProducts
	 *
	 */
	@Transactional
	public Set<Product> findAllProducts() throws DataAccessException {

		return findAllProducts(-1, -1);
	}

	/**
	 * JPQL Query - findAllProducts
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findAllProducts(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllProducts", startResult, maxRows);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByDateModifiedBefore
	 *
	 */
	@Transactional
	public Set<Product> findProductByDateModifiedBefore(java.util.Calendar dateModified) throws DataAccessException {

		return findProductByDateModifiedBefore(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDateModifiedBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDateModifiedBefore(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDateModifiedBefore", startResult, maxRows, dateModified);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByOrdered
	 *
	 */
	@Transactional
	public Set<Product> findProductByOrdered(Integer ordered) throws DataAccessException {

		return findProductByOrdered(ordered, -1, -1);
	}

	/**
	 * JPQL Query - findProductByOrdered
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByOrdered(Integer ordered, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByOrdered", startResult, maxRows, ordered);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByComputedPrice
	 *
	 */
	@Transactional
	public Set<Product> findProductByComputedPrice(java.math.BigDecimal computedPrice) throws DataAccessException {

		return findProductByComputedPrice(computedPrice, -1, -1);
	}

	/**
	 * JPQL Query - findProductByComputedPrice
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByComputedPrice(java.math.BigDecimal computedPrice, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByComputedPrice", startResult, maxRows, computedPrice);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByDateModified
	 *
	 */
	@Transactional
	public Set<Product> findProductByDateModified(java.util.Calendar dateModified) throws DataAccessException {

		return findProductByDateModified(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDateModified
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDateModified(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDateModified", startResult, maxRows, dateModified);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByProdId
	 *
	 */
	@Transactional
	public Product findProductByProdId(Integer prodId) throws DataAccessException {

		return findProductByProdId(prodId, -1, -1);
	}

	/**
	 * JPQL Query - findProductByProdId
	 *
	 */

	@Transactional
	public Product findProductByProdId(Integer prodId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findProductByProdId", startResult, maxRows, prodId);
			return (com.ecom.domain.Product) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findProductByEnteredPrice
	 *
	 */
	@Transactional
	public Set<Product> findProductByEnteredPrice(java.math.BigDecimal enteredPrice) throws DataAccessException {

		return findProductByEnteredPrice(enteredPrice, -1, -1);
	}

	/**
	 * JPQL Query - findProductByEnteredPrice
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByEnteredPrice(java.math.BigDecimal enteredPrice, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByEnteredPrice", startResult, maxRows, enteredPrice);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByInternalName
	 *
	 */
	@Transactional
	public Set<Product> findProductByInternalName(String internalName) throws DataAccessException {

		return findProductByInternalName(internalName, -1, -1);
	}

	/**
	 * JPQL Query - findProductByInternalName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByInternalName(String internalName, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByInternalName", startResult, maxRows, internalName);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByUseEnteredPrice
	 *
	 */
	@Transactional
	public Set<Product> findProductByUseEnteredPrice(Boolean useEnteredPrice) throws DataAccessException {

		return findProductByUseEnteredPrice(useEnteredPrice, -1, -1);
	}

	/**
	 * JPQL Query - findProductByUseEnteredPrice
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByUseEnteredPrice(Boolean useEnteredPrice, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByUseEnteredPrice", startResult, maxRows, useEnteredPrice);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByDateAddedAfter
	 *
	 */
	@Transactional
	public Set<Product> findProductByDateAddedAfter(java.util.Calendar dateAdded) throws DataAccessException {

		return findProductByDateAddedAfter(dateAdded, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDateAddedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDateAddedAfter(java.util.Calendar dateAdded, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDateAddedAfter", startResult, maxRows, dateAdded);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByOrderUnits
	 *
	 */
	@Transactional
	public Set<Product> findProductByOrderUnits(Integer orderUnits) throws DataAccessException {

		return findProductByOrderUnits(orderUnits, -1, -1);
	}

	/**
	 * JPQL Query - findProductByOrderUnits
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByOrderUnits(Integer orderUnits, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByOrderUnits", startResult, maxRows, orderUnits);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByDateModifiedAfter
	 *
	 */
	@Transactional
	public Set<Product> findProductByDateModifiedAfter(java.util.Calendar dateModified) throws DataAccessException {

		return findProductByDateModifiedAfter(dateModified, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDateModifiedAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDateModifiedAfter(java.util.Calendar dateModified, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDateModifiedAfter", startResult, maxRows, dateModified);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByPrimaryKey
	 *
	 */
	@Transactional
	public Product findProductByPrimaryKey(Integer prodId) throws DataAccessException {

		return findProductByPrimaryKey(prodId, -1, -1);
	}

	/**
	 * JPQL Query - findProductByPrimaryKey
	 *
	 */

	@Transactional
	public Product findProductByPrimaryKey(Integer prodId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findProductByPrimaryKey", startResult, maxRows, prodId);
			return (com.ecom.domain.Product) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findProductByCustom
	 *
	 */
	@Transactional
	public Set<Product> findProductByCustom(java.math.BigDecimal custom) throws DataAccessException {

		return findProductByCustom(custom, -1, -1);
	}

	/**
	 * JPQL Query - findProductByCustom
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByCustom(java.math.BigDecimal custom, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByCustom", startResult, maxRows, custom);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductBySortOrder
	 *
	 */
	@Transactional
	public Set<Product> findProductBySortOrder(Integer sortOrder) throws DataAccessException {

		return findProductBySortOrder(sortOrder, -1, -1);
	}

	/**
	 * JPQL Query - findProductBySortOrder
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductBySortOrder(Integer sortOrder, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductBySortOrder", startResult, maxRows, sortOrder);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByStatusId
	 *
	 */
	@Transactional
	public Set<Product> findProductByStatusId(Integer statusId) throws DataAccessException {

		return findProductByStatusId(statusId, -1, -1);
	}

	/**
	 * JPQL Query - findProductByStatusId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByStatusId(Integer statusId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByStatusId", startResult, maxRows, statusId);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductByTaxClassId
	 *
	 */
	@Transactional
	public Set<Product> findProductByTaxClassId(Integer taxClassId) throws DataAccessException {

		return findProductByTaxClassId(taxClassId, -1, -1);
	}

	/**
	 * JPQL Query - findProductByTaxClassId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByTaxClassId(Integer taxClassId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByTaxClassId", startResult, maxRows, taxClassId);
		return new LinkedHashSet<Product>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Product entity) {
		return true;
	}
	/**
	 * JPQL Query - findProductByStoreId
	 *
	 */
	@Transactional
	public Set<Product> findProductByStoreId(Integer storeId) throws DataAccessException {

		return findProductByStoreId(storeId, -1, -1);
	}

	/**
	 * JPQL Query - findProductByStoreId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByStoreId(Integer storeId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByStoreId", startResult, maxRows, storeId);
		return new LinkedHashSet<Product>(query.getResultList());
	}
	
	/**
	 * JPQL Query - findProductByDesignerId
	 *
	 */
	@Transactional
	public Set<Product> findProductByDesignerId(Integer designerId) throws DataAccessException {

		return findProductByDesignerId(designerId, -1, -1);
	}

	/**
	 * JPQL Query - findProductByDesignerId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Product> findProductByDesignerId(Integer designerId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findProductByDesignerId", startResult, maxRows, designerId);
		return new LinkedHashSet<Product>(query.getResultList());
	}
}

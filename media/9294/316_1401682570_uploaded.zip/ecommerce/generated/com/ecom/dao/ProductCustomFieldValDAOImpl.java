package com.ecom.dao;

import com.ecom.domain.ProductCustomFieldVal;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage ProductCustomFieldVal entities.
 * 
 */
@Repository("ProductCustomFieldValDAO")
@Transactional
public class ProductCustomFieldValDAOImpl extends AbstractJpaDao<ProductCustomFieldVal>
		implements ProductCustomFieldValDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { ProductCustomFieldVal.class }));

	/**
	 * EntityManager injected by Spring for persistence unit Postgres
	 *
	 */
	@PersistenceContext(unitName = "Postgres")
	private EntityManager entityManager;

	/**
	 * Instantiates a new ProductCustomFieldValDAOImpl
	 *
	 */
	public ProductCustomFieldValDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAllProductCustomFieldVals
	 *
	 */
	@Transactional
	public Set<ProductCustomFieldVal> findAllProductCustomFieldVals() throws DataAccessException {

		return findAllProductCustomFieldVals(-1, -1);
	}

	/**
	 * JPQL Query - findAllProductCustomFieldVals
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<ProductCustomFieldVal> findAllProductCustomFieldVals(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllProductCustomFieldVals", startResult, maxRows);
		return new LinkedHashSet<ProductCustomFieldVal>(query.getResultList());
	}

	/**
	 * JPQL Query - findProductCustomFieldValByPrimaryKey
	 *
	 */
	@Transactional
	public ProductCustomFieldVal findProductCustomFieldValByPrimaryKey(Integer prodId, Integer langId, Integer customFieldId) throws DataAccessException {

		return findProductCustomFieldValByPrimaryKey(prodId, langId, customFieldId, -1, -1);
	}

	/**
	 * JPQL Query - findProductCustomFieldValByPrimaryKey
	 *
	 */

	@Transactional
	public ProductCustomFieldVal findProductCustomFieldValByPrimaryKey(Integer prodId, Integer langId, Integer customFieldId, int startResult, int maxRows) throws DataAccessException {
		try {
			Query query = createNamedQuery("findProductCustomFieldValByPrimaryKey", startResult, maxRows, prodId, langId, customFieldId);
			return (com.ecom.domain.ProductCustomFieldVal) query.getSingleResult();
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(ProductCustomFieldVal entity) {
		return true;
	}
}

package com.ecom.dao;

import com.ecom.domain.HttpSession;

import org.skyway.spring.util.dao.JpaDao;

/**
 * DAO to manage HttpSession entities.
 * 
 */
public interface HttpSessionDAO extends JpaDao<HttpSession> {

}
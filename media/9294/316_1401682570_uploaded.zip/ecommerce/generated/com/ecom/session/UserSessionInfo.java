package com.ecom.session;

import java.io.Serializable;

import com.ecom.domain.AdminUser;
import com.ecom.domain.Language;
import com.ecom.domain.StoreDesc;
import com.ecom.utils.Permissions;
/*
 * This class contains User Session Specific information. 
 * It includes, login info, shopping cart info etc.
 */
public class UserSessionInfo implements Serializable
{
	private static final long serialVersionUID = 20110816L;

	/*
	 * Key for getting UserSessionInfo object from HTTP Session
	 */
	public static final String USER_SESSION_INFO_KEY = "user_sesssion_info";
	
	public AdminUser adminUser;
	public Permissions permissions;	
	public Language currentLang;
	public StoreDesc currentStoreDesc;
}

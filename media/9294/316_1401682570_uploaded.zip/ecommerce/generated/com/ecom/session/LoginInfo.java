package com.ecom.session;

import java.io.Serializable;
import java.util.Locale;

public class LoginInfo implements Serializable{
	private static final long serialVersionUID = 20110816L;
	
	//common used variable, so no getter/setter are provided
	public int adminUserId;
	public String userName;
	public int roleId;
	public String roleName;
	public int storeId;
	public String storeName;
	public int langId;
	public String langName;
	public Locale userLocale;	
	public Locale siteLocale;	
	
	/*
	 * Returns user Locale if set, otherwise return site locale
	 * 
	 */
	public Locale getLocale()
	{
		if (userLocale == null)
			return siteLocale;
		else
			return userLocale;
	}
}
